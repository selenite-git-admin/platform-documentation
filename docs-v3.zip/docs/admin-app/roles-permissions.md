# Roles & Permissions

RBAC model stub.
