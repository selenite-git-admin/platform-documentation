# Messaging Events Module

Overview stub.
