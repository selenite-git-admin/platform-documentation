# Schema Registry Changelog

- 2025-09-30: Enriched subfiles created with V1 depth and V3 structure  
- 2025-09-30: Initial enriched index.md produced
