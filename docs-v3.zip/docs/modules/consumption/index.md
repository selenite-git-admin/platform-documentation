# Consumption Domain

Overview stub.
