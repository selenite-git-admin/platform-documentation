# Activation Plane — API Reference

👉 **Placeholder**: To be generated automatically from `openapi/activation-plane.yaml` using Swagger-UI or Redoc.

- Spec location: `/openapi/activation-plane.yaml`  
- Base path: `/api/v1`  
- Auth: OAuth2 (client credentials / auth code)  

Once configured, this section will render the full endpoint list and schemas.
