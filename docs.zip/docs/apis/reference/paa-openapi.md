# Admin Host App API — OpenAPI Reference

> TODO: Embed/Link `apis/specs/paa-v1.yaml`.
