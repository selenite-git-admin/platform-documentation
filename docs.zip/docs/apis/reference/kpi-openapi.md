# KPI Services API — OpenAPI Reference

> TODO: Embed/Link `apis/specs/kpi-v1.yaml`.
