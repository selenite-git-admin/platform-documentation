# Tenant App API — OpenAPI Reference

> TODO: Embed/Link `apis/specs/tenant-v1.yaml`.
