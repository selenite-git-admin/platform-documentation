# API Guide — Versioning & Deprecation

URI/header versioning, deprecation schedule, and Major–Minor–Update alignment.

> TODO: Add changelog conventions and SLAs.
