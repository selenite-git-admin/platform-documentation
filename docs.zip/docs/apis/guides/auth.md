# API Guide — Auth & Scopes

OIDC/JWT, scopes per role (Super Admin, Admin App, Connectors, Tenant App).

> TODO: Describe token formats, rotation, and examples.
