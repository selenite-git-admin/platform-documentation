# API Examples — Contract Publish (Admin App → PHS)

Workflow: draft → review → approve → publish.

> TODO: Include request/response snippets.
