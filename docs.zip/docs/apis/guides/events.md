# API Guide — Webhooks & Events

Event names, payload IDs, signatures, and delivery guarantees.

> TODO: Document verification steps and replay.
