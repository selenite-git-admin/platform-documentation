# API Examples — CICD → PHS (CLI/SDK)

End‑to‑end example to publish a contract via CICD.

> TODO: Insert step‑by‑step with sample payloads.
