# APIs — Guides (Overview)

Task‑driven guides for using platform APIs.

> TODO: Link to auth, versioning, errors, rate limits, events, and examples.
