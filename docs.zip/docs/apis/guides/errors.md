# API Guide — Errors & Retries

Canonical error schema, idempotency keys, retry/backoff matrix.

> TODO: Provide code samples.
