# API Examples — Connector Egress (Raw)

How connectors authenticate and send/receive data under Raw contract.

> TODO: Add egress allowlist patterns and telemetry hooks.
