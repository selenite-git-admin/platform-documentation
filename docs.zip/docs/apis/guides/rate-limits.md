# API Guide — Rate Limits & Quotas

Policy by actor; 429 behavior, quotas, and reporting.

> TODO: Add headers and examples.
