# Tenant App — Overview

Purpose: tenant‑facing application surfaces KPIs and governed datasets.

> TODO: Clarify RBAC, data access, and audit views.
