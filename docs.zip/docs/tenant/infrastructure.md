# Tenant Infrastructure

Deployment models: single‑tenant SaaS, multi‑tenant SaaS, on‑prem/hybrid.

> TODO: Describe provisioning via Admin App → CDK Pipeline; connectivity to PHS.
