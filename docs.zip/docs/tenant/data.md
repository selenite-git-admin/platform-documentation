# Tenant Data Access & Reports

Access patterns, BI connectors, and governed exports.

> TODO: Add examples and policy controls.
