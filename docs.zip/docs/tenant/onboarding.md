# Tenant Onboarding

Steps to onboard a tenant; prerequisites and validation.

> TODO: Add checklists and BDD scenarios.
