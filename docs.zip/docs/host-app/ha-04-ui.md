# Host App — UI

## Screens & Workflows
Contracts, Tenants, Reference Data, Audit, Health, Settings

## Patterns
Approvals, diff/compare, lineage previews, disabled controls in read-only

## Accessibility
Keyboard nav, focus states, high contrast

## Notifications
In-app and email/webhook
