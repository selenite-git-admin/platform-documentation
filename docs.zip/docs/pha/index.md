# Platform Host/Admin App — Overview

Purpose: governance workflows (contracts, tenants), read‑only PHS health.

> TODO: State boundaries: no infra mutations; writes published contracts to PHS.
