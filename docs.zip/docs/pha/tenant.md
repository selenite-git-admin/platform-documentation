# PAA — Tenant Management

Tenant CRUD, quotas, calendars, residency flags, and lifecycle.

> TODO: Add state machine and acceptance criteria.
