# KPI Services — Framework

Metric model: formula, inputs (GDP), grain, filters, dimensions, delivery.

> TODO: Add examples and contract snippets.
