# KPI Services — Overview

Purpose: derive auditable metrics over GDP, with thresholds and delivery SLAs.

> TODO: Outline runtime behavior and boundaries with Schema Services.
