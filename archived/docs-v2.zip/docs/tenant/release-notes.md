# Tenant App – Release Notes

## vX.Y.Z – YYYY‑MM‑DD
### Added
- …

### Changed
- …

### Fixed
- …

### Security
- …
