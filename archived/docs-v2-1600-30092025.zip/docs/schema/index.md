# Schema Services — Index

Read in order. Each file builds on the previous file.

- 01-overview.md
- 02-schema-contracts.md
- 03-schema-enforcement.md
- 04-extraction-schema-model.md
- 05-raw-schema-model.md
- 06-gdp-schema-model.md
- 07-kpi-schema-model.md
- 08-meta-schema-model.md
- 09-schema-database.md
- 10-schema-management.md
