# Data Pipeline

Read this module before Schema Services.
This module explains how data moves from source to Gold.
