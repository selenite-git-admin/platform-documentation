# Operations - Runbooks

Standard runbooks for Shared Services modules.

- Auth - rotate IdP client secret, force logout.  
- RBAC - clear AVP cache, redeploy Cedar policies.  
- Secrets - rekey vault, expire leases.  
- Scheduler - purge stuck jobs, replay DLQ.  
- Logging - expand retention window temporarily.  
- Telemetry - scrape OTel collector status.

> Each runbook must include steps, rollback, validation.