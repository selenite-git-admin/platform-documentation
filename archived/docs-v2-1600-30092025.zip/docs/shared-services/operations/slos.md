# Operations - SLOs

Golden signals and error budgets for Shared Services modules.

| Module       | SLO Target                  | Notes |
|--------------|-----------------------------|-------|
| Auth         | P95 login < 300ms, 99.9% avail | IdP dependent |
| RBAC         | P95 authorize < 120ms, 99.99% avail | Cached |
| Secrets      | 99.99% read availability     | Writes async |
| Scheduler    | 95% jobs on time ±30s        | Cron drift excluded |
| Logging      | P95 ingest < 200ms           | Search SLA separate |
| Telemetry    | Metrics/trace drop <0.1%     | Collector HA |