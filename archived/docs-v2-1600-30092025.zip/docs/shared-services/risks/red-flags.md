# Risks & Red Flags

!!! warning "Blunt truth"
    Shared Services must remain plain and primitive.

- ❌ Don’t add business logic (validation rules, KPI derivations).  
- ❌ Don’t embed housekeeping jobs (schema migrations, tenant bootstrap).  
- ❌ Avoid cross-tenant leaks (always enforce tenantId).  
- ❌ Don’t bypass audit trails (all modules emit events).  
- ✅ Keep everything minimal, composable, boring.