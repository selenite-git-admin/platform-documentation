# Shared Services

The Shared Services is the platform’s utility belt: plain, cross-cutting modules that provide security, identity, observability, and reliability primitives. It carries no business logic and integrates with no external ERP/CRM/HRMS. Other systems consume these primitives via clear contracts.

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational)
![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

!!! warning "Blunt truth"
    If complex workflows, schema rules, or ERP-specific logic creep in here, Shared Services will bloat and slow everything else. Keep it minimal and composable.

---

## Scope (what this system provides)
- Authentication, authorization, secrets, encryption
- Logging, telemetry, health checks
- Job scheduling, service discovery, messaging
- Simple notifications, feature flags
- ID/UUID helpers

## Out of scope (intentionally excluded)
- ERP/CRM connectors, data models, schema/catalog ownership  
- Business workflows, KPI/domain logic, tenant onboarding flows  
- DR/BC runbooks and compliance operations (owned elsewhere)

---

## Where to go next

- Modules - full catalog of primitives (Auth, RBAC, Secrets, …) with features and APIs  
  → See Modules Index at `platform/shared_services_system/modules/index.md`

- Operations - runbooks and SLOs to keep shared services healthy  
  → Runbooks: `platform/shared_services_system/operations/runbooks.md`  
  → SLOs: `platform/shared_services_system/operations/slos.md`

- Risks - red flags & anti-patterns to avoid in Shared Services  
  → `platform/shared_services_system/risks/red-flags.md`

- Events - standard events emitted across modules (for subscribers)  
  → `platform/shared_services_system/events/events-catalog.md`

- Compliance - security baseline and retention expectations  
  → `platform/shared_services_system/compliance/security-baseline.md`

- Change Control - versioning rules, approvals for breaking changes  
  → `platform/shared_services_system/change-control.md`

- UI Screens - minimal admin UIs & wireframes (platform engineers / tenant admins)  
  → `platform/shared_services_system/ui/index.md`

- DB Designs - ERD, schema docs, migrations templates (keep it thin)  
  → `platform/shared_services_system/db/index.md`

---

## Conventions

- Keep it boring: primitives only; no tenant-specific logic.  
- Contracts first: APIs/events are versioned (semver) and audited.  
- Tenancy: APIs/events include `tenantId`; UI is advisory - APIs enforce.  
- Docs: Each module maintains `index.md`, `features.md`, `api.md` (CSV tables referenced with short paths inside module docs).