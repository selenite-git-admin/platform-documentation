# UI Screens - Shared Services

Keep UI minimal - only what platform engineers and tenant admins need. No business workflows.

## Screens (by module)
- Auth Admin
  - IdP configuration (OIDC, client IDs/secrets, redirect URIs)
  - Token lifetimes & cookie settings
  - Allowed domains / passkey policy
- RBAC Admin
  - Policy sets per tenant (view/diff/version)
  - Entitlements preview (user → features matrix)
  - Cache purge / simulate decision
- Secrets
  - Secret list (labels, versions), masked preview
  - Rotation policy & schedule
  - Lease management (revoke/extend)
- Gateway
  - Limits/quotas per tenant/key
  - Canary routing weights and rollback
  - Edge status and 429 heatmap
- Health
  - Aggregated readiness, failing deps, maintenance toggle
- Telemetry & Logging
  - Golden signals dashboards links
  - Log search presets (correlation ID)

## UX Rules
- Tenant first: every admin action is scoped to `tenantId` visibly.
- Dangerous ops require reason + confirmation and emit audit events.
- Copy-pasteable cURL for every API action in the UI.
- Redact secrets by default; reveal via short-lived view tokens.

## Wireframes
Place PNGs/SVGs under `./wireframes/` and reference them here: