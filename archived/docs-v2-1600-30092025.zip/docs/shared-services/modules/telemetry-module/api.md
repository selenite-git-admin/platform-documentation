# API - Telemetry Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/telemetry-module-apis.csv') }}

---

## Operations

---

### metrics_write
**Method/Path:** `POST /telemetry/metrics/write (binary remote_write)`  
**Purpose:** Ingest metrics (remote write).

**Request**
```http
HTTP/1.1 200 OK
POST /telemetry/metrics/write (binary remote_write)
```
**Response**
```json
{"ok": True}
```

---

### trace_write
**Method/Path:** `POST /telemetry/trace/write (OTLP/gRPC or HTTP)`  
**Purpose:** Ingest trace spans.

**Request**
```http
HTTP/1.1 200 OK
POST /telemetry/trace/write (OTLP/gRPC or HTTP)
```
**Response**
```json
{"ok": True}
```

---

### dashboards
**Method/Path:** `GET /telemetry/dashboards?module=rbac-module`  
**Purpose:** List dashboards/links.

**Request**
```http
GET /telemetry/dashboards?module=rbac-module HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"items": [{"name": "RBAC Golden Signals", "url": "https://grafana/..."}]}
```

---

### slos
**Method/Path:** `GET /telemetry/slos?module=rbac-module`  
**Purpose:** List SLOs and burn rates.

**Request**
```http
GET /telemetry/slos?module=rbac-module HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"items": [{"name": "authz decide P95<120ms", "burnRate": "1.2x"}]}
```