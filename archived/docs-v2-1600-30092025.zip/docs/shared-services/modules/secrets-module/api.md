# API - Secrets Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/secrets-module-apis.csv') }}

---

## Operations

---

### get
**Method/Path:** `GET /secrets?name=db/password&version=3`  
**Purpose:** Fetch a secret value/version.

**Request**
```http
GET /secrets?name=db/password&version=3 HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"name": "db/password", "version": 3, "value": "*****", "leaseTtlSec": 3600}
```

---

### set
**Method/Path:** `POST /secrets/set`  
**Purpose:** Create or update a secret (versioned).

**Request**
```json
{"name": "db/password", "value": "s3cr3t", "labels": ["prod", "db"]}
```
**Response**
```json
{"ok": True, "version": 4}
```

---

### list
**Method/Path:** `GET /secrets?prefix=db/`  
**Purpose:** List secrets by prefix or label.

**Request**
```http
GET /secrets?prefix=db/ HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"items": [{"name": "db/password"}, {"name": "db/user"}]}
```

---

### rotate
**Method/Path:** `POST /secrets/rotate`  
**Purpose:** Trigger rotation for a secret.

**Request**
```json
{"name": "api/token"}
```
**Response**
```json
{"ok": True, "newVersion": 7}
```

---

### leases
**Method/Path:** `POST /secrets/leases`  
**Purpose:** Issue/revoke ephemeral credentials.

**Request**
```json
{"name": "db/password", "ttlSec": 900}
```
**Response**
```json
{"leaseId": "lease_123", "expiresAt": "2025-08-26T12:00:00Z"}
```