# API - Logging Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/logging-module-apis.csv') }}

---

## Operations

---

### append
**Method/Path:** `POST /logs/append`  
**Purpose:** Append structured log line.

**Request**
```json
{"level": "INFO", "message": "job started", "context": {"tenantId": "TEN-123", "requestId": "REQ-1"}}
```
**Response**
```json
{"ok": True}
```

---

### search
**Method/Path:** `GET /logs/search?tenant=TEN-123&level=ERROR&from=2025-08-01`  
**Purpose:** Search logs by fields/time window.

**Request**
```http
GET /logs/search?tenant=TEN-123&level=ERROR&from=2025-08-01 HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"items": [{"time": "2025-08-26T10:00:00Z", "message": "fail", "level": "ERROR"}]}
```

---

### tail
**Method/Path:** `GET /logs/tail?tenant=TEN-123`  
**Purpose:** Live tail stream (SSE/WebSocket).

**Request**
```http
GET /logs/tail?tenant=TEN-123 HTTP/1.1
Host: api.example.com
```
**Response**
```http
HTTP/1.1 200 OK
Content-Type: text/event-stream
```