# API - Gateway Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/gateway-module-apis.csv') }}

---

## Operations

### status
**Method/Path:** `GET /gateway/status`  
**Purpose:** Report edge health and summarized config (read-only).

**Response**
```json
{
  "healthy": true,
  "routes": 128,
  "limits": {"tenants": 56, "keys": 143},
  "version": "2025.08.26-1"
}
```

---

### limits_get
**Method/Path:** `GET /gateway/limits?tenant=TEN-123`  
**Purpose:** Fetch effective limits/quotas for a tenant or key.

**Response**
```json
{
  "tenantId": "TEN-123",
  "rate": "500 rpm",
  "burst": 200,
  "quota": "50k/day"
}
```

---

### limits_set
**Method/Path:** `POST /gateway/limits`  
**Purpose:** Set limits/quotas for a tenant or key (idempotent).

**Request**
```json
{ "tenantId": "TEN-123", "rate": "500 rpm", "burst": 200, "quota": "50k/day" }
```

**Response**
```json
{ "ok": true }
```

---

### keys_issue
**Method/Path:** `POST /gateway/keys/issue`  
**Purpose:** Issue a new API key (hash-at-rest; return plain once).

**Request**
```json
{ "tenantId": "TEN-123", "label": "finapp-ci" }
```

**Response**
```json
{
  "keyId": "key_9Xc12",
  "apiKey": "sk_live_9sdf...only_shown_once"
}
```

---

### keys_revoke
**Method/Path:** `POST /gateway/keys/revoke`  
**Purpose:** Revoke an existing API key.

**Request**
```json
{ "keyId": "key_9Xc12" }
```

**Response**
```json
{ "ok": true }
```

---

### signature_verify
**Method/Path:** `POST /gateway/signature/verify`  
**Purpose:** Verify HMAC/Ed25519 signature for inbound B2B calls (utility).

**Request**
```json
{
  "algo": "hmac-sha256",
  "payload": "base64:...",
  "signature": "base64:...",
  "secretRef": "key_9Xc12",
  "timestamp": "2025-08-26T09:15:00Z"
}
```

**Response**
```json
{ "valid": true, "skewSeconds": 12 }
```

---

### routes_canary_set
**Method/Path:** `POST /gateway/routes/canary`  
**Purpose:** Set weighted routing for canary rollout and rollback quickly.

**Request**
```json
{ "route": "/kpi", "weights": {"v1": 90, "v2": 10} }
```

**Response**
```json
{ "ok": true }
```

---

### cache_purge
**Method/Path:** `POST /gateway/cache/purge`  
**Purpose:** Purge edge cache for a specific route pattern.

**Request**
```json
{ "pattern": "/docs/*" }
```

**Response**
```json
{ "ok": true, "purged": 127 }
```

---

## Error Model
```json
{
  "error": "forbidden",
  "error_description": "Admin scope required",
  "correlation_id": "REQ-2025-08-26-xyz123"
}
```
Common: `invalid_request`, `unauthorized`, `forbidden`, `rate_limited`, `config_push_failed`.