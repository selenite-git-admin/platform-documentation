# API - Encryption Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List

{{ read_csv('api/encryption-module-apis.csv') }}

---

## Operations

### encrypt
**Method/Path:** `POST /crypto/encrypt`  
**Purpose:** Encrypt plaintext using KMS-backed keys. Supports optional tenant-scoped key references and envelope mode.

**Request**
```json
{
  "tenantId": "TEN-123",
  "plaintext": "SGVsbG8gV29ybGQ=",
  "keyRef": "kms:alias/platform-default",
  "aad": "REQ-abc123",
  "envelope": false
}
```

**Response**
```json
{
  "ciphertext": "CiQAABCD...",
  "keyRef": "kms:alias/platform-default",
  "alg": "AES-GCM",
  "iv": "o8c3c2r5...",
  "tag": "b2Yk...",
  "aad": "REQ-abc123"
}
```

---

### decrypt
**Method/Path:** `POST /crypto/decrypt`  
**Purpose:** Decrypt ciphertext previously encrypted by the service. Supports envelope mode.

**Request**
```json
{
  "tenantId": "TEN-123",
  "ciphertext": "CiQAABCD...",
  "keyRef": "kms:alias/platform-default",
  "aad": "REQ-abc123"
}
```

**Response**
```json
{ "plaintext": "SGVsbG8gV29ybGQ=" }
```

---

### sign
**Method/Path:** `POST /crypto/sign`  
**Purpose:** Create a digital signature for payload integrity/non-repudiation.

**Request**
```json
{
  "tenantId": "TEN-123",
  "payload": "eyJpZCI6ICJKT0ItMDAxIn0=",
  "keyRef": "kms:alias/signing-default",
  "alg": "RSASSA_PSS_SHA_256"
}
```

**Response**
```json
{ "signature": "MEQCIB8...==" }
```

---

### verify
**Method/Path:** `POST /crypto/verify`  
**Purpose:** Verify a signature created by `sign`.

**Request**
```json
{
  "tenantId": "TEN-123",
  "payload": "eyJpZCI6ICJKT0ItMDAxIn0=",
  "signature": "MEQCIB8...==",
  "keyRef": "kms:alias/signing-default",
  "alg": "RSASSA_PSS_SHA_256"
}
```

**Response**
```json
{ "valid": true }
```

---

### key_status
**Method/Path:** `GET /crypto/key/status?keyRef=kms:alias/platform-default&tenantId=TEN-123`  
**Purpose:** Provide health/rotation info for a key reference (non-secret).

**Response**
```json
{
  "keyRef": "kms:alias/platform-default",
  "status": "active",
  "lastRotated": "2025-07-15T00:00:00Z",
  "rotationPolicyDays": 90
}
```

---

## Error Model
```json
{
  "error": "invalid_request",
  "error_description": "keyRef is required",
  "correlation_id": "REQ-2025-08-26-xyz123"
}
```
Common cases: `invalid_request`, `unauthorized`, `forbidden`, `kms_unavailable`, `key_revoked`, `payload_too_large`.