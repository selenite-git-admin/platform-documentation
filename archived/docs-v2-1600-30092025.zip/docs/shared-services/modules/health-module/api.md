# API - Health Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/health-module-apis.csv') }}

---

## Operations

### live
**Method/Path:** `GET /health/live`  
**Purpose:** Process is up. Never checks dependencies. Used by container orchestrators.

**Response**
```json
{ "ok": true, "service": "shared-services.health", "time": "2025-08-26T09:30:00Z" }
```

---

### ready
**Method/Path:** `GET /health/ready`  
**Purpose:** Service can accept traffic. Checks only critical dependencies.

**Response (healthy)**
```json
{ "ready": true, "deps": [], "time": "2025-08-26T09:30:05Z" }
```

**Response (not ready)**
```json
{
  "ready": false,
  "deps": [{ "name": "postgres", "status": "down", "latencyMs": 1200 }],
  "time": "2025-08-26T09:30:05Z"
}
```

---

### status
**Method/Path:** `GET /health/status`  
**Purpose:** Structured summary for dashboards (version, uptime, maintenance, failing deps).

**Response**
```json
{
  "service": "shared-services.health",
  "version": "2025.08.26-1",
  "uptimeSec": 86400,
  "maintenance": { "active": false },
  "failingDeps": []
}
```

---

### dependencies
**Method/Path:** `GET /health/dependencies`  
**Purpose:** Detailed probe results with timing and last error.

**Response**
```json
{
  "probes": [
    {"name":"postgres","status":"ok","latencyMs":12},
    {"name":"redis","status":"ok","latencyMs":3},
    {"name":"avp","status":"ok","latencyMs":27}
  ]
}
```

---

### maintenance_get
**Method/Path:** `GET /health/maintenance`  
**Purpose:** Return current maintenance state and schedule.

**Response**
```json
{ "active": false, "window": null }
```

---

### maintenance_set
**Method/Path:** `POST /health/maintenance`  
**Purpose:** Toggle or schedule maintenance (admin-only).

**Request**
```json
{ "active": true, "window": { "from": "2025-08-26T10:00:00Z", "to": "2025-08-26T12:00:00Z" }, "reason":"DB patching" }
```

**Response**
```json
{ "ok": true }
```

---

## Error Model
```json
{
  "error": "invalid_request",
  "error_description": "window.to must be in the future",
  "correlation_id": "REQ-2025-08-26-xyz123"
}
```
Common: `invalid_request`, `unauthorized`, `forbidden`, `probe_timeout`.