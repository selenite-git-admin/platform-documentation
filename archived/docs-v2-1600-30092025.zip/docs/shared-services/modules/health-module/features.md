# Features - Health Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## Feature List

{{ read_csv('features/health-module-features.csv') }}

---

## Notes
- Priority: P0 = must-have, P1 = near-term, P2 = backlog.
- Dependencies: reference Feature IDs in same/other modules.
- Status: Planned | In Progress | Done | Backlog.