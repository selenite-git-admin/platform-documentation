# API - Auth Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List

{{ read_csv('api/auth-module-apis.csv') }}

---

## Operations

### login
**Method/Path:** `GET /auth/login?tenant=TEN-123&redirect=/app`  
**Purpose:** Start OIDC flow via IdP Hosted UI.

**Request (example)**
```http
GET /auth/login?tenant=TEN-123&redirect=%2Fapp HTTP/1.1
Host: api.example.com
```

**Response**
```http
HTTP/1.1 302 Found
Location: https://your-idp-domain.auth.region.amazoncognito.com/login?client_id=...&redirect_uri=https%3A%2F%2Fapi.example.com%2Fauth%2Fcallback&response_type=code&scope=openid+email+profile
Set-Cookie: _reqid=...; HttpOnly; Secure; SameSite=Strict
```

---

### callback
**Method/Path:** `GET /auth/callback?code=...&state=...`  
**Purpose:** Handle IdP redirect, exchange code, set secure cookies (web) or return tokens (API clients).

**Response (web/SPAs: sets cookies + redirects)**
```http
HTTP/1.1 302 Found
Location: /app
Set-Cookie: id_token=...; HttpOnly; Secure; SameSite=Strict; Path=/
Set-Cookie: access_token=...; HttpOnly; Secure; SameSite=Strict; Path=/
Set-Cookie: refresh_token=...; HttpOnly; Secure; SameSite=Strict; Path=/
```

**Response (programmatic/API client)**
```json
{
  "token_type": "Bearer",
  "expires_in": 900,
  "access_token": "eyJhbGciOi...",
  "refresh_token": "def50200...",
  "id_token": "eyJraWQiOi...",
  "tenantId": "TEN-123"
}
```

---

### logout
**Method/Path:** `POST /auth/logout`  
**Purpose:** Revoke refresh token and clear cookies.

**Request**
```http
POST /auth/logout HTTP/1.1
Host: api.example.com
Authorization: Bearer eyJhbGciOi...
```

**Response**
```json
{ "ok": true }
```

---

### token_refresh
**Method/Path:** `POST /auth/token/refresh`  
**Purpose:** Exchange refresh token for a new access token (and rotate refresh).

**Request**
```http
POST /auth/token/refresh HTTP/1.1
Host: api.example.com
Content-Type: application/json

{
  "refresh_token": "def50200..."
}
```

**Response**
```json
{
  "token_type": "Bearer",
  "expires_in": 900,
  "access_token": "eyJhbGciOi...",
  "refresh_token": "def50200..." 
}
```

---

### introspect
**Method/Path:** `POST /auth/token/introspect`  
**Purpose:** Validate token server-side and return basic claims.

**Request**
```http
POST /auth/token/introspect HTTP/1.1
Host: api.example.com
Content-Type: application/json

{ "token": "eyJhbGciOi..." }
```

**Response**
```json
{
  "active": true,
  "sub": "u-123",
  "exp": 1753963200,
  "tenantId": "TEN-123",
  "scope": "openid profile email"
}
```

---

### m2m_token
**Method/Path:** `POST /auth/m2m/token`  
**Purpose:** Issue access token for service-to-service auth using client credentials.

**Request**
```http
POST /auth/m2m/token HTTP/1.1
Host: api.example.com
Content-Type: application/json

{
  "client_id": "svc-finance-app",
  "client_secret": "******",
  "audience": "kpi-api"
}
```

**Response**
```json
{
  "token_type": "Bearer",
  "expires_in": 900,
  "access_token": "eyJhbGciOi...",
  "tenantId": "TEN-123"
}
```

---

## Error Model

All endpoints return standard errors with a consistent shape:

```json
{
  "error": "invalid_token",
  "error_description": "Access token expired",
  "correlation_id": "REQ-2025-08-26-abc123"
}
```

Common cases:
- `invalid_grant` - wrong/expired code or refresh token
- `unauthorized` - missing/invalid access token
- `suspended` - user or tenant suspended (blocked pre-authorization)
- `rate_limited` - gateway throttling exceeded