# Product Requirements - Auth MVP

!!! info "Purpose"
    The authentication module controls access to the platform. It protects data and operations by allowing only the right people to sign in. It builds user trust through clear, fast, and predictable journeys comparable to the best products users know.

## Summary
Provide secure, low-effort sign-in using Amazon Cognito. Keep development minimal. Use email + password with email OTP. Enforce access on the server using Cognito roles or claims. Prepare a clean path to Amazon Verified Permissions later without changing clients.

## Why Cognito
- Minimal build. Hosted UI covers login, first-time password set, forgot password, and email OTP.
- Secure defaults. OAuth 2.0 with PKCE, signed JWTs, JWKS rotation, password policy, and MFA enforcement.
- Operates well. CloudWatch metrics, SES email delivery, and managed availability.
- Grows cleanly. Add Google/Microsoft federation, TOTP, and fine-grained authorization later.

## Goals
- Fast, reliable sign-in for invited users
- Minimal custom code
- Clear deny paths and audits
- Simple operations with metrics and alarms

## Non-Goals
- Social sign-in
- SMS or TOTP MFA
- AVP in this release
- Pre-auth tenant discovery or tenant switch UI

## Users
- Host admin and staff
- Client admin
- Client user

## Assumptions
- Email is the single login identifier
- SES sender or domain is verified and out of sandbox
- Hosted UI theming is acceptable for the MVP

## Scope
- Hosted UI login, first-login password set, forgot password
- Email OTP as mandatory MFA
- One active tenant per session
- Basic profile endpoint
- Server checks with Cognito roles or claims
- JWT verification at the gateway

## Flows
- Invite user with temporary password
- First login sets permanent password, then email OTP
- Regular login uses password, then email OTP
- Forgot password sends code by email
- Logout clears session and ends Hosted UI session where supported

### Flow Diagram
![diagram placeholder](../../../assets/diagrams/diagram_placeholder.svg)

## Functional Requirements

| ID | Requirement | Effort | AWS | Acceptance |
|---|---|---|---|---|
| FR-01 | Use Cognito user pools with the Hosted UI for all auth screens. | Config | Cognito | Hosted UI shows login, new password, forgot password, and OTP screens. |
| FR-02 | Use OAuth 2.0 Authorization Code flow with PKCE. | Config | Cognito | Callback exchanges code + verifier for tokens successfully. |
| FR-03 | Enforce invite-only access. | Config | Cognito | Users not pre-created are denied with a clear reason; no session created. |
| FR-04 | Require email OTP as the second factor. | Config | Cognito | After password, user must enter the emailed code to complete login. |
| FR-05 | Force password change on first login for invited users. | Config | Cognito | First login triggers new password screen before OTP. |
| FR-06 | Provide password reset by email. | Config | Cognito | Forgot password sends a code and confirms new password end-to-end. |
| FR-07 | Keep one active tenant per session. | Dev+Config | Cognito | Tenant id stored as a user attribute and present in ID token; reject requests without a tenant. |
| FR-08 | Expose a profile endpoint returning user id, tenant id, and roles. | Develop | Cognito | `/auth/me` returns fields from the ID token with p95 < 100 ms. |
| FR-09 | Verify JWTs at the gateway using the user pool JWKS. | Develop | Cognito | Invalid or expired tokens are rejected; logs show deny reason. |
| FR-10 | Enforce server access using Cognito roles or claims. | Develop | Cognito | Protected endpoints deny when the role is missing; denies are audited. |
| FR-11 | Support logout that clears app session and Hosted UI session where supported. | Develop | Cognito | After logout, protected routes return unauthorized until next login. |

## Non-Functional Requirements

| ID | Requirement | Effort | AWS | Acceptance |
|---|---|---|---|---|
| NFR-01 | Use HttpOnly and Secure cookies; do not expose tokens to page scripts. | Develop | - | No token present in client storage; cookies carry session only. |
| NFR-02 | Set short-lived tokens; enforce idle and absolute session timeouts. | Config | Cognito | Token TTLs match policy; sessions expire as configured. |
| NFR-03 | Track login success rate and deny counts by reason. | Config | Cognito | Metrics visible for last 24h; two alarms configured. |
| NFR-04 | Audit sign-in, deny, and logout. | Develop | - | Events include correlation id and tenant id. |
| NFR-05 | Provide a clean upgrade path to AVP without client changes. | Design | AVP | Authorization facade defined; AVP can replace role checks later. |

## Operational Notes
- Deliverability. Verify SES sender or domain and exit sandbox early.
- Metrics. Track login success rate, deny counts, and error spikes; set alarms.
- Limits. Hosted UI theming is simple; acceptable for MVP.

## Dependencies
- SES domain or sender verification
- CDN and TLS in front of the app
- App callback and logout URLs registered in Cognito

## Risks
- Email deliverability delays OTP and resets
- Misconfigured callbacks break login
- Over-scoped roles weaken enforcement

### Mitigations
- Warm-up deliverability and monitor bounces
- Pre-prod checklist for callbacks and logout URLs
- Minimal role set; reviewed changes

## Rollout
- Internal tenants first
- One pilot client
- Observe metrics and logs for a week
- Open to all tenants after stability

## Future Expansion
- Social sign-in (Google, Microsoft)
- TOTP or passwordless via custom challenges
- AVP for fine-grained authorization behind the facade
- Identifier-first login or vanity domains if needed

## References
- Cognito user pools overview  
  https://docs.aws.amazon.com/cognito/latest/developerguide/cognito-user-identity-pools.html
- App integration and Hosted UI  
  https://docs.aws.amazon.com/cognito/latest/developerguide/cognito-userpools-configuring-app-integration.html
- MFA settings and email message MFA  
  https://docs.aws.amazon.com/cognito/latest/developerguide/user-pool-settings-mfa.html
- Admin invite and first login password set  
  https://docs.aws.amazon.com/cognito/latest/developerguide/signing-up-users-in-your-app.html#user-pool-sign-up-admin-create-user
- Forgot password flow  
  https://docs.aws.amazon.com/cognito/latest/developerguide/password-reset-enduser.html
- Signing keys and JWKS  
  https://docs.aws.amazon.com/cognito/latest/developerguide/amazon-cognito-signing-keys.html
- Monitoring with CloudWatch  
  https://docs.aws.amazon.com/cognito/latest/developerguide/monitoring-cloudwatch.html
