# API - Feature Flags Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/feature-flags-module-apis.csv') }}

---

## Operations

---

### eval
**Method/Path:** `POST /flags/eval`  
**Purpose:** Evaluate a flag for a subject.

**Request**
```json
{"flag": "new-nav", "subject": {"userId": "u-123", "tenantId": "TEN-123"}}
```
**Response**
```json
{"value": True, "variant": "on"}
```

---

### definitions
**Method/Path:** `GET /flags/definitions`  
**Purpose:** List flag definitions (read-only).

**Request**
```http
GET /flags/definitions HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"items": [{"name": "new-nav", "type": "boolean"}]}
```

---

### expose
**Method/Path:** `POST /flags/expose`  
**Purpose:** Record exposure metrics.

**Request**
```json
{"flag": "new-nav", "subject": {"userId": "u-123"}, "variant": "on"}
```
**Response**
```json
{"ok": True}
```