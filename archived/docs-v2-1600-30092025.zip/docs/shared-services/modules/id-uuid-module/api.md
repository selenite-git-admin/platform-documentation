# API - ID/UUID Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/id-uuid-module-apis.csv') }}

---

## Operations

---

### new
**Method/Path:** `POST /ids/new`  
**Purpose:** Generate single UUIDv7.

**Request**
```http
POST /ids/new HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"uuid": "018f6a9f-88d0-7a7a-bf6e-9f3a5d4d0c1a"}
```

---

### bulk
**Method/Path:** `POST /ids/bulk`  
**Purpose:** Generate batch UUIDv7.

**Request**
```json
{"count": 100}
```
**Response**
```json
{"uuids": ["018f6a9f...", "018f6aa0..."]}
```

---

### correlation
**Method/Path:** `POST /ids/correlation`  
**Purpose:** Create correlation/request IDs.

**Request**
```http
POST /ids/correlation HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"correlationId": "CORR-20250826-abc123"}
```