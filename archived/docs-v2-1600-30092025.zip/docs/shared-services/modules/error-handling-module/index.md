# Errors (Fault Handling) - Shared Service

!!! abstract "Purpose"
    One canonical way to signal, log, route, and act on errors across Cxofacts.  
    This module defines the error envelope, taxonomy, and runtime rules for sync APIs and async workloads.

!!! tip "Who consumes this"
        **Everyone.** Product services, Shared Services (Auth, RBAC, Logging, Messaging, Notifications), and external integrations.

---

## Scope
- In: Error envelope (HTTP/JSON), error taxonomy & reasons, correlation IDs, retry/backoff/circuit-breaking, DLQ routing, error events → Notifications, redaction rules, SLOs/signals, runbook hooks.
- Out: Transport internals (see Messaging), log storage/format (see Logging), human-facing channels (see Notifications).

## Why this exists (no hand-waving)
- Stop bespoke error payloads and “mystery 500s.”  
- Make retries predictable (and safe).  
- Ensure every failure is either recovered or surfaced (alert/notification) with an audit trail.

## Relationships
- Messaging: delivers error events and DLQs; this module tells you when and what to publish.  
- Logging: structured logs; this module mandates what keys must appear for errors.  
- Notifications: how human-visible alerts are sent; this module says when to trigger them.

## Quick adopt checklist
- Emit error responses using the envelope below.  
- Map to the taxonomy here; add module-specific `reason`s in your own appendix.  
- Use correlationId consistently (reuse `X-Request-Id`).  
- Apply timeouts, retries with jitter, and idempotency.  
- On repeated failure: DLQ + error event → Notifications.  
- Wire metrics/traces as defined here.

---

## Canonical Error Envelope (HTTP)
```json
{
  "error": "forbidden",
  "reason": "user_not_authorized",
  "message": "Contact your admin to be added to Cxofacts.",
  "correlationId": "req-9f1c...",
  "ts": "2025-08-26T10:12:30Z"
}
```
**Fields**
- `error` - stable platform code: `invalid_request | unauthorized | forbidden | not_found | conflict | rate_limited | upstream_error | internal`.  
- `reason` - module-specific subtype (e.g., `mfa_required`, `email_unverified`, `policy_denied`).  
- `message` - human-safe, non-PII.  
- `correlationId` - same value logged and propagated in headers.  
- `ts` - ISO8601 UTC.

**HTTP mapping**
- 400 invalid_request · 401 unauthorized · 403 forbidden · 404 not_found · 409 conflict · 429 rate_limited · 5xx upstream_error/internal.

!!! note "Headers to include on error responses"
    - `X-Request-Id` (or `X-Correlation-Id`)  
    - `Retry-After` (for 429 or 503), seconds or HTTP-date  
    - `Cache-Control: no-store`

---

## Signals (must instrument)
- Counters: errors by `error`, `reason`, `httpStatus`  
- SLIs: error-rate %, 5xx rate, p95 latency, retry success %  
- Traces: span status with `error.code`, `error.reason`, `tenantId`, `userId?`  
- Logs: never log tokens or secrets; allow `email` only if essential

---

## Diagrams
- `diagrams/errors-module.drawio` → _Async retry/DLQ flow_, _Error envelope anatomy_. Export SVG and embed in consuming docs.