# Audit Module

Immutable, append-only audit trail for all critical platform events and security-relevant actions.

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational)
![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 25-Aug-2025](https://img.shields.io/badge/Last_Updated-25--Aug--2025-lightgrey)

---

!!! info "Purpose"
    Provide a tamper-evident, queryable log of every significant action: logins, authorization decisions, provisioning changes, schema updates, and admin actions.  

!!! warning "Blunt truth"
    If the audit trail can be modified or bypassed, compliance is gone and trust in the platform collapses.

---

## Design Goals
- Immutable: append-only, write-once storage with tamper evidence.
- Complete coverage: every security-relevant event, every admin change.
- Queryable: APIs to search, filter, and export logs for audits.
- Retention policy: configurable per-tenant and per-regulatory regime.
- Separation of duties: no one team can silently alter or purge logs.

## Architecture Principles
- All audit writes go through a facade service.
- Events structured in JSON Schema, signed, and chained with hashes.
- Storage backend: Postgres/JSONB for query; long-term archive in S3/Glacier with hash chain.
- Redaction by policy: secrets/tokens masked at ingestion.
- Sealing: periodic batch hashing (Merkle root) published to external store.

---

## Core Components
- Audit Facade: API endpoint to accept structured events.
- Log Store: primary append-only table with JSONB payloads.
- Archiver: moves aged logs to cold storage; maintains hash chain.
- Query API: filters by actor, tenant, action, time window.
- Integrity Verifier: recalculates seals; detects tampering.
- Exporter: generates evidence packs for compliance.

---

## APIs at a glance
- `POST /audit` → append audit record (validated schema, masked secrets).
- `GET /audit/search?tenant=TEN-123&actor=user-456&action=authz.decide`
- `GET /audit/export?tenant=TEN-123&range=2025-01-01:2025-01-31` → downloadable bundle.
- Events: `AUDIT_APPENDED`, `AUDIT_SEAL_PUBLISHED`.

---

## Failure Modes
- DB outage → buffer events in queue; retry until persisted.
- Tamper detected → alert + fail closed until investigation.
- Cold archive unavailable → continue hot storage; raise warning.
- Overloaded queries → enforce pagination + rate limits.

---

## Observability & SLOs
- Metrics: append latency P95 < 50 ms, append failure rate < 0.1%.
- Events: `audit_append_failed`, `audit_integrity_mismatch`.
- Dashboards: event volume per tenant, query latency, seal status.

---

## Roadmap
- Phase 0: Append-only log with schema + masking; query API.
- Phase 1: Archival + integrity seals; exporter for compliance.
- Phase 2: Admin UI viewer with search/export.
- Phase 3: External notarization (publish Merkle roots to blockchain or secure ledger).

---

## References
- Auth Module → `/platform/shared_services_system/modules/auth-module/`
- RBAC Module → `/platform/shared_services_system/modules/rbac-module/`
- Risks & Mitigation (Audit) → `/risks/index.md`

---

### Acceptance Criteria (MVP)
- All login/authz/admin events appended with schema validation.
- Tamper-evidence via hash chain in place.
- Query API returns results by tenant/actor/action/time.
- Exporter produces valid evidence pack for a one-month window.