# Backend Role Enforcement - Contract (Auth ↔ RBAC)

**Position:** The back-end MUST enforce access. Front-end guards are UX only.

## Runtime contract
### 1) Token verification (Gateway)
- Validate JWT signature (kid/JWKS), `iss`, `aud`, `exp`, `nbf`.
- Extract: `sub` (userId), `tenantId`, `roles[]`, `scope[]`, `jti`, `ver` (policy snapshot version if present).
- Inject headers to upstream:  
  `X-User-Id`, `X-Tenant-Id`, `X-Roles`, `X-Scopes`, `X-Request-Id` (correlation).

### 2) Authorization decision (Service)
- Before performing the action, call RBAC:
```
POST /authz/decide
{
  "subject": { "userId": "u-123", "tenantId": "TEN-001", "roles": ["TENANT_ADMIN"] },
  "resource": { "type": "kpi", "id": "revenue", "path": "/kpi/revenue" },
  "action": "read",
  "context": { "method": "GET", "ip": "...", "requestId": "..." }
}
```
**Response:**
```
200 OK
{
  "decision": "ALLOW",
  "policyVersion": "2025-08-26-01",
  "ttlSec": 60
}
```
- On `DENY`, return `403` with body `{ "error": "forbidden", "reason": "policy_denied" }`.

### 3) Caching
- Services MAY cache positive decisions for `ttlSec` keyed by `(userId, tenantId, resource, action, policyVersion)`.
- Cache MUST be flushed on policy/version change or when `jti` is in a revoke list.

### 4) Auditing & telemetry
- Emit `audit.recorded` for admin-config/role changes and `policy_denied` decisions.
- OTel: span `authz.decide` with attributes (`tenantId`, `userId`, `resource`, `action`, `decision`).

## Resource & action naming
- `resource.type`: stable domain noun (`kpi`, `dataset`, `dashboard`, `user`, `tenant-config`).
- `resource.id`: business identifier (e.g., `revenue`, `gross-margin`).
- `action`: `read | write | delete | execute | administer` (extend as needed).

## Error codes
| HTTP | error             | when                              |
|------|-------------------|-----------------------------------|
| 401  | unauthorized      | missing/invalid token             |
| 403  | policy_denied     | RBAC denied                       |
| 403  | tenant_mismatch   | token tenant ≠ request tenant     |
| 429  | rate_limited      | RBAC or gateway throttled         |
| 5xx  | upstream_error    | RBAC unavailable                  |

## Definition of Done
- Gateway middleware validates tokens and injects headers.
- Service filter calls `/authz/decide` on protected routes.
- Unit tests for allow/deny and tenant mismatch.
- Audit + OTel wired; latency p95 < 25ms for `/authz/decide` with cache hits.

See also the sequence diagram: Auth - Backend RBAC Enforcement (draw.io).