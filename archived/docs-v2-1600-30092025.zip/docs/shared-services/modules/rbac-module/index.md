# RBAC Module

Centralized authorization facade built on top of AWS Verified Permissions (AVP). Provides tenant-aware, default-deny, policy-driven access decisions.

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational)
![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 25-Aug-2025](https://img.shields.io/badge/Last_Updated-25--Aug--2025-lightgrey)

---

!!! info "Purpose"
    Provide a consistent authorization layer for all apps and services. Ensure every action on every resource is checked against policy, with caching and entitlements snapshots for UI.

!!! warning "Blunt truth"
    If RBAC is bypassed or inconsistently applied, tenant isolation is broken and compliance is out the window.

---

## Design Goals
- Default-deny authorization decisions.
- Tenant-aware, context-driven policies.
- Cached decisions with short TTLs + event-driven invalidation.
- Provide both point-in-time decision API and entitlements snapshot API.
- Integrate with Auth Module + Host DB user provisioning.

## Core Components
- RBAC Facade: `/authz/decide`, `/authz/entitlements` endpoints.
- Policy Engine: backed by AWS Verified Permissions (Cedar).
- Cache Layer: short TTL + purge on entitlement changes.
- Provisioner: sync user-role-policy relationships from Host DB.
- Audit Hooks: every decision logged with context.

---

## APIs at a glance
- `POST /authz/decide` → `{ principal, action, resource, context }` → `{ decision, ttlMs }`
- `GET /authz/entitlements?tenant=TEN-123&app=finance`
- Events: `ENTITLEMENTS_CHANGED`, `USER_STATUS_CHANGED`

---

## Failure Modes
- AVP unavailable → serve cached decisions ≤10m, log degraded mode.
- Cache stale → entitlements snapshot forces refresh.
- Misconfigured policy → deny by default, emit alert.

---

## Observability & SLOs
- Metrics: decision latency P95 < 20 ms (cached), < 120 ms (cold).
- Events: `rbac_decision_failure`, `rbac_cache_stale`.
- Audit: every decision outcome logged.

---

## Roadmap
- Phase 0: Decision API + cache + snapshot API.
- Phase 1: Tenant-scoped policy sets; dynamic context attributes.
- Phase 2: Delegated admin policy management.
- Phase 3: Policy versioning + diff tooling.

---

## References
- Auth Module → `/platform/shared_services_system/modules/auth-module/`
- Audit Module → `/platform/shared_services_system/modules/audit-module/`

---

### Acceptance Criteria (MVP)
- All protected APIs call `/authz/decide` before execution.
- Entitlements snapshot drives UI route guards.
- Cache purges on `ENTITLEMENTS_CHANGED` events.
- Every decision logged and queryable in Audit.