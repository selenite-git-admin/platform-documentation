# API - Notification Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/notification-module-apis.csv') }}

---

## Operations

---

### send_email
**Method/Path:** `POST /notify/send_email`  
**Purpose:** Send email using a template.

**Request**
```json
{"to": ["user@example.com"], "template": "verify", "vars": {"code": "123456"}}
```
**Response**
```json
{"ok": True, "messageId": "em_123"}
```

---

### send_sms
**Method/Path:** `POST /notify/send_sms`  
**Purpose:** Send SMS message.

**Request**
```json
{"to": "+15551234567", "text": "Your OTP is 123456"}
```
**Response**
```json
{"ok": True, "messageId": "sms_123"}
```

---

### send_chat
**Method/Path:** `POST /notify/send_chat`  
**Purpose:** Send Slack/Teams message.

**Request**
```json
{"channel": "#alerts", "text": "Deployment complete"}
```
**Response**
```json
{"ok": True, "messageId": "chat_123"}
```

---

### send_batch
**Method/Path:** `POST /notify/send_batch`  
**Purpose:** Batch send messages.

**Request**
```json
{"items": [{"type": "email", "to": "a@x.com", "template": "verify", "vars": {"code": "111111"}}]}
```
**Response**
```json
{"ok": True, "accepted": 1}
```