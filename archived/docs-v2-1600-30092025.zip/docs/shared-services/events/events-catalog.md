# Events Catalog - Shared Services

Standard events emitted across modules.

| Module    | Event Type                  | Payload (core fields) |
|-----------|-----------------------------|-----------------------|
| Auth      | `auth.logged_in`            | tenantId, userId, method, ts |
| RBAC      | `rbac.policy_denied`        | tenantId, userId, resource, ts |
| Secrets   | `secrets.rotated`           | tenantId, secretId, version, ts |
| Audit     | `audit.recorded`            | tenantId, recordId, actor, ts |
| Scheduler | `scheduler.job_completed`   | tenantId, jobId, state, durationMs |
| Messaging | `bus.event_published`       | tenantId, topic, offset, ts |