# Migrations (Template)

> One migration per section; include down step.

---
## 0001_rbac_policy_set.sql
**up**
```sql
CREATE TABLE rbac_policy_set (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  name text NOT NULL,
  version integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE (tenant_id, name, version)
);
```

**down**
```sql
DROP TABLE IF EXISTS rbac_policy_set;
```
---
## 0002_gateway_limit.sql
**up**
```sql
CREATE TABLE gateway_limit (
  id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  rate_rpm integer NOT NULL,
  burst integer NOT NULL,
  quota_daily integer NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX ON gateway_limit (tenant_id);
```

**down**
```sql
DROP TABLE IF EXISTS gateway_limit;
```