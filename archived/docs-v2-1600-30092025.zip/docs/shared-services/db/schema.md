# Schema - Shared Services (PostgreSQL DDL)

**Target:** PostgreSQL 15+ • Timezone: UTC • Schema: `shared_services`  
**Assumptions:** `pgcrypto` extension available for `gen_random_uuid()` (or set UUIDs from app).

> Copy/paste sections as needed. Keep tables minimal; prefer managed services where possible.

---

## Bootstrap (schema + extension)

```sql
-- Create schema and required extension (safe if already present)
CREATE SCHEMA IF NOT EXISTS shared_services;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
```

---

## RBAC - Policy Sets (metadata, versions)

```sql
-- RBAC policy sets; the actual Cedar/JSON policy text is stored per version.
CREATE TABLE IF NOT EXISTS shared_services.rbac_policy_set (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid        NOT NULL,
  name            text        NOT NULL,         -- logical policy set name (e.g., "core")
  version         integer     NOT NULL CHECK (version > 0),
  policy_format   text        NOT NULL CHECK (policy_format IN ('cedar','json','rego')),
  policy_text     text        NOT NULL,         -- Cedar/JSON string
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name, version)
);
```

```sql
-- Handy view to fetch the latest version per (tenant_id, name)
CREATE OR REPLACE VIEW shared_services.v_rbac_policy_set_latest AS
SELECT DISTINCT ON (tenant_id, name)
  tenant_id, name, id, version, policy_format, policy_text, created_at, updated_at
FROM shared_services.rbac_policy_set
ORDER BY tenant_id, name, version DESC;

COMMENT ON TABLE  shared_services.rbac_policy_set IS 'Versioned RBAC policy sets (Cedar/JSON strings).';
COMMENT ON COLUMN shared_services.rbac_policy_set.tenant_id IS 'Foreign key to external Tenants (logical).';
```

---

## Gateway - Limits & Quotas

```sql
CREATE TABLE IF NOT EXISTS shared_services.gateway_limit (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid        NOT NULL,
  rate_rpm        integer     NOT NULL CHECK (rate_rpm >= 0),
  burst           integer     NOT NULL CHECK (burst >= 0),
  quota_daily     integer     NOT NULL CHECK (quota_daily >= 0),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ix_gateway_limit_tenant ON shared_services.gateway_limit (tenant_id);
COMMENT ON TABLE shared_services.gateway_limit IS 'Per-tenant API limits/quotas enforced at Gateway.';
```

---

## Secrets - References (values live in Vault/KMS)

```sql
CREATE TABLE IF NOT EXISTS shared_services.secret_ref (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        uuid        NOT NULL,
  name             text        NOT NULL,                 -- logical secret name, e.g., db/password
  labels           jsonb       NOT NULL DEFAULT '{}'::jsonb,
  current_version  integer     NOT NULL CHECK (current_version >= 1),
  created_at       timestamptz NOT NULL DEFAULT now(),
  rotates_at       timestamptz,
  UNIQUE (tenant_id, name)
);

CREATE INDEX IF NOT EXISTS ix_secret_ref_tenant ON shared_services.secret_ref (tenant_id);
COMMENT ON TABLE shared_services.secret_ref IS 'References to secrets stored in KMS/Vault; metadata only.';
```

---

## Health - Maintenance Windows

```sql
CREATE TABLE IF NOT EXISTS shared_services.health_maintenance (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid,                           -- NULL = global maintenance
  active      boolean     NOT NULL DEFAULT false,
  window_from timestamptz,
  window_to   timestamptz,
  reason      text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  CHECK (window_from IS NULL OR window_to IS NULL OR window_to > window_from)
);

CREATE INDEX IF NOT EXISTS ix_health_maintenance_active ON shared_services.health_maintenance (active);
```

---

## IDs - Correlation IDs (optional helper)

```sql
CREATE TABLE IF NOT EXISTS shared_services.id_correlation (
  correlation_id text PRIMARY KEY,            -- e.g., 'CORR-20250826-abc123'
  created_at     timestamptz NOT NULL DEFAULT now(),
  expires_at     timestamptz
);

CREATE INDEX IF NOT EXISTS ix_id_correlation_expires_at ON shared_services.id_correlation (expires_at);
```

---

## (Optional) Events Outbox - reliable publish pattern

```sql
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'outbox_status') THEN
    CREATE TYPE shared_services.outbox_status AS ENUM ('pending','published','failed');
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS shared_services.events_outbox (
  id           bigserial PRIMARY KEY,
  topic        text        NOT NULL,
  key          text,
  payload      jsonb       NOT NULL,
  status       shared_services.outbox_status NOT NULL DEFAULT 'pending',
  created_at   timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz
);

CREATE INDEX IF NOT EXISTS ix_events_outbox_status ON shared_services.events_outbox (status, created_at);
```

---

## Privileges (example)

```sql
-- GRANT USAGE ON SCHEMA shared-services TO app_role;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA shared-services TO app_role;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA shared-services GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_role;
```