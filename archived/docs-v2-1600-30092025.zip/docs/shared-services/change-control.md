# Change Control - Shared Services

- APIs: Semver enforced; breaking changes require migration notes + approval.  
- Features: All features tracked in module CSVs with status/priority.  
- Events: New event types require schema + consumer impact review.  
- Ownership: Module owners sign off; security reviews mandatory.  
- Automation: CI runs contract tests on all modules.