# Host App — Information Architecture

## Global Navigation
Dashboard, Contracts, Tenants, Reference Data, Audit, Settings

## Local Navigation
Module tabs, contextual links (Tenant → Contracts → Evidence)

## Search & Discovery
Search across tenants, contracts, versions, evidence
