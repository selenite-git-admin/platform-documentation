# Non Functional Requirements
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI System - Non-Functional Requirements

## 1. Availability & Reliability
- [NFR-AVL-01] The KPI execution engine shall provide ≥ 99.5% uptime per tenant per month.  
- [NFR-AVL-02] The Admin Dashboard and APIs shall provide ≥ 99.9% uptime.  
- [NFR-AVL-03] All KPI runs shall be logged in append-only mode; no run event may be deleted or overwritten.  
- [NFR-AVL-04] SLA states (pass, warn, breach) shall be recorded for 100% of runs.

---

## 2. Performance & Latency
- [NFR-PERF-01] Interactive KPI Calls shall respond within 3 seconds at P95 latency.  
- [NFR-PERF-02] Batch KPI jobs shall complete within 5 minutes of scheduled SLA window for 95% of runs.  
- [NFR-PERF-03] Monitoring views (`vw_kpi_run_overview`, `vw_kpi_validation_summary`) shall refresh within 2 minutes of job completion.  

---

## 3. Scalability
- [NFR-SCAL-01] The system shall support 1000+ KPI runs per hour per tenant.  
- [NFR-SCAL-02] The system shall horizontally scale via serverless infra (ECS Fargate / Lambda).  
- [NFR-SCAL-03] KPI Call caching shall support 100k+ cached queries per tenant.  

---

## 4. Security
- [NFR-SEC-01] Tenant data shall be isolated via IAM roles and DB schema separation or row-level security.  
- [NFR-SEC-02] All KPI outputs shall be encrypted at-rest (KMS) and in-transit (TLS 1.2+).  
- [NFR-SEC-03] Every API request shall require OIDC/Cognito token authentication.  
- [NFR-SEC-04] Policy enforcement (ABAC/RBAC) shall be mandatory for every KPI Call.  
- [NFR-SEC-05] Masking/aggregation obligations shall be applied before data leaves the system.  

---

## 5. Cost Efficiency
- [NFR-COST-01] The system shall prioritize serverless pay-per-use components to scale to zero when idle.  
- [NFR-COST-02] KPI runs shall be optimized to SQL pushdown where possible to minimize infra cost.  
- [NFR-COST-03] KPI result caching shall reduce repeated execution costs by at least 50%.  

---

## 6. Auditability & Compliance
- [NFR-AUD-01] 100% of KPI runs, validations, SLA checks, and admin actions shall be logged.  
- [NFR-AUD-02] Audit logs shall be immutable and stored in append-only form for ≥ 1 year.  
- [NFR-AUD-03] The system shall generate audit bundles on request (KPI contract, version, lineage, run logs).  
- [NFR-AUD-04] The system shall be designed for SOC 2 Type II and ISO 27001 compliance.  
- [NFR-AUD-05] Personal or sensitive data in KPI sources shall be handled per GDPR guidelines (right to audit, right to delete).  

---

## 7. Observability
- [NFR-OBS-01] KPI jobs shall emit metrics (duration, SLA status, error counts) to CloudWatch/Grafana.  
- [NFR-OBS-02] Every KPI Call shall be traceable via unique request ID (linked across logs and audit).  
- [NFR-OBS-03] Dashboards shall show health by KPI, pack, tenant, and SLA compliance trend.  

---

## 8. Maintainability
- [NFR-MAINT-01] All KPI definitions shall be stored as Git-friendly artifacts (YAML/JSON).  
- [NFR-MAINT-02] Deployment of KPI definitions shall follow CI/CD workflows.  
- [NFR-MAINT-03] Canary releases and rollbacks shall be supported via Admin Dashboard.  
- [NFR-MAINT-04] Content drift (Git vs DB state) shall be detectable and alerted.  

---

## 9. Constraints
- [NFR-CON-01] Phase 1 deployment shall be AWS-first (EventBridge, Step Functions, ECS Fargate, RDS/Redshift, DynamoDB).  
- [NFR-CON-02] Initial workloads are batch and near-real-time; true streaming deferred.  
- [NFR-CON-03] Each tenant shall be deployed in a single AWS region; cross-region DR deferred.  

---

## 10. Traceability
Each NFR `[NFR-XXX-YY]` shall map to:  
- Framework doc reference (design justification).  
- Test case ID (performance, load, security, compliance).  
- Monitoring metric (for observability & SLA dashboards).  

Traceability will be maintained in `traceability-matrix.md`.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None