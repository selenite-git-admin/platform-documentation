# Kpi Data Model
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Define canonical entities and relationships for the KPI/GDP layers used by reporting and analytics.  
- Scope: Includes entity catalog, keys, relationships, and ERD notes. Excludes BI visuals and pipeline mechanics.  
- Target Readers: Data modelers, BI developers, functional consultants.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI System - Data Model

This document specifies the logical data model for the KPI System, including entities, relationships, and schemas.  
It provides a DBML ERD for diagramming and a canonical table/column specification for implementation.

> Diagram placeholders:
> - ERD SVG → `../assets/diagrams/kpi-system-erd.svg`
> - Flow SVG → `../assets/diagrams/kpi-system-data-flow.svg`

---

## 1. Core Entities (overview)

- KPI Contract - human/semantic definition (business meaning, sourcing, extensions, validations). Versioned.  
- KPI Version - immutable snapshot of the contract with semantic versioning and lifecycle state.  
- KPI Job - operational config for scheduling & SLA (authoring artifact -> runtime binding).  
- KPI Run - a single execution instance (inputs, outputs, status, timings, SLA state).  
- Validation Result - pre/post validation outcomes per run.  
- Lineage Edge - dependency graph edges (GDP → KPI, KPI → KPI).  
- SLA Policy - expectations (freshness, latency, availability) bound to versions/jobs.  
- Change Request - governance record for version promotions & edits.  
- Policy Binding - link between tenant policy versions and KPI versions.  
- Result Materialization / Cache - persisted outputs (tables/partitions) and cache registry.  
- Alert/Report - notifications and scheduled reports linked to runs and SLA state.

---

## 2. DBML (ERD)

```dbml
Project KPISystem {
  database_type: "postgres"
  note: "Logical ERD for KPI System"
}

Table kpi_contract {
  id                varchar [pk] // e.g., 'CFO-AR-DSO'
  name              varchar
  description       text
  domain_pack       varchar // e.g., CFO
  sensitivity       varchar // public|internal|restricted|confidential
  owners_business   varchar[]
  owners_technical  varchar[]
  created_at        timestamptz
  updated_at        timestamptz
  is_active         boolean
  note: 'Human/semantic container'
}

Table kpi_version {
  id                bigserial [pk]
  kpi_id            varchar [ref: > kpi_contract.id]
  contract_version  varchar // semver e.g., 1.2.0
  status            varchar // Draft|Proposed|Approved|Active|Deprecated|Retired
  artifact_yaml     text    // normalized artifact at publish time
  checksum          varchar // content hash for drift detection
  created_by        varchar
  created_at        timestamptz
  approved_by       varchar
  approved_at       timestamptz
  deprecated_at     timestamptz
  retired_at        timestamptz
  idx_kpi_ver       varchar // e.g., 'CFO-AR-DSO@1.2.0' (unique)
  unique: "uniq_kpi_ver" (kpi_id, contract_version)
  note: 'Immutable snapshot of contract'
}

Table kpi_job {
  id                bigserial [pk]
  kpi_version_id    bigint  [ref: > kpi_version.id]
  schedule_cron     varchar
  trigger_type      varchar // time|event|hybrid
  sla_id            bigint  [ref: > kpi_sla.id]
  retries           int
  retry_backoff_s   int
  is_enabled        boolean
  created_at        timestamptz
  updated_at        timestamptz
  note: 'Runtime binding for orchestration'
}

Table kpi_sla {
  id                bigserial [pk]
  freshness_minutes int
  latency_p95_ms    int
  availability_pct  numeric(5,2)
  breach_policy     varchar // alert-only|fallback|halt
  created_at        timestamptz
  updated_at        timestamptz
}

Table kpi_run {
  id                bigserial [pk]
  run_uid           varchar  // public id like 'run_01J12...'
  kpi_version_id    bigint   [ref: > kpi_version.id]
  started_at        timestamptz
  ended_at          timestamptz
  status            varchar  // success|failed|partial
  sla_state         varchar  // pass|warn|breach
  scd_view          varchar  // as_reported|restated
  request_json      jsonb    // full KPI Call request
  result_meta_json  jsonb    // shape, columns, applied_extensions, masking
  error_code        varchar
  error_message     text
  triggered_by      varchar  // scheduler|api|event
  tenant_id         varchar
  trace_id          varchar
  created_at        timestamptz
  index: "idx_run_kpi" (kpi_version_id, started_at)
  index: "idx_run_trace" (trace_id)
  unique: "uniq_run_uid" (run_uid)
}

Table kpi_run_validation {
  id                bigserial [pk]
  run_id            bigint   [ref: > kpi_run.id]
  phase             varchar  // pre|post
  rule_id           varchar
  rule_type         varchar  // completeness|freshness|variance|plausibility|cross_kpi
  status            varchar  // pass|warn|fail
  details_json      jsonb
  created_at        timestamptz
  index: "idx_val_run" (run_id, phase)
}

Table kpi_lineage_edge {
  id                bigserial [pk]
  kpi_version_id    bigint   [ref: > kpi_version.id]
  from_type         varchar  // gdp|kpi
  from_ref          varchar  // table name or kpi@version
  to_type           varchar  // kpi
  to_ref            varchar  // kpi@version
  relation          varchar  // depends_on|derived_from
  created_at        timestamptz
  index: "idx_lineage_to" (kpi_version_id)
}

Table kpi_change_request {
  id                bigserial [pk]
  kpi_id            varchar   [ref: > kpi_contract.id]
  requested_by      varchar
  requested_at      timestamptz
  proposed_action   varchar   // create|update|deprecate|retire|republish
  diff_json         jsonb
  criticality       varchar   // low|medium|high
  status            varchar   // pending|approved|rejected|executed
  approver_tech     varchar
  approver_bus      varchar
  decided_at        timestamptz
  executed_at       timestamptz
  note: 'Lifecycle governance object'
}

Table kpi_policy_binding {
  id                bigserial [pk]
  kpi_version_id    bigint   [ref: > kpi_version.id]
  policy_version    varchar
  obligations_json  jsonb   // default obligations (masking, grain caps)
  created_at        timestamptz
  unique: "uniq_kpi_policy" (kpi_version_id, policy_version)
}

Table kpi_result_registry {
  id                bigserial [pk]
  kpi_version_id    bigint   [ref: > kpi_version.id]
  storage_ref       varchar  // table/partition path
  partition_key     varchar  // e.g., month, quarter
  last_materialized timestamptz
  row_count         bigint
  checksum          varchar
  created_at        timestamptz
  updated_at        timestamptz
  index: "idx_result_kpi" (kpi_version_id, partition_key)
}

Table kpi_cache_registry {
  id                bigserial [pk]
  cache_key         varchar   // hash of KPI Call request
  kpi_version_id    bigint    [ref: > kpi_version.id]
  created_at        timestamptz
  expires_at        timestamptz
  storage_ref       varchar
  hit_count         int
  index: "idx_cache_key" (cache_key)
}

Table kpi_alert {
  id                bigserial [pk]
  run_id            bigint   [ref: > kpi_run.id]
  alert_type        varchar  // sla_breach|validation_fail|exec_fail
  severity          varchar  // info|warn|critical
  message           text
  routed_channels   varchar[] // slack|email|opsgenie
  created_at        timestamptz
  index: "idx_alert_run" (run_id, alert_type)
}

Ref: kpi_version.kpi_id > kpi_contract.id
Ref: kpi_job.kpi_version_id > kpi_version.id
Ref: kpi_run.kpi_version_id > kpi_version.id
Ref: kpi_run_validation.run_id > kpi_run.id
Ref: kpi_lineage_edge.kpi_version_id > kpi_version.id
Ref: kpi_change_request.kpi_id > kpi_contract.id
Ref: kpi_policy_binding.kpi_version_id > kpi_version.id
Ref: kpi_result_registry.kpi_version_id > kpi_version.id
Ref: kpi_cache_registry.kpi_version_id > kpi_version.id
Ref: kpi_alert.run_id > kpi_run.id
```

---

## 3. Table Specifications

### 3.1 `kpi_contract`
- Purpose: Top-level KPI identity and semantics.  
- Key fields: `id`, `sensitivity`, `owners_*`.  
- Notes: Contracts link to many versions; `is_active` indicates business status (separate from version state).

### 3.2 `kpi_version`
- Purpose: Immutable snapshot of contract.  
- Key fields: `contract_version`, `status`, `artifact_yaml`, `checksum`.  
- Constraints: Unique per (`kpi_id`,`contract_version`).

### 3.3 `kpi_job`
- Purpose: Runtime schedule/bindings for a specific version.  
- Key fields: `schedule_cron`, `trigger_type`, `sla_id`, `retries`.  
- Notes: Decouples authoring from runtime; enables canary (multiple jobs per version).

### 3.4 `kpi_sla`
- Purpose: SLA expectations.  
- Key fields: `freshness_minutes`, `latency_p95_ms`, `availability_pct`, `breach_policy`.

### 3.5 `kpi_run`
- Purpose: Execution instance.  
- Key fields: `run_uid`, `status`, `sla_state`, `request_json`, `result_meta_json`, `trace_id`.  
- Notes: Append-only; errors captured inline for fast diagnosis.

### 3.6 `kpi_run_validation`
- Purpose: Validation outcomes (pre/post).  
- Key fields: `phase`, `rule_id`, `rule_type`, `status`, `details_json`.

### 3.7 `kpi_lineage_edge`
- Purpose: DAG edges for lineage/impact.  
- Key fields: `from_type`, `from_ref`, `to_ref`, `relation`.

### 3.8 `kpi_change_request`
- Purpose: Governance record for lifecycle/version changes.  
- Key fields: `proposed_action`, `diff_json`, `criticality`, `status`, `approver_*`.

### 3.9 `kpi_policy_binding`
- Purpose: Bind tenant policy to KPI version.  
- Key fields: `policy_version`, `obligations_json` (default obligations).

### 3.10 `kpi_result_registry`
- Purpose: Tracks materialized results in data store.  
- Key fields: `storage_ref`, `partition_key`, `last_materialized`, `row_count`, `checksum`.

### 3.11 `kpi_cache_registry`
- Purpose: Caches KPI Call results.  
- Key fields: `cache_key`, `expires_at`, `storage_ref`, `hit_count`.

### 3.12 `kpi_alert`
- Purpose: Alert events linked to runs.  
- Key fields: `alert_type`, `severity`, `routed_channels`, `message`.

---

## 4. Indices & Access Patterns

- Recent runs per KPI: index (`kpi_version_id`, `started_at`) on `kpi_run`.  
- Trace lookup: index (`trace_id`) on `kpi_run`.  
- Validation drilldown: index (`run_id`, `phase`) on `kpi_run_validation`.  
- Lineage fan-out: index on `kpi_version_id` in `kpi_lineage_edge`.  
- Materialization: index (`kpi_version_id`, `partition_key`) in `kpi_result_registry`.  
- Cache hits: index (`cache_key`) in `kpi_cache_registry`.  

---

## 5. Multi-tenant Posture

- Option A (preferred): Per-tenant schema (`kpi_<tenant>.*`) with shared physical cluster.  
- Option B: Single schema with RLS on every table by `tenant_id` (must add `tenant_id` to tables).  
- Tenant-scoped KMS keys & IAM roles control access at the data plane.

---

## 6. Event Model (outbound)

Emitted on major lifecycle and runtime events (to SNS/EventBridge, then webhooks):  
- `kpi.version.published` - payload includes `kpi_id`, `contract_version`.  
- `kpi.run.completed` - includes `run_uid`, `status`, `sla_state`, `policy_version`.  
- `kpi.run.failed` - includes `error_code`, `error_message`.  
- `kpi.sla.breach` - includes breach dimension, duration, impacted packs.  
- `kpi.change_request.pending` - for approval queues.

---

## 7. Data Retention

- Runs & validations: minimum 13 months online, archive to S3 after.  
- Audit logs: ≥ 1 year immutable store.  
- Cache entries: TTL configurable (default 24–72h).  
- Materializations: per KPI policy (daily/weekly/period-close partitions).

---

## 8. Open Questions / TBD

- Should `kpi_run` include a normalized resource usage metric (cpu/mem/rows scanned) for cost analytics?  
- Do we need a `kpi_sensitivity_policy_history` table to track label changes over time?  
- Add `kpi_verdict` entity for anomaly/scoring outputs? (post-validation extensions)

---

## 9. How to Generate the ERD

Use the DBML above in any DBML-compatible tool (dbdiagram.io, community CLI) to export SVG and save to:  
`../assets/diagrams/kpi-system-erd.svg`

---


---

## Diagrams

None

## Tables

None



## Glossary

None