# Kpi Screens And Features
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe user‑facing screens and features of the KPI System.  
- Scope: Includes UX intents, states, and field definitions. Excludes visual brand/creative guidelines.  
- Target Readers: Product, UX, frontend engineers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI System - Screens & Features

This document specifies the Admin Dashboard screens and their features for the KPI System.  
It provides a structured, screenwise breakdown to guide UI/UX design, development, and QA.

---

## 1. Catalog View

### Purpose
Entry point for KPI browsing, search, and quick health checks.

### Features
- [UI-CAT-01] List KPIs with columns: ID, Name, Domain Pack, Status, Current Version, Sensitivity, SLA Health, Last Run.  
- [UI-CAT-02] Search by KPI ID, Name, Tags.  
- [UI-CAT-03] Filters: Domain Pack, Status, SLA compliance (pass/warn/breach), Sensitivity.  
- [UI-CAT-04] Quick actions: View details, Export metadata, Pause/Resume, Open Change Request.  
- [UI-CAT-05] Pagination and sorting (by status, SLA health, last run).  

### Wireframe Placeholder
`../assets/diagrams/ui-kpi-catalog.png`

---

## 2. KPI Detail Screen

### Purpose
Provide a comprehensive view of a single KPI, with tabs for drilldown.

### Tabs & Features
- Overview  
  - [UI-DET-01] Show KPI name, description, owners, sensitivity.  
  - [UI-DET-02] Show current version, SLA summary, recent runs (sparkline).  
  - [UI-DET-03] Quick actions: Publish, Pause/Resume, Rollback.  

- Versions  
  - [UI-DET-04] List versions (semver), status, created/approved dates, checksums.  
  - [UI-DET-05] Diff between two versions.  

- Sourcing  
  - [UI-DET-06] Show GDP/KPI inputs and lineage graph.  
  - [UI-DET-07] Show sourcing validation rules.  

- Validation  
  - [UI-DET-08] Show pre-validation and post-validation rules applied.  
  - [UI-DET-09] Show latest validation results with pass/warn/fail.  

- Schedule & SLA  
  - [UI-DET-10] Show/edit schedule (cron/event/hybrid).  
  - [UI-DET-11] Show/edit SLA thresholds (freshness, latency, availability).  

- Lineage  
  - [UI-DET-12] Interactive DAG view (GDP → KPI → KPI).  

- Monitoring  
  - [UI-DET-13] Recent runs overview with SLA states.  
  - [UI-DET-14] Drill into specific run detail (link to Logs API).  

- Alerts  
  - [UI-DET-15] Configure alert routing (Slack, Email, Opsgenie).  
  - [UI-DET-16] View active alerts and history.  

- Audit  
  - [UI-DET-17] Show all admin actions with timestamp, user, reason.  

### Wireframe Placeholder
`../assets/diagrams/ui-kpi-detail.png`

---

## 3. Change Request Queue

### Purpose
Governance control for lifecycle transitions and updates.

### Features
- [UI-CRQ-01] List pending change requests with: KPI ID, Proposed Action, Criticality, Requester, Timestamp.  
- [UI-CRQ-02] Show diff of proposed changes (artifact diff, sourcing diff).  
- [UI-CRQ-03] Approve/Reject with comments; dual approval required for critical changes.  
- [UI-CRQ-04] Filter by status (Pending, Approved, Rejected, Executed).  
- [UI-CRQ-05] Export history of change requests.  

### Wireframe Placeholder
`../assets/diagrams/ui-kpi-change-requests.png`

---

## 4. Rollout & Promotion Dashboard

### Purpose
Enable canary releases, environment promotion, and rollbacks.

### Features
- [UI-ROL-01] Show active rollouts (tenant/env, KPI version).  
- [UI-ROL-02] Metrics: success rate, error distribution, SLA breaches.  
- [UI-ROL-03] Promote from staging → prod with approval workflow.  
- [UI-ROL-04] Rollback to previous version (with reason).  
- [UI-ROL-05] Canary status (control vs test group metrics).  

### Wireframe Placeholder
`../assets/diagrams/ui-kpi-rollout.png`

---

## 5. Incident & SLA Dashboard

### Purpose
Central view of KPI reliability, SLA compliance, and incidents.

### Features
- [UI-INC-01] SLA compliance trendline per KPI/pack/tenant.  
- [UI-INC-02] Active SLA breaches, categorized by error type.  
- [UI-INC-03] MTTR (mean time to resolve) metrics.  
- [UI-INC-04] Open incidents list with assigned owner.  
- [UI-INC-05] Export incident/SLA compliance report.  

### Wireframe Placeholder
`../assets/diagrams/ui-kpi-incidents.png`

---

## 6. User & Policy Management (Optional Phase 2)

### Purpose
Manage roles, policies, and obligations in the Admin Dashboard.

### Features
- [UI-POL-01] View current tenant policy (JSON/Cedar/Rego).  
- [UI-POL-02] Edit/update policies via CR workflow.  
- [UI-POL-03] Run policy simulator (dry-run with sample user/resource).  
- [UI-POL-04] Export policy version history.  

### Wireframe Placeholder
`../assets/diagrams/ui-kpi-policy.png`

---

## 7. Mapping to APIs

- Catalog → `GET /admin/kpis`  
- Detail (Overview, Versions, etc.) → `GET /metadata/kpis/{kpi_id}`, `GET /logs/runs`  
- Change Requests → `POST /admin/change-requests`, `GET /admin/change-requests`  
- Rollout → `POST /admin/kpis/{id}/versions/{ver}/publish|rollback`  
- SLA & Monitoring → `GET /monitoring/views/vw_kpi_run_overview`  
- Alerts → `POST /admin/kpis/{id}/alerts`  
- Audit → `GET /logs/audit`  
- Policy Mgmt → `GET/PUT /policy`, `POST /policy/simulate`  

---

## 8. Traceability

Each UI feature `[UI-XXX-YY]` maps to:  
- Functional Requirement(s) in `functional-requirements.md`  
- APIs in `apis.md`  
- Data model entities in `data-model.md` (where applicable)  
- Test cases in QA suite  

Traceability is captured in `traceability-matrix.md`.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None