# Tech Stack

[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025--08--24](https://img.shields.io/badge/Last%20Updated-2025--08--24-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

[![Author: Anant Kulkarni](https://img.shields.io/badge/Author-Anant%20Kulkarni-06b6d4?style=flat-square&labelColor=111827&color=06b6d4)](#)
[![Owner: KPI Platform Team](https://img.shields.io/badge/Owner-KPI%20Platform%20Team-3b82f6?style=flat-square&labelColor=111827&color=3b82f6)](#)

---

## Runtime & Orchestration
- Python workers with task orchestration (Airflow/Prefect) for scheduling and retries.  
- Containerized execution (Docker, Fargate/K8s).  

## Datastore
- Postgres for definitions + metadata.  
- Columnar warehouse (Snowflake/Redshift/BigQuery) for KPI results.  
- Object storage for logs and snapshots.  

## APIs & Serving
- REST + GraphQL APIs with OpenAPI specs.  
- Semantic layer exposed via Power BI/SSAS or dbt metrics.  

## Observability
- Central logging (ELK/CloudWatch).  
- Metrics & traces (Prometheus, OpenTelemetry).  

## Security
- JWT/OAuth2 for API calls.  
- Secrets managed via Vault/Secrets Manager.  
