# KPI Architecture
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

[![Author: Anant Kulkarni](https://img.shields.io/badge/Author-Anant%20Kulkarni-06b6d4?style=flat-square&labelColor=111827&color=06b6d4)](#)
[![Owner: KPI Platform Team](https://img.shields.io/badge/Owner-KPI%20Platform%20Team-3b82f6?style=flat-square&labelColor=111827&color=3b82f6)](#)

---

## Document Information
- Purpose: Explain the KPI System architecture and how layers interact to deliver KPIs end-to-end.
- Scope: Logical views, responsibilities, cross-cutting concerns. *Excludes* vendor-specific deployment steps.
- Target Readers: Enterprise/solution architects, senior developers, stakeholders.
- Dependencies: <List related docs>
- References: <List references>

---

## System Context (Architecture)
[![KPI System Context](../../assets/diagrams/kpi-system-context.svg)](../../assets/diagrams/kpi-system-context.svg)

(Figure A1: Subsystems, trust boundaries, and integration flows F1–F9)

---

## How it works (end-to-end)

**0) Author & approve contract (F2 → K1)**  
A KPI is a governed, versioned contract stored in the Authoring & Catalog (K1). It maps business meaning to GDP tables or other KPIs, plus extensions and validation rules. Approval in K1 makes the contract addressable by the scheduler and APIs.

**1) Resolve sourcing & dependencies (K1 → K2)**  
From the contract, the system derives a DAG (GDP → KPI → composite KPI). K1 passes schedule/event metadata to the Execution Engine (K2) (F3).

**2) Pre-validate inputs (F1 → K2)**  
Before a run, K2 pulls readiness/quality signals from Silver/GDP (Upstream) (F1).  
- Availability: sources exist for the requested range.  
- Freshness: upstream SLAs met.  
- Quality: null/constraint/reconciliation checks clear.  
If any check fails → run skipped, reason logged (F6) and alerted (F7).

**3) Execute the run (K2 → K3)**  
K2 executes idempotently (containerized workers, retries, backoff). On success, it writes results + lineage to the Datastore (K3) (F4). All runs emit logs/metrics/traces to Observability (F6) and record lineage/registry data as required.

**4) Serve results (Consumers ↔ K4)**  
Consumers (Dashboards, Packs, APIs/Agents) query the Public APIs (K4) (F5). Each response includes contract version, lineage pointers, and any anomaly/verdict flags.

**5) Security & policy on every call (F8)**  
All calls (authoring, execution, serving) enforce AuthN/Z and policy via Shared Services (F8). Secrets retrieval for workers is isolated.

**6) Admin operations (F9)**  
**Admin Dashboard** issues publish/pause/rollback to K2 (F9) and pushes tenant policies to K1. Platform Mgmt supplies deploy/env config to K2.

---

## Flow map (F1–F9)

| Flow | From → To | What happens | Success path | Failure / Skip |
|---|---|---|---|---|
| F1 | Upstream → K2 | Data readiness/quality signals | Proceed to execute | Skip run, log (F6), alert (F7) |
| F2 | Admin Dashboard → K1 | Create/approve contract | Contract version becomes active | Reject/pend; no scheduling |
| F3 | K1 → K2 | Schedule/event trigger | Worker started with run context | Queue retry/backoff |
| F4 | K2 → K3 | Persist results + lineage | Result set committed | Partial write rollback; incident |
| F5 | Consumers ↔ K4 | Query KPI results | 200 + data + metadata | 4xx/5xx; rate-limit; auth fail (F8) |
| F6 | K2/K4 → Observability | Logs/metrics/traces | Telemetry visible | N/A (best-effort with buffer) |
| F7 | K2 → Notifier | SLA breach/failure alerts | Stakeholders notified | N/A |
| F8 | K1/K2/K4 ↔ IAM/Policy | AuthN/Z & policy checks | Token/Scopes valid | 401/403; deny run/query |
| F9 | Admin Dashboard → K2 | Publish/Pause/Rollback ops | State changed; audit log | Denied by policy; conflict |

---

## Contracts, extensions, and calls (what devs implement)

- Contracts (K1): YAML/JSON/DB; include inputs, extensions (Time/Entity/Benchmark/Scenario), validation rules, and lifecycle state.  
- KPI Call (K4): Declarative query to fetch results with grain/range/filters; server resolves SCD view, applies extensions, and returns data + metadata (version, lineage, verdicts).  
- Idempotency: Contract hash + run window ensure repeatable outputs; re-runs attach to lineage.

---

## Failure & skip logic (encoded in K2)

- Pre-validation fail (F1): mark as *SKIPPED* with reason; notify (F7); no partial results.  
- Execution fail: retry policy, then DLQ/incident; metrics emitted (F6).  
- Post-validation fail: mark run *FAILED_VALIDATION*; suppress serving unless override policy says otherwise; alert.  
- SLA breach: emit *BREACH* event; alert with impacted KPIs and consumers.

---

## Security & policy checkpoints (F8)

- Authoring: contract create/approve requires role-based scopes.  
- Execution: per-tenant policies gate schedules, secrets, and upstream access.  
- Serving: query scopes (read:domain:pack, read:kpi:*), row/column policies if applicable.  
- Audit: every F8 decision logs actor, resource, policy, and outcome.

---

## Supporting Governance Frameworks
- KPI Layers - Primary (GDP), Secondary (KPI-on-KPI), Composite (indices); DAG execution rules.
- KPI Logging - Append-only run logs with lineage and delivery context.
- KPI Monitoring - SQL views + dashboards for run health, SLA, anomalies.
- KPI Error Handling - Error taxonomy (sourcing/validation/execution/rules/scheduler) with retry/fallback/escalation.
- KPI Alerts & Reports - Real-time alerts + scheduled packs/scorecards.
- KPI Versioning - Semantic versions + variants; impact analysis before breaking changes.

---

## Why this architecture
- Trust & auditability - Every result carries contract version, lineage, validations, lifecycle.
- Consistency > ad-hoc SQL - Contracts + calls prevent drift; extensions standardize analysis.
- Comparability - SCD + version catalog preserve trends through change.
- Operational excellence - SLA enforcement, logging, monitoring, alerts.
- Scale - SQL pushdown, caching, DAG-aware scheduling.

---

## Conceptual Flow (tie-back)
Author → Approve (F2) → Schedule/Trigger (F3) → Pre-validate (F1) → Execute → Persist (F4) → Serve (F5) → Telemetry (F6) → Alerts (F7) with F8 on every hop and F9 for admin control.

---

## Run Flow - Daily Net Sales

![KPI Run Flow - Daily Net Sales](../../assets/diagrams/kpi-run-flow-daily-net-revenue.svg)

(Figure A2: Steps map to context flows: F1 readiness, F3 trigger, F4 persist, F5 serve, F6 telemetry, F7 alerts, F8 auth/policy.)

## Roadmap
- v0.1: Core authoring and execution pipeline.
- v0.2: SLA monitoring + alerting.
- v0.3: Multi-tenant scalability and cross-system integrations.