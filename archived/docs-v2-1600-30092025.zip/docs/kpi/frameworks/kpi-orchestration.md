# Kpi Orchestration
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe KPI lifecycle orchestration, scheduling, and run-state management.  
- Scope: Includes DAGs, triggers, backfills, and failure handling. Excludes connector-specific ingest details.  
- Target Readers: Data engineers, SRE/ops, platform owners.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Orchestration Framework

## Purpose
The KPI Orchestration Framework defines how KPI jobs are executed, monitored, and scaled in the platform infrastructure.  
It bridges the logical contract layer (KPI Structure & Flow) with the physical execution layer (AWS-first design).  
This ensures KPIs run reliably, on schedule, at scale, and with SLA-backed governance.

---

## Assumptions (AWS First Phase)

- All tenants share one orchestration layer (multi-tenant aware).  
- KPI definitions are already governed and stored in metadata (contracts).  
- Initial workloads are batch and near-real-time, not true streaming.  
- KPI execution is stateless and containerized (no persistent state).  
- Primary data sources are RDS (Postgres/MySQL) and optionally Redshift.  
- Serverless-first approach (ECS Fargate, Step Functions, EventBridge) to minimize ops overhead.  

---

## Constraints

- Cost: Must prioritize pay-per-use serverless services to remain affordable for SMEs.  
- Database choice: Locked to RDS/Redshift in Phase 1 (no vendor flexibility per tenant).  
- SLA scope: Focus on daily/period-close KPIs; real-time SLA < 5s deferred to later phases.  
- Region: Single AWS region per tenant; no cross-region or multi-cloud in Phase 1.  
- Compliance: Only basic ISO/SOC logging in Phase 1; advanced compliance (GDPR/HIPAA) deferred.  

---

## Infra Components

### Execution Engine
- KPI jobs run as containers (ECS Fargate tasks or EKS pods).  
- Stateless execution, pulling configuration from KPI metadata.  
- Jobs compute KPI results, apply validations, and persist outputs.

### Scheduler & Triggers
- AWS EventBridge for cron/event triggers.  
- AWS Step Functions (or MWAA/Airflow) to orchestrate DAG dependencies.  
- SLA-aware orchestration (alerts when jobs exceed deadlines).  

### Storage & Data Access
- Bronze/Silver/Gold data in RDS or Redshift.  
- KPI results materialized in RDS/Redshift tables.  
- Staging data optionally stored in S3.  

### Logging & Monitoring
- Logs written to CloudWatch (infra) and DynamoDB (business-aware run logs).  
- Monitoring dashboards (Grafana, Quicksight) using SQL views (`vw_kpi_run_overview`, `vw_kpi_validation_summary`).  

### Error Handling & Retry
- Step Functions retry policies for transient failures.  
- Dead Letter Queues (SNS/SQS) for unrecoverable errors.  
- Error codes aligned with KPI Error Handling Framework.  

### Security & Multi-Tenancy
- Isolation via IAM roles and DB schemas.  
- Tenant context injected into every KPI run.  
- Encrypted storage (KMS) for results and logs.  

### Scalability
- ECS Fargate auto-scaling for KPI job containers.  
- ElastiCache (Redis) for KPI Call caching.  
- Horizontal scale: thousands of KPI runs per hour across tenants.  

---

## Non-Functional Requirements (NFRs)

- Availability: Orchestration platform ≥ 99.5% uptime.  
- Scalability: Support 1000+ KPI runs/hour per tenant with < 5m cold start.  
- Latency: KPI Calls return < 3s at P95.  
- Reliability: 100% of KPI runs logged with SLA outcome.  
- Security: Tenant isolation enforced at IAM + schema levels.  
- Cost Efficiency: Serverless-first; idle tenants incur near-zero cost.  
- Auditability: All KPI runs linked to contract + version in append-only logs.  

---

## Workflow: How a KPI Runs on AWS

```
EventBridge trigger (time/event) →
  Step Function DAG →
  ECS Fargate task (executes KPI job) →
  Reads GDP/KPI sources from RDS/Redshift →
  Applies pre-validation rules →
  Executes KPI expression →
  Applies post-validation rules →
  Writes results to KPI results table →
  Logs run in DynamoDB + CloudWatch →
  SLA check →
  If breach → SNS/SQS → Alerts & Escalation
```

---

## Diagrams (Placeholders)

- AWS Reference Architecture  
  ![KPI Orchestration AWS]#(../assets/diagrams/kpi-orchestration-aws.svg)

- KPI Orchestration Workflow  
  ![KPI Orchestration Workflow]#(../assets/diagrams/kpi-orchestration-workflow.svg)

---

## Why This Design

- Serverless-first – Low cost, minimal ops, scale to zero when idle.  
- Separation of concerns – KPI definition (contracts) decoupled from execution (orchestration).  
- Scalable & multi-tenant – Shared orchestration layer, tenant isolation in schema/IAM.  
- Reliable & auditable – SLA-aware orchestration, full logs, error handling, monitoring.  
- Future-proof – Real-time packs and AI-driven agents can plug into the same orchestration backbone.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None