# Kpi Monitoring
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Establish observability for the KPI System across logs, metrics, and traces.  
- Scope: Includes telemetry, alerting, SLOs, dashboards. Excludes business KPI definitions.  
- Target Readers: SRE/ops, platform owners, engineers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Monitoring Framework

## Purpose
The KPI Monitoring Framework provides real-time visibility into KPI health, SLA adherence, and validation results.  
It builds on the KPI Logging Framework by surfacing curated metrics, views, dashboards, and alerts for CFOs, business leaders, and technical operators.  

This ensures KPIs are not just executed and logged, but also continuously monitored, visualized, and governed.

---

## Core Concepts

- Views over Logs
  - Abstract raw log tables into compact, query-friendly SQL views.
  - Expose only the most relevant run, validation, lineage, and SLA fields.

- Dashboards
  - Executive dashboards → SLA compliance %, KPI health index, top failing KPIs.  
  - Operational dashboards → validation failures by rule type, retry success rates.  
  - Developer dashboards → SQL hash lineage, error distributions, runtime anomalies.  

- Alerting
  - SLA breaches → CFO office + ops.  
  - Validation failures → Data quality team.  
  - Runtime anomalies → Platform engineering.  

- Governance
  - Monitoring views enforce tenant-aware access controls.  
  - Metrics and definitions are published in a KPI dictionary for consistency.  

---

## SQL Views Layer

### 1. Run Overview
One row per run with verdicts, timings, SLA, and key metadata.

```sql
CREATE OR REPLACE VIEW vw_kpi_run_overview AS
SELECT
  r.run_id,
  r.tenant_id,
  r.environment,
  r.kpi_id,
  r.contract_version,
  r.variant_label,
  r.started_at,
  r.finished_at,
  EXTRACT(EPOCH FROM (r.finished_at - r.started_at))::BIGINT AS duration_sec,
  r.status,
  r.sla_breached,
  d.verdict,
  d.time_grain,
  d.time_range,
  d.extensions
FROM kpi_log_run r
LEFT JOIN kpi_log_delivery d ON d.run_id = r.run_id;
```

### 2. Validation Summary
Rollup of pre/post validation outcomes for quick health checks.

```sql
CREATE OR REPLACE VIEW vw_kpi_validation_summary AS
WITH pre AS (
  SELECT run_id,
         COUNT(*) FILTER (WHERE result='fail') AS pre_fail_count
  FROM kpi_log_pre_validation
  GROUP BY run_id
),
post AS (
  SELECT run_id,
         COUNT(*) FILTER (WHERE result='fail') AS post_fail_count
  FROM kpi_log_post_validation
  GROUP BY run_id
)
SELECT
  r.run_id,
  r.tenant_id,
  r.kpi_id,
  r.contract_version,
  r.status,
  COALESCE(pre.pre_fail_count,0) AS pre_fail_count,
  COALESCE(post.post_fail_count,0) AS post_fail_count
FROM kpi_log_run r
LEFT JOIN pre  ON pre.run_id  = r.run_id
LEFT JOIN post ON post.run_id = r.run_id;
```

### 3. Lineage Sources
Dependency view showing GDP tables and KPI references per run.

```sql
CREATE OR REPLACE VIEW vw_kpi_lineage_sources AS
SELECT
  r.run_id,
  r.tenant_id,
  r.kpi_id,
  r.contract_version,
  s.source_type,
  s.source_object,
  s.source_version
FROM kpi_log_run r
JOIN kpi_log_sourcing s ON s.run_id = r.run_id;
```

### 4. SLA Violations
Focused list of runs breaching SLA.

```sql
CREATE OR REPLACE VIEW vw_kpi_sla_violations AS
SELECT
  r.run_id,
  r.tenant_id,
  r.kpi_id,
  r.contract_version,
  r.started_at,
  r.finished_at,
  r.status,
  r.error_code,
  r.error_message
FROM kpi_log_run r
WHERE r.sla_breached = TRUE;
```

---

## Dashboards

- Executive View
  - SLA compliance rate (% of runs within SLA).  
  - KPI health index (weighted by failures, verdicts).  
  - Top failing KPIs (by failure count).  

- Ops View
  - Validation failure trends by rule type.  
  - Retry success/failure rates.  
  - Runs skipped due to pre-validation.  

- Dev View
  - Error code distribution.  
  - SQL hash diffs for lineage debugging.  
  - Run duration anomalies vs historical baseline.  

---

## Alerting Strategy

- SLA breach → high-severity alert to CFO office & ops channel.  
- Validation fail (hard stop) → medium-severity alert to data quality team.  
- Unusual runtime anomaly (duration, row count) → medium-severity alert to platform engineering.  
- Alerts include deep links to `vw_kpi_run_overview` and `vw_kpi_validation_summary`.  

---

## Governance & Operations

- Tenant Isolation
  - All monitoring views scoped by tenant; RLS enforced.  

- Retention & Archiving
  - Inherits logging retention policy (e.g., 24 months active, then cold archive).  

- Data Dictionary
  - Published definitions of monitoring fields (status, SLA, verdict) to avoid ambiguity.  

- Materialization
  - Heavy views (e.g., run overview) may be materialized in the warehouse for performance.  

---

## Why It Matters

- Transparency – KPIs aren’t black boxes; every run’s health is visible.  
- Trust – CFOs and auditors can inspect KPI monitoring dashboards as assurance.  
- Resilience – Ops teams can act on alerts before business impact grows.  
- Efficiency – BI dashboards bind to simple views instead of complex joins.  
- Future-Proof – Monitoring can expand with anomaly detection, ML scoring, or KPI reliability indices.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None