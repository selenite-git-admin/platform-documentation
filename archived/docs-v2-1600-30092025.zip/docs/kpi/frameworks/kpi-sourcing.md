# Kpi Sourcing
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Sourcing Framework

## Purpose
The KPI Sourcing Framework defines how every KPI in Cxofacts resolves its data sources.  
It ensures that KPIs always have a governed, transparent, and auditable mapping to either:
- Golden Data Points (GDPs) → reconciled facts and dimensions, or  
- Other KPIs → previously computed KPI outputs (for derived or ratio metrics).  

This creates a semantic bridge between business meaning and technical implementation, while enabling dependency management, impact analysis, and trust.

---

## Core Concepts

- Primary KPIs  
  Directly sourced from GDP tables.  
  Examples: Cash Balance, Receivables, Payables, Headcount.  

- Secondary KPIs  
  Derived from one or more other KPI outputs.  
  Examples: Liquidity Ratios, ROE, Gross Margin %, DSO.  

- Source Types  
  - `GDP` – facts and dimensions from GDP layer.  
  - `KPI` – contract IDs of upstream KPIs.  

- Contract Binding  
  Every KPI contract must declare its sources in a structured form (with lineage and version references).  

---

## Source Declaration (YAML/JSON Schema)

```yaml
# schema_version: 1.0
kpi_id: CFO-LQ-04
contract_version: 1.0.0
sources:
  - type: gdp
    object: GDP_CashBalance
    attributes: [cash_ending_balance]
  - type: gdp
    object: GDP_BankStatements
    attributes: [balance_verified]
```

**Example – Derived KPI**

```yaml
kpi_id: CFO-LQ-07
contract_version: 1.0.0
sources:
  - type: kpi
    ref_id: CFO-LQ-04
    contract_version: 1.0.0
  - type: kpi
    ref_id: CFO-LQ-05
    contract_version: 1.0.0
```

---

## Governance & Lineage

- Lineage Tracking  
  Each KPI run stores GDP tables or KPI IDs it depended on.  
  Enables impact analysis when GDPs or upstream KPIs change.  

- Version Awareness  
  If a KPI references another KPI, it must specify the contract version to prevent silent drift.  

- Dependency DAG  
  Platform builds a directed acyclic graph of KPI dependencies:  
  - Leaves = GDP-sourced KPIs.  
  - Higher nodes = KPI-on-KPI.  
  Scheduler uses this graph to sequence runs safely.  

- Transparency  
  Business users and auditors can always trace:  
  *“This KPI was sourced from these GDPs or KPI IDs, at these versions.”*  

---

## Integration with Other Frameworks

- KPI Pre-Validation Framework  
  Uses sourcing metadata to check data readiness of GDPs or freshness/SLA of upstream KPIs.  

- KPI Call Framework  
  Runtime query generation adapts to source type (SQL pushdown for GDP; cache retrieval for KPI).  

- KPI Scheduler Framework  
  Considers sourcing DAG for dependency-aware orchestration.  

- KPI Lifecycle Framework  
  Impact analysis leverages sourcing lineage to notify downstream KPI owners of breaking changes.  

---

## Example

**Liquidity Ratio (CFO-LQ-07)**  
- Sources:  
  - CFO-LQ-04 (Cash Balance)  
  - CFO-LQ-05 (Current Liabilities)  
- Type: Secondary KPI (KPI-on-KPI).  
- Execution: Waits for both source KPIs to complete → computes ratio → passes to Post-Validation for plausibility.  

---

## Why It Matters
- Consistency – all KPIs resolve to governed sources, not ad-hoc queries.  
- Flexibility – supports both GDP-based and KPI-on-KPI layering.  
- Trust – sourcing lineage ensures CFOs know “where the number came from.”  
- Scalability – DAG orchestration enables hundreds of KPIs across multiple tenants.  
- Future-proof – prepares the platform for advanced derived metrics, scenario models, and AI agents.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None