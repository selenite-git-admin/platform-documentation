# Kpi Sla
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI SLA Framework

## Purpose
The KPI SLA Framework defines how Service Level Agreements are declared, enforced, and monitored for each KPI.  
It ensures CFOs, executives, and operations teams can trust KPI timeliness and reliability, with clear expectations and escalation when SLAs are breached.

---

## SLA Dimensions

- Freshness – KPI must be computed within X time of source data availability.  
- Latency – KPI query/call must return results within Y seconds.  
- Availability – KPI must be delivered at scheduled time (e.g., daily 9 AM IST).  
- Consistency – KPI must reflect consistent rules across variants/tenants (e.g., all entities close by T+1).  

---

## SLA Metadata (DDL Sketch)

```sql
CREATE TABLE kpi_sla (
  kpi_id             TEXT NOT NULL,
  contract_version   TEXT NOT NULL,
  sla_type           TEXT CHECK (sla_type IN ('freshness','latency','availability','consistency')) NOT NULL,
  target_value       INT NOT NULL,                 -- seconds/minutes/hours depending on type
  grace_window       INT DEFAULT 0,                -- additional allowed slack in seconds
  criticality        TEXT CHECK (criticality IN ('low','medium','high','critical')) NOT NULL,
  escalation_policy  TEXT,                         -- reference to escalation config
  created_at         TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (kpi_id, contract_version, sla_type)
);
```

- Every KPI version must declare SLA rows.  
- Multiple SLA types may be attached to a single KPI.  
- Escalation policies stored separately (can point to playbooks, alert configs).  

---

## Workflow for SLA Tracking

```
Scheduler triggers KPI run →
  SLA definition fetched from kpi_sla →
  Run metadata logged (start_time, end_time, status) →
  Compare actual vs SLA target →
    - If within SLA → mark pass.  
    - If beyond SLA but within grace_window → warn.  
    - If beyond grace_window → breach → escalate.  
Logs → Monitoring views → Alerts/Reports.
```

---

## Example: Liquidity Ratio (CFO-LQ-07)

- Freshness SLA: must be available within 2 hours after source data load.  
- Availability SLA: must be delivered daily by 09:00 IST.  
- Latency SLA: KPI Call must return within 3 seconds at P95.  
- Criticality: High.  
- Escalation: Slack warning at T+2h, Opsgenie page if > T+3h.  

---

## Integration with Other Frameworks

- KPI Scheduler Framework → Enforces SLA at job runtime.  
- KPI Logging Framework → Records SLA checks for every run.  
- KPI Monitoring Framework → Provides SLA compliance dashboards (pass %, breach count).  
- KPI Error Handling Framework → SLA breaches treated as error category with retry/escalation.  
- KPI Alerts & Reports Framework → Alerts and reports are triggered on SLA breaches.  
- KPI Versioning Framework → SLA definitions are version-bound (different clients/variants may have different SLA commitments).  

---

## Why It Matters

- Executive trust – CFOs see KPIs when expected, not “eventually”.  
- Operational accountability – SLA breaches are transparent and traceable.  
- Comparability – Standard SLA types ensure consistency across KPIs, tenants, and domains.  
- Scalability – SLA metadata + monitoring views allow automated compliance reporting across hundreds of KPIs.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None