# Kpi Call
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Call Framework

## Purpose
The KPI Call Framework standardizes how every KPI is queried, computed, and delivered within Cxofacts.  
It acts as a contract between:
- Business meaning (KPI definition, extensions, verdicts)  
- System design (GDP tables, attributes, SCD handling)  
- Intelligence delivery (dashboards, anomaly detection, AI activations)

---

## Core Concepts
- KPI Contract – versioned metadata for each KPI (ID, name, description, GDP mappings, extension rules).  
- KPI Call – a declarative, stateless request to compute KPI values (select db/tables/fields, apply time range, filters, ops).  
- Extensions – re-use the standard Extensions Framework (time, entity, benchmark, scenario, analytical).  
- Verdict – qualitative labeling applied post-math via rule sets (e.g., Adequate / Low / Critical).  

---

## Request Schema (JSON)
```json
{
  "kpi_id": "CFO-LQ-04",
  "contract_version": "1.0.0",
  "db": "finance_dw",
  "tables": ["GDP_CashBalance"],
  "select": [
    {"expr": "SUM(cash_ending_balance)", "as": "cash_balance"}
  ],
  "time": {
    "grain": "month",
    "range": {"type": "relative", "last_n": 6},
    "calendar": "fiscal"
  },
  "dimensions": ["company_id","currency_code"],
  "filters": [
    {"field":"ledger_type","op":"=","value":"actual"}
  ],
  "extensions": {
    "time": ["MoM"],
    "entity": ["unit"],
    "benchmark": ["budget_vs_actual"]
  },
  "scd_view": "as_reported",
  "operations": {
    "rolling": [{"on":"cash_balance","window":"3m","as":"cash_balance_ra3"}]
  },
  "verdict": {"enabled": true, "rule_set": "liquidity_generic_v1"},
  "format": {"type": "timeseries"}
}
```

---

## Response Schema
```json
{
  "kpi_id": "CFO-LQ-04",
  "contract_version": "1.0.0",
  "request_id": "b2c7-…",
  "data": [
    {"period":"2025-01","company_id":"PARENT","currency":"USD",
     "cash_balance":12500000,"cash_balance_ra3":11900000,
     "mom_delta":0.04,"budget_variance":-0.02,
     "verdict":"Adequate"}
  ],
  "meta": {
    "time_grain": "month",
    "range": {"start":"2025-01-01","end":"2025-06-30"},
    "scd_view": "as_reported",
    "extensions_applied": ["MoM","unit","budget_vs_actual"],
    "lineage": {"tables": ["GDP_CashBalance@2025.03"],"sql_hash":"sha256:…"},
    "warnings": []
  }
}
```

---

## SQL Generation Template (Pseudocode)
```sql
WITH base AS (
  SELECT
    ${time_bucket} AS period,
    ${dimension_list},
    SUM(cash_ending_balance) AS cash_balance
  FROM finance_dw.GDP_CashBalance ${scd_join('as_reported')}
  WHERE ${time_filter} AND ${filters}
  GROUP BY 1, ${group_by_indices}
),
joined AS (
  SELECT b.*,
         (b.cash_balance - LAG(b.cash_balance) OVER (PARTITION BY ${dims} ORDER BY period))
         / NULLIF(LAG(b.cash_balance) OVER (PARTITION BY ${dims} ORDER BY period),0) AS mom_delta
  FROM base b
)
SELECT * FROM joined;
```

---

## Governance & Dev Notes
- Versioning – every KPI call references a contract version.  
- Idempotency – identical calls yield same `request_id` + cached result.  
- Caching – scalars & small timeseries in memory; heavy queries materialized.  
- Security – row-level & column policies applied pre-aggregation.  
- Multi-tenant – `db` resolves to tenant schema/catalog; lineage recorded.  
- Errors – `INVALID_KPI_ID`, `MISSING_GDP`, `SCHEMA_MISMATCH`, etc.  
- SCD Handling – `as_reported` vs `restated` view.  

---

## Examples

### A) Cash Balance (CFO-LQ-04)
**Type:** Scalar / Timeseries  
**Extensions:** MoM  
**Verdict:** Adequate / Low / Critical  

```json
{
  "kpi_id":"CFO-LQ-04","contract_version":"1.0.0","db":"finance_dw",
  "tables":["GDP_CashBalance"],
  "select":[{"expr":"SUM(cash_ending_balance)","as":"cash_balance"}],
  "time":{"grain":"month","range":{"type":"relative","last_n":3}},
  "extensions":{"time":["MoM"]},
  "format":{"type":"timeseries"}
}
```

---

### B) DSO (CFO-EF-02)
**Type:** Table  
**Extensions:** Entity (unit), Benchmark (budget vs actual)  
**Verdict:** Optional  

```json
{
  "kpi_id":"CFO-EF-02","contract_version":"1.0.0","db":"finance_dw",
  "tables":["GDP_Receivables"],
  "select":[{"expr":"DSO(receivable_amount, credit_sales, period_days)","as":"dso"}],
  "time":{"grain":"month","range":{"type":"relative","last_n":6}},
  "dimensions":["region","customer_tier"],
  "filters":[{"field":"ledger_type","op":"=","value":"actual"}],
  "extensions":{"entity":["unit"],"benchmark":["budget_vs_actual"]},
  "format":{"type":"table"}
}
```

---

## Why It Matters
- Consistent – one way to call any KPI.  
- Composable – extensions and SCD built-in.  
- Auditable – lineage + contract version in every response.  
- Performant – SQL pushdown, caching, and materialization.  
- Future-Proof – feeds dashboards, anomaly detection, AI agents.  

---

## KPI API Security (Enforcement)

**Goal:** Enforce tenant policies at runtime for KPI Calls (read/run/export).

### Request Pipeline
1. AuthN (OIDC/Cognito) → issue token with user attrs (tenant, roles, region).  
2. Authorizer (Verified Permissions / OPA) evaluates tenant policy for action (`kpi:Read|Run|Export`) on resource (KPI/version) and slice (entity/time-grain/extensions).  
3. Query Shaping (KPI engine) applies obligations:
   - Row-level filters (entity scope), time-grain limits, extension restrictions, SCD view caps.  
   - Masking/aggregation (hash/redact fields, bucket values, suppress small segments).  
4. Response echoes: `policy_version`, `contract_version`, and `applied_masking` in metadata.  
5. Audit: decision + obligations logged to `kpi_log` (tenant scoped).

### Example: Obligations Contract (Response Meta)
```json
{
  "kpi_id": "CFO-LQ-07",
  "contract_version": "1.0.0",
  "policy_version": "2025-08-01",
  "applied_masking": ["hash_account_numbers","suppress_small_segments"],
  "effective_entity_scope": ["APAC","EMEA"],
  "allowed_time_grains": ["month","quarter"]
}
```

### Hard Guardrails (Platform)
- Cross-tenant access is always DENY.  
- Admin operations require dual-approval for high-criticality KPIs.  
- Exports can be globally disabled per tenant or per KPI.

---


---

## Diagrams

None

## Tables

None



## Glossary

None