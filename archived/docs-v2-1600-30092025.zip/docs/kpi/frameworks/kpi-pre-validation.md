# Kpi Pre Validation
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Pre-Validation Framework

## Purpose
The KPI Pre-Validation Framework ensures that every KPI computation runs only on ready, complete, and trustworthy input data.  
It acts as the gatekeeper before KPI execution, verifying that required GDPs or upstream KPIs are available, fresh, and high quality.  

This prevents CFOs and business users from seeing half-baked or misleading KPIs due to stale or incomplete data.

---

## Core Concepts

- Data Availability  
  - Are all declared GDP tables or KPI sources present for the requested time range?  
  - Do they cover the expected entities (company, units, geographies)?  

- Data Readiness  
  - Are upstream pipelines and dependencies complete?  
  - Is data within freshness SLA (e.g., <24h for DSO, <1h for Cash Balance)?  

- Data Quality Checks  
  - Null / missing value ratios.  
  - Out-of-range checks (e.g., negative receivables).  
  - Reconciliation checks (e.g., trial balance equality).  
  - Record count consistency vs historical baseline.  

---

## Pre-Validation Schema (YAML/JSON)

```yaml
kpi_id: CFO-EF-02
contract_version: 1.0.0
pre_validation:
  availability:
    sources: [GDP_Receivables, GDP_Sales]
    time_range: last_6m
  readiness:
    freshness_sla: "24h"
    dependency_signals: [erp_eod_sync]
  quality_rules:
    - rule: "no_nulls"
      field: receivable_amount
    - rule: "value_range"
      field: receivable_amount
      min: 0
    - rule: "reconciliation"
      type: trial_balance_check
```

---

## Governance & Lineage

- Fail-Fast Policy  
  If pre-validation fails, KPI execution is skipped. Error is logged, alert fired, lineage updated.  

- Transparency  
  Each KPI run stores pre-validation results (pass/fail + rules applied).  
  Users can inspect failures in observability dashboards.  

- Audit Trail  
  Pre-validation outcomes are recorded in KPI history tables for auditors.  

- Configurable Severity  
  Some checks may be warnings (allow execution), others are hard stops.  

---

## Integration with Other Frameworks

- KPI Sourcing Framework  
  Defines the GDPs or KPI IDs to validate.  

- KPI Scheduler Framework  
  Scheduler checks pre-validation results before executing KPI Calls.  

- KPI Call Framework  
  Only executed if pre-validation passes.  

- KPI Post-Validation Framework  
  Complements pre-validation by checking plausibility of outputs.  

---

## Example

**Days Sales Outstanding (CFO-EF-02)**  
- Sources: GDP_Receivables, GDP_Sales.  
- Pre-Validation Rules:  
  - Availability → both tables must have data for last 6 months.  
  - Readiness → SLA <24h, dependency = ERP EOD sync complete.  
  - Quality → no negative receivables, trial balance reconciles.  
- If GDP_Sales is missing for March, the KPI run is skipped, with an error surfaced to the CFO dashboard.  

---

## Why It Matters
- Trust – CFOs only see KPIs computed on validated inputs.  
- Consistency – standardized checks across all KPIs.  
- Resilience – prevents broken dashboards/AI activations on missing data.  
- Auditability – logs every validation for future reference.  
- Governance – enforces enterprise-wide data discipline before numbers go live.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None