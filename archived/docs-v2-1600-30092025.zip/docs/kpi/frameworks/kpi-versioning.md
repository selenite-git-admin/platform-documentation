# Kpi Versioning
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Versioning Framework

## Purpose
The KPI Versioning Framework defines how KPIs evolve over time while maintaining trust, auditability, and compatibility.  
It ensures that every KPI run, report, or dashboard references an explicit contract version, preventing silent drift and preserving historical comparability.

---

## Core Concepts

- Semantic Versioning
  - Major (X.0.0) – Breaking changes (formula redefined, new denominator, altered purpose).  
  - Minor (0.X.0) – Non-breaking additions (new extension, optional filter, additional dimension).  
  - Patch (0.0.X) – Technical fixes (typos, corrected field mapping, metadata fix).  

- Contract Binding
  - Every KPI Call must specify a `contract_version`.  
  - Every KPI Response must echo the `contract_version`.  
  - Dashboards and AI agents always reference a specific version.

- Variants & Lineage
  - Parent KPI – Global definition.  
  - Industry Variant – Derived from parent, adapted to industry practice.  
  - Client Variant – Derived from parent or industry variant, adapted to client policy.  
  - Each variant maintains its own version chain but must reference its parent lineage.

- Compatibility
  - Backward compatibility – Old dashboards continue to work until migrated.  
  - Forward compatibility – Variants inherit parent definition unless overridden.  

---

## Version Catalog (DDL Sketch)

```sql
CREATE TABLE kpi_version_catalog (
  kpi_id            TEXT NOT NULL,
  contract_version  TEXT NOT NULL,
  parent_kpi_id     TEXT,                -- reference if variant
  owner_business    TEXT NOT NULL,
  owner_technical   TEXT NOT NULL,
  release_date      DATE NOT NULL,
  status            TEXT CHECK (status IN ('draft','approved','active','deprecated','retired')) NOT NULL,
  change_log        TEXT,                -- description of what changed
  created_at        TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (kpi_id, contract_version)
);
```

- Stores every KPI contract version with lineage.  
- Exposed in UI for traceability.  
- Enables dependency scans for dashboards, packs, and AI agents.  

---

## Integration with Other Frameworks

- KPI Lifecycle Framework  
  Lifecycle stages operate *per version* (e.g., v1.0.0 active, v0.9.0 deprecated).  

- KPI Sourcing Framework  
  Sourcing metadata is bound to the contract version (GDP/KPI references may differ between versions).  

- KPI Call Framework  
  Calls and responses must include `contract_version`.  

- KPI Logging & Monitoring Frameworks  
  Every run logged with `kpi_id` + `contract_version`. Monitoring views expose version distribution and failure trends.  

- KPI Error Handling Framework  
  Error codes are tied to specific contract versions for audit.  

---

## Example

**Days Sales Outstanding (CFO-EF-02)**  

- v1.0.0 (Parent KPI)  
  Formula: Receivables ÷ Credit Sales × Days.  

- v1.1.0 (Minor)  
  Added benchmark extension: Budget vs Actual.  

- v2.0.0 (Major)  
  Formula changed: excludes intercompany receivables.  

- v2.0.0-SaaS (Industry Variant)  
  Adjusted for subscription billing cycles.  

- v2.0.0-SaaS-ClientA (Client Variant)  
  Client-specific adjustment excluding deferred revenue.  

---

## Visual Timeline

![KPI Versioning Timeline](kpi-versioning-timeline.png)
This diagram illustrates how KPI versions evolve over time:
- Parent KPI starts the lineage.  
- Minor changes evolve within the same lineage (v1.1.0).  
- Major changes create new baselines (v2.0.0).  
- Industry Variants branch from parent versions.  
- Client Variants branch from industry variants, inheriting definitions unless overridden.  

---

## Why It Matters

- Trust – CFOs and auditors always know exactly *which version* produced a KPI.  
- Consistency – Prevents silent drift when KPI definitions evolve.  
- Comparability – Historical KPI runs remain valid under their original contracts.  
- Governance – Variants inherit lineage but evolve safely.  
- Scalability – Supports hundreds of KPIs across industries and clients with controlled versioning.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None