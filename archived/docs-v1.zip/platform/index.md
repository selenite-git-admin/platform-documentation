# CxoFacts Platform

The Cxofacts Platform is a system of systems. It is intentionally modular: each system is independently designed, governed, and operable, yet plugs into common control, security, and observability fabric. This lets clients adopt capabilities incrementally while preserving auditability and trust at scale.

## Architecture Principles

- Modularity over monoliths - Capabilities are packaged as autonomous Systems (Acquisition, Processing, Storage, KPI, Consumption) with clear contracts and lifecycle.  
- Composability via contracts - Systems interoperate through governed APIs, schemas, and policies (not implicit coupling).  
- Multi-tenant by design - Tenant isolation at data, identity, and policy layers; platform vs tenant responsibilities are explicit.  
- Auditability & trust - Lineage, versioning, SLA, security decisions, and change requests are first-class and queryable.  
- Operational excellence - Artifact-driven jobs, SLA-aware orchestration, error handling, monitoring views, and admin control planes.  
- Security as policy - AWS-style policies (ABAC/RBAC) enforced at the API/data layers, with masking/aggregation obligations.  
- Performance & cost efficiency - SQL pushdown, caching/materialization, serverless-first orchestration; scale to zero when idle.  
- Future-ready - Consistent contracts make it safe for agents/AI to act (alerts, playbooks) without re-modeling per tenant.  

---

## High-level Architecture

> Diagram placeholder (place under docs assets):  
> `![Platform Systems Map](../assets/diagrams/platform-systems-map-v2.svg)`

The platform is organized into the following Systems. Each System has its own framework docs (Purpose → Design → Assumptions/Constraints/NFRs → Workflow → Why it matters).

### Core Data Systems
**Data Acquisition System**  
Connectors and ingestion orchestration from ERP/CRM/HRMS and external sources.  
- Connectors & credentials (tenant-scoped), schema detection, drift handling, reconciliation.  
- Batch/event/stream ingestion → Bronze landing.  
- Ingestion validation (freshness, completeness).

**Data Processing System**  
Transforms raw data to standardized Silver and conformed GDP models.  
- dbt/SQL/Lambda transforms, universal date calendars, entity harmonization.  
- Quality checks & anomaly detection; lineage to metadata catalog.

**Data Storage System**  
The governed hub for persisted data products and metadata.  
- Warehouse/Lakehouse, GDP tables, Universal Date, KPI materializations.  
- Metadata & schema registry, lineage store, RLS/ABAC helpers.  
- Access posture (tenant schemas or fine-grained RLS).

### Intelligence System
**KPI System (independent subsystem)**  
Defines, runs, governs, and serves KPIs as a modular engine.  
- Definition layer: contracts, sourcing (GDP/KPI), extensions, pre/post validation, layering.  
- Execution layer: orchestration (EventBridge/Step Functions/ECS), SLA, logging/monitoring, error handling.  
- Governance layer: lifecycle, versioning, change requests, security policies.  
- Control plane: KPI Admin Dashboard (publish, pause/resume, canary, rollback, approvals).  
- Consumption: consistent API, domain packs, dashboards, reports and alerts.

> Reference docs: `kpi-architecture.md`, `kpi-sourcing.md`, `kpi-pre-validation.md`, `kpi-post-validation.md`, `kpi-logging.md`, `kpi-monitoring.md`, `kpi-error-handling.md`, `kpi-alerts-reports.md`, `kpi-versioning.md`, `kpi-sla.md`, `kpi-security.md`, `kpi-admin-dashboard.md`, `kpi-orchestration.md`, `kpi-structure-and-flow.md`

### Experience System
**Consumption System**  
Delivers value to users and apps.  
- Domain Playbooks (CFO/COO/CGO), BI dashboards, API/agent integrations.  
- Report scheduling & alert delivery; client admin console (branding, roles).

### Cross-cutting Systems
**Shared Services**  
Platform-wide capabilities available to every system.  
- Auth/OIDC, IAM federation; Secrets/KMS; Event bus/messaging.  
- Observability (logs, metrics, traces); metadata/lineage catalog.  
- Policy services (policy store, ABAC/RBAC helpers), RLS utilities.

**Platform Management System** *(provider-side control plane)*  
Operations for the platform operator.  
- Environment management, deployments, cost/capacity; compliance & audits.  
- Ops console, incident response, runbooks; sandbox/prod tenancy oversight.

**Tenant System** *(client-side control plane)*  
Administration for each tenant.  
- Onboarding, org/entity modeling, RBAC groups, quotas/billing, branding.  
- Tenant policy editing (security templates, approvals), access reviews.

---

## Conceptual Execution Flow

1) Ingest (Acquisition) → Data flows from source systems into Bronze with ingestion validation.  
2) Conform (Processing) → Silver cleanup and GDP conformance; lineage and metadata updated.  
3) Persist (Storage) → GDP and derived products stored with RLS/ABAC posture and catalog entries.  
4) Compute (KPI System) → KPI contracts source GDP/KPIs, run pre-validation; jobs execute; post-validation applied.  
5) Log & Monitor → Append-only run logs; curated monitoring views (overview, validation, lineage, SLA).  
6) Handle Errors → Retry/fallback/escalation per error-handling policy; SLA evaluated.  
7) Alert/Report → Real-time alerts for breaches/failures; scheduled KPI packs and reliability reports.  
8) Consume → Dashboards, reports, APIs/agents consume KPI outputs with clear metadata (contract version, policy version, lineage).  
9) Govern → Lifecycle state transitions via Change Requests (Admin Dashboard), with dual approvals and impact analysis.  
10) Secure → API authorizers evaluate tenant policies; query shaping applies masking/filters; audits record allow/deny and obligations.

> Workflow diagram placeholder:  
> `![Platform Execution Flow](../assets/diagrams/platform-execution-flow.svg)`

---

## Design Intent

**Why it’s built this way**
- Trust you can audit - Every number carries its contract, version, lineage, validation state, and policy decision trail.  
- Consistency beats one-off SQL - Standard calls/DSLs and extensions prevent metric drift across tenants and tools.  
- Comparability despite change - SCD, “as-reported/restated,” and semantic versioning protect longitudinal analysis during reorganizations.  
- Operational clarity - Artifact jobs, SLA-aware orchestration, and curated monitoring views separate design from runtime.  
- Scale with costs in check - Serverless-first orchestration, SQL pushdown, caching/materialization keep the platform fast and economical.  
- Agent-ready - Clear contracts/verdicts/anomaly hooks let agents safely automate alerts, diagnostics, and playbooks.

---

## Deployment View

**AWS-first, Phase-1**
- Compute & Orchestration - EventBridge (triggers), Step Functions (DAG), ECS Fargate (stateless jobs).  
- Data - RDS/Redshift (primary stores), S3 (staging/archives).  
- Identity & Security - Cognito/OIDC, IAM federation, KMS, AWS Verified Permissions/OPA for policy eval.  
- Networking - VPC, private subnets, SGs; API Gateway + CloudFront for secure ingress/edge.  
- Observability - CloudWatch logs/metrics, X-Ray traces; Grafana/Quicksight for dashboards.  
- Messaging - SNS/SQS for alerts/DLQs; Event bus for system integration.  

> Infra diagram placeholder:  
> `![AWS Reference](../assets/diagrams/platform-aws-reference.svg)`

---

## What’s Next

- Add Platform Systems Map SVG to `/assets/diagrams/` and embed above.  
- For each System, ensure a consistent doc template: *Principles → Design → Assumptions/Constraints/NFRs → Workflow → Intent*.  
- Keep policy templates and SLA definitions versioned per tenant and tied to change requests.