# Data Processing System

The Data Processing System is responsible for transforming raw ingested data into standardized, trusted, and conformed models.  
It ensures that data flows from Bronze → Silver → GDP (Golden Data Points), ready for analytics and KPI computation.

---

## Architecture Principles

- Layered refinement - Raw → standardized → conformed → business-ready.  
- Schema harmonization - Standardize entities like customers, products, employees across sources.  
- Data quality built-in - Automated checks and anomaly detection during processing.  
- Metadata-first - Lineage and schema changes are always recorded in the catalog.  
- Scalable transformations - SQL/dbt/Lambda pipelines support batch and event-driven modes.  

---

## Core Components

### Bronze to Silver Transforms  
- Type casting, deduplication, null handling  
- Aligning to standard data types and keys  
- Near-source operational schemas  

### GDP (Golden Data Points) Models  
- Universal date/calendar tables  
- Harmonized customer, product, and org entities  
- Cross-domain canonical models for KPIs  

### Data Quality & Anomalies  
- Freshness and completeness checks  
- Rule-based and anomaly detection validations  
- Error handling with quarantining and reprocessing  

### Metadata & Lineage Tracking  
- Record every transformation step  
- Update central catalog with schema versions  
- Enable auditability of KPI sourcing  

---

## Conceptual Flow

1. Data lands in Bronze from the Data Acquisition System.  
2. Transformations produce Silver (cleaned, standardized).  
3. Entity harmonization and universal date alignments build GDP models.  
4. Data quality rules validate results; anomalies are flagged.  
5. Metadata and lineage updates are pushed to the registry.  
6. Validated data is published into the Data Storage System.  

> Placeholder diagram:  
> `![Data Processing Flow](../assets/diagrams/data-processing-flow.svg)`

---

## Roadmap

- Expand GDP model coverage across domains (finance, HR, operations).  
- Add anomaly detection powered by ML for continuous monitoring.  
- Automate schema evolution handling across Bronze → Silver → GDP.  
- Integrate quality scores directly into KPI authoring workflows.