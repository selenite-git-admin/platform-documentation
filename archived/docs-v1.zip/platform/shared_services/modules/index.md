# Shared Services - Modules

Plain, cross-cutting platform primitives. No business logic, no smart workflows. Each module owns its contracts (APIs) and feature backlog locally.

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational)
![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

!!! info "How this section is organized"
    Every module has:
    - `index.md` - scope, design goals, APIs at a glance, failure modes, SLOs.
    - `features.md` - renders module backlog from `features/<module>-features.csv`.
    - `api.md` - renders API list from `api/<module>-apis.csv` + copy/paste examples.

!!! warning "Blunt truth"
    If modules start carrying domain logic or housekeeping jobs, Shared Services will bloat and slow everything else. Keep it boring and minimal.

---

## Module Directory

| Module | What it provides | Docs |
|---|---|---|
| Auth | Authentication proxy & token lifecycle (OIDC/MFA/passkeys). | [index](./auth-module/index.md) · [features](./auth-module/features.md) · [api](./auth-module/api.md) |
| RBAC | Central authorization via AVP (Cedar), default-deny + caching. | [index](./rbac-module/index.md) · [features](./rbac-module/features.md) · [api](./rbac-module/api.md) |
| Secrets | Central secrets/config, rotation, leases, redaction. | [index](./secrets-module/index.md) · [features](./secrets-module/features.md) · [api](./secrets-module/api.md) |
| Discovery | Service registry + health-aware endpoint resolution. | [index](./discovery-module/index.md) · [features](./discovery-module/features.md) · [api](./discovery-module/api.md) |
| Scheduler | Cron/jobs, retries/backoff, idempotency keys, DAGs. | [index](./scheduler-module/index.md) · [features](./scheduler-module/features.md) · [api](./scheduler-module/api.md) |
| Messaging | Pub/sub abstraction, DLQ, replay, optional ordering. | [index](./messaging-module/index.md) · [features](./messaging-module/features.md) · [api](./messaging-module/api.md) |
| Gateway | Edge policies: limits, versioning, signing, canary, CORS. | [index](./gateway-module/index.md) · [features](./gateway-module/features.md) · [api](./gateway-module/api.md) |
| Audit | Immutable append-only audit trail + export + integrity seals. | [index](./audit-module/index.md) · [features](./audit-module/features.md) · [api](./audit-module/api.md) |
| Logging | Structured logs with correlation IDs; search/tail APIs. | [index](./logging-module/index.md) · [features](./logging-module/features.md) · [api](./logging-module/api.md) |
| Telemetry | OTel metrics/traces, golden signals, SLOs. | [index](./telemetry-module/index.md) · [features](./telemetry-module/features.md) · [api](./telemetry-module/api.md) |
| Notification | Plain email/SMS/Chat senders (no workflows). | [index](./notification-module/index.md) · [features](./notification-module/features.md) · [api](./notification-module/api.md) |
| Feature Flags | Safe rollout toggles; targeting & exposure metrics. | [index](./feature-flags-module/index.md) · [features](./feature-flags-module/features.md) · [api](./feature-flags-module/api.md) |
| Encryption | KMS-backed crypto: encrypt/decrypt/sign/verify. | [index](./encryption-module/index.md) · [features](./encryption-module/features.md) · [api](./encryption-module/api.md) |
| Health | Live/ready/status, maintenance, dependency probes. | [index](./health-module/index.md) · [features](./health-module/features.md) · [api](./health-module/api.md) |
| ID/UUID | UUIDv7 + correlation/request ID utilities. | [index](./id-uuid-module/index.md) · [features](./id-uuid-module/features.md) · [api](./id-uuid-module/api.md) |

---

## Conventions

- APIs  
  - Each module uses one logical API with operations listed in `api/<module>-apis.csv`.  
  - `api.md` must include copyable Request/Response examples for every operation.

- Features  
  - Backlogs live in `features/<module>-features.csv` with columns:  
    `System, Module, FeatureID, Name, Description, Priority, Dependencies, Status, Owner`.  
  - Priorities: P0 (must-have), P1 (near-term), P2 (backlog).

- Table rendering  
  - Always reference CSVs with short paths.  
  - Example literals (escaped so the plugin doesn’t execute):  
    - &#123;&#123; read_csv('features/your-file.csv') &#125;&#125;  
    - &#123;&#123; read_csv('api/your-file.csv') &#125;&#125;

- Tenancy  
  - All APIs/events include `tenantId` where applicable; UI is advisory - APIs enforce.

---

## What’s explicitly **not** in Shared Services
- Business workflows, validation rules, schema/catalog ownership, DR/BC runbooks, cost/billing, plugin marketplaces.  
- Those live in Platform Host or domain systems and are only *consumers* of these primitives.

---

## Change Control
- Contracts are versioned (semver).  
- Breaking changes require migration notes and approvals.  
- All modules emit audit events and expose golden signals (latency/error rate/traffic).