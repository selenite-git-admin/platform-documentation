# Gateway Module

API gateway add-ons for the platform: rate limiting, throttling, quotas, versioning, request signing/verification, CORS, IP allow/deny, and canary routing. Keeps edge behavior consistent across services.

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational)
![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

!!! info "Purpose"
    Provide a uniform, enforceable edge for all APIs - consistent authn handoff, limits, versioning, and routing - without each service re-implementing them.

!!! warning "Blunt truth"
    If limits and routing policies differ by service, outages ripple unpredictably. Centralize edge concerns or pay the price during incidents.

---

## Design Goals
- Central policy for limits/quotas, signatures, and versioning.
- Safe rollout via canary/blue-green routing with fast rollback.
- Consistency: standardized CORS, headers, error shapes at the edge.
- Low latency: edge decisions P95 < 10 ms.
- Observability: per-key and per-tenant limit metrics, 429 heatmaps.

## Architecture Principles
- Gateway as control-plane + data-plane: config APIs are admin-only.
- Idempotent updates to policies; config stored centrally and pushed to edge.
- Zero trust at edge: verify signatures (when enabled), forward minimal headers.
- Contracts: semantic API versions; deprecation windows enforced.

---

## Core Components
- Limiter: token-bucket/Leaky-bucket with per-tenant and per-key quotas.
- Version Router: header/path-based routing to `/v1`, `/v2` targets.
- Signature Verifier: optional HMAC/Ed25519 verification for B2B calls.
- CORS/Headers: standardized CORS and security headers.
- Canary Controller: weighted routing + instant rollback.
- Admin API: programmatic config for limits, keys, routes.
- Metrics Exporter: emits per-key & per-tenant usage and 429s.

---

## APIs at a glance
(See detailed ops in `api.md`)

- `/gateway/limits` - get/set limits and quotas.
- `/gateway/keys` - issue/revoke API keys (hash-at-rest).
- `/gateway/signature/verify` - verify request signatures (utility).
- `/gateway/routes/canary` - set weights and rollback.
- `/gateway/cache/purge` - purge edge caches for a route.
- `/gateway/status` - edge health and config summary.

---

## Failure Modes
- Limiter backend outage → fail-closed for writes; conservative defaults for reads.
- Config push failed → keep last-known-good; raise alert.
- Signature clock skew → grace window ±60s; log violations.
- Key leak → revoke + rotate; hash-at-rest prevents retrieval.

---

## Observability & SLOs
- P95 edge overhead ≤ 10 ms.
- 429 rate visible by tenant/key/route.
- Canary success/fail counters; rollback duration tracked.
- Dashboards: latency, 2xx/4xx/5xx by route, limit utilization, signature failures.

---

## Roadmap
- Phase 0: Limits/quotas + status; standardized CORS/errors.
- Phase 1: Keys issue/revoke + signature verification.
- Phase 2: Canary routing & automated rollback.
- Phase 3: Per-tenant adaptive limits (learned baselines).

---

## References
- Auth Module - token issuance & cookies (edge just forwards minimal claims).
- RBAC Module - authorization happens after the edge.
- Logging/Telemetry - edge emits structured logs & metrics.