# API - Discovery Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/discovery-module-apis.csv') }}

---

## Operations

---

### register
**Method/Path:** `POST /discovery/register`  
**Purpose:** Register or heartbeat a service instance.

**Request**
```json
{"service": "kpi-api", "url": "https://kpi.svc:443", "version": "v1", "meta": {"region": "ap-south-1"}}
```
**Response**
```json
{"ok": True, "leaseSec": 30}
```

---

### resolve
**Method/Path:** `GET /discovery/resolve?service=kpi-api&version=v1&region=ap-south-1`  
**Purpose:** Resolve endpoints for a service.

**Request**
```http
GET /discovery/resolve?service=kpi-api&version=v1&region=ap-south-1 HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"endpoints": ["https://kpi.svc:443"]}
```

---

### deregister
**Method/Path:** `POST /discovery/deregister`  
**Purpose:** Remove an instance.

**Request**
```json
{"service": "kpi-api", "url": "https://kpi.svc:443"}
```
**Response**
```json
{"ok": True}
```

---

### watch
**Method/Path:** `GET /discovery/watch?service=kpi-api`  
**Purpose:** Open stream for updates.

**Request**
```http
GET /discovery/watch?service=kpi-api HTTP/1.1
Host: api.example.com
```
**Response**
```http
HTTP/1.1 200 OK
Content-Type: text/event-stream
```