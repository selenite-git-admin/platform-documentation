# API - RBAC Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List

{{ read_csv('api/rbac-module-apis.csv') }}

---

## Operations

### decide
**Method/Path:** `POST /authz/decide`  
**Purpose:** Evaluate whether a principal can perform an action on a resource in a given context.

**Request**
```json
{
  "principal": { "type": "User", "id": "u-123" },
  "action":    { "type": "View" },
  "resource":  { "type": "Feature", "id": "AP_Dashboard" },
  "context":   { "tenantId": "TEN-123", "appId": "finance" }
}
```

**Response**
```json
{ "decision": "ALLOW", "ttlMs": 5000 }
```

---

### entitlements
**Method/Path:** `GET /authz/entitlements?tenant=TEN-123&app=finance`  
**Purpose:** Return a snapshot of feature-level entitlements for UI route/menu guards.

**Response**
```json
{
  "AP_Dashboard": "allow",
  "AR_Dashboard": "deny",
  "CashflowPage": "allow"
}
```

---

### cache_purge
**Method/Path:** `POST /authz/cache/purge`  
**Purpose:** Purge cached decisions/snapshots after policy or membership changes.

**Request**
```json
{ "tenantId": "TEN-123", "userId": "u-123" }
```

**Response**
```json
{ "ok": true }
```

---

### policies_list
**Method/Path:** `GET /authz/policies/TEN-123`  
**Purpose:** List effective policies for a tenant (admin/debug only).

**Response (example)**
```json
{
  "tenantId": "TEN-123",
  "policies": [
    { "id": "permit_ap_view", "effect": "permit", "resource": "Feature:AP_Dashboard" },
    { "id": "forbid_ar_view", "effect": "forbid", "resource": "Feature:AR_Dashboard" }
  ]
}
```

---

## Error Model
```json
{
  "error": "unauthorized",
  "error_description": "Missing or invalid token",
  "correlation_id": "REQ-2025-08-26-xyz123"
}
```
Common cases: `unauthorized`, `forbidden`, `invalid_request`, `policy_misconfigured`, `degraded_mode`.