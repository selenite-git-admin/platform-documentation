# Errors (Fault Handling) - API & Contracts

!!! abstract "What this page is"
    The contracts your service implements to be a good citizen of the platform: HTTP error envelope, headers, event schema, retry/DLQ rules, and naming conventions.

---

## HTTP Error Response (contract)

**Envelope** - see the module overview for fields.

**Status mapping (required)**
- 400 `invalid_request` (validation, bad params)
- 401 `unauthorized` (no/expired token)
- 403 `forbidden` (policy denied, tenant mismatch, MFA required)
- 404 `not_found`
- 409 `conflict` (versioning, duplicates)
- 429 `rate_limited` (include `Retry-After`)
- 5xx `upstream_error|internal`

**Headers**
- `X-Request-Id` (propagate)
- `Retry-After` (429/503)
- `Cache-Control: no-store`

**Example**
```http
HTTP/1.1 403 Forbidden
Content-Type: application/json
X-Request-Id: req-9f1c...
Cache-Control: no-store

{
  "error": "forbidden",
  "reason": "policy_denied",
  "message": "You don't have access to this resource.",
  "correlationId": "req-9f1c...",
  "ts": "2025-08-26T10:12:30Z"
}
```

---

## Error Event (async) - `error.occurred`

**When to emit**
- Retries exhausted (DLQ reached)
- Repeated 5xx to a critical dependency
- Security-significant denials (module-specific)

**Schema (JSON)**
```json
{
  "type": "error.occurred",
  "service": "kpi-api",
  "severity": "P2",
  "error": "upstream_error",
  "reason": "dependency_timeout",
  "message": "Timed out calling analytics-core",
  "tenantId": "TEN-001",
  "userId": "u-123",
  "correlationId": "req-9f1c",
  "attempt": 5,
  "ts": "2025-08-26T10:12:30Z"
}
```

**Conventions**
- `severity`: P1 (page), P2 (degraded), P3 (minor).  
- Include links to logs/runbooks when available.

---

## Messaging & DLQ rules

**Defaults**
- Max attempts: 5 (progressive delays with jitter)
- Backoff: 1s → 2s → 4s → 8s → 16s (jittered, cap 30s)
- DLQ retention: ≥ 7 days
- Replay: manual with guardrails (idempotent handlers required)

**Naming**
- Queues: `<service>.<topic>.q`  
- DLQ: `<service>.<topic>.dlq`

---

## Correlation & Headers

**Inbound**
- Accept `X-Request-Id` or generate one.
- Reflect the same value as `correlationId` in the envelope.

**Outbound**
- Propagate `X-Request-Id` to dependencies.