# Errors features

## features list

{{ read_csv('features/errors.csv') }}

## envelope
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Without one envelope, every team invents a different error body and clients must special case each API.

### requirement
All HTTP APIs return the JSON envelope with consistent headers and status mapping.

### scope
In: JSON envelope, HTTP status mapping, headers  
Out: transport choice

### flow
1) Service detects an error
2) Map to error and reason
3) Return envelope with status and headers

### rules
- message is safe for users; details live in logs
- include Retry After on 429 and 503
- include correlationId; do not include tokens

### acceptance
- Given a policy denial, when the API responds, then it returns 403 and an envelope with error forbidden and reason policy_denied

### links
![diagram placeholder](../../../../assets/diagrams/diagram_placeholder.svg)

### references
- HTTP status codes: https://www.rfc-editor.org/rfc/rfc9110
- Error handling guidance: https://12factor.net/

## taxonomy
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Platform wide error codes with module specific reasons avoid ambiguity.

### requirement
Use the platform set for error and extend with documented reasons per module.

### acceptance
- Given a new denial in Auth, when shipped, then the new reason appears in the Auth appendix and dashboards

## correlation
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
We must join logs, metrics, and traces across services.

### requirement
Propagate a single correlation id and record trace ids in logs.

### rules
- include tenantId and userId when available
- never log tokens or secrets

## retries
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Many errors vanish with a retry, others should never be retried.

### requirement
Apply timeouts and retry only safe failure modes with exponential backoff and jitter; handlers are idempotent.

### acceptance
- Given a transient outage, when retries run, then processing recovers without duplicates

## async
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Consumers fail for bursts; some messages are poison.

### requirement
Use bounded retries; after exhaustion, send to DLQ and publish an error event.

### acceptance
- Given a poison message, when attempts are exhausted, then it is moved to DLQ and an error event is published

### links
![diagram placeholder](../../../../assets/diagrams/diagram_placeholder.svg)

### references
- AWS SQS DLQ: https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-dead-letter-queues.html

## circuit
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Prevent cascading failure.

### requirement
Trip a circuit breaker after consecutive errors and shed load gracefully.

## redaction
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Keep secrets and PII out of logs and error bodies.

### requirement
Mask tokens and keys; include email only when essential for support.

## signals
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Standard dashboards and alerts help on call act quickly.

### requirement
Expose error rate, 5xx rate, p95 latency, retry success, DLQ depth, time to drain.

## runbooks
<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e6f4ff;color:#055; font-size:12px; border:1px solid #b3e1ff;">P1</span>

### context
Every error path links to a concrete runbook.

### requirement
Minimum set includes login failure tree, redirect mismatch, JWKS rotation, provider outage, queue backlog, DLQ replay.
