# API - Scheduler Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/scheduler-module-apis.csv') }}

---

## Operations

---

### enqueue
**Method/Path:** `POST /scheduler/enqueue`  
**Purpose:** Enqueue job for immediate/asap run.

**Request**
```json
{"name": "recompute-kpis", "payload": {"tenantId": "TEN-123"}, "idempotencyKey": "job-abc"}
```
**Response**
```json
{"jobId": "job-abc", "state": "queued"}
```

---

### schedule
**Method/Path:** `POST /scheduler/schedule`  
**Purpose:** Create/update cron schedule.

**Request**
```json
{"name": "daily-gdp", "cron": "0 2 * * *", "tz": "Asia/Kolkata"}
```
**Response**
```json
{"ok": True, "scheduleId": "sch-001"}
```

---

### status
**Method/Path:** `GET /scheduler/status?jobId=job-abc`  
**Purpose:** Get job run status/history.

**Request**
```http
GET /scheduler/status?jobId=job-abc HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"jobId": "job-abc", "state": "succeeded", "durationMs": 1234}
```

---

### cancel
**Method/Path:** `POST /scheduler/cancel`  
**Purpose:** Cancel future or running job.

**Request**
```json
{"jobId": "job-abc"}
```
**Response**
```json
{"ok": True}
```