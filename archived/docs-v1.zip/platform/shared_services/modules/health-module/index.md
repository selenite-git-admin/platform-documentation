# Health Module

Liveness/readiness endpoints, aggregated service status, and SLA signal wiring for the platform.

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational)
![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

!!! info "Purpose"
    Provide consistent health semantics for every service: liveness (is the process up?), readiness (can it take traffic?), and overall status (including dependencies and maintenance).

!!! warning "Blunt truth"
    If health checks lie or are inconsistent, deploys will greenlight broken services and on-call will chase ghosts.

---

## Design Goals
- Uniform semantics: `/health/live` and `/health/ready` everywhere.
- Dependency awareness: readiness considers critical dependencies.
- Aggregated status: per-service and per-tenant views for ops.
- Maintenance mode: explicit, time-bounded, with banner signal.
- Exportable metrics: uptime, error budget burn, probe latencies.

## Architecture Principles
- Health does not execute migrations or heavy checks; fast and cheap.
- Readiness gates on critical dependencies only (declared in config).
- All health responses are cache-disabled and include correlation IDs.
- Status aggregation is read-only; changes via Admin/Config systems.

---

## Core Components
- Health Endpoints: `/health/live`, `/health/ready`, `/health/status`.
- Dependency Probes: DB/policy/cache/bus checks with timeouts.
- Status Aggregator: rolls up signals for dashboards & status pages.
- Maintenance Controller: toggles scheduled/unscheduled maintenance.
- Exporters: metrics to Telemetry; events to Notification/Audit.

---

## APIs at a glance
(See detailed ops in `api.md`)

- `/health/live` - process is up.
- `/health/ready` - process can serve traffic (deps OK).
- `/health/status` - structured summary (deps, maintenance, version).
- `/health/dependencies` - detailed probe results.
- `/health/maintenance` - get/set maintenance window (admin).

---

## Failure Modes
- Probe timeouts → readiness returns 503; liveness stays 200.
- Thundering herd → jitter probe schedules; cache recent results.
- Misdeclared deps → treat as non-critical by default; alert config owners.
- Clock skew → show server time in response; reliance on NTP elsewhere.

---

## Observability & SLOs
- P95 latency: live < 5 ms, ready < 20 ms, status < 50 ms.
- Export: uptime %, error budget burn, failing deps, maintenance windows.
- Emit events: `health.dependency.failed`, `health.maintenance.started/ended`.

---

## Roadmap
- Phase 0: live/ready/status + dependency probes.
- Phase 1: maintenance windows + aggregator + status page feed.
- Phase 2: per-tenant health overlays; synthetic probes for key flows.
- Phase 3: auto-remediation hooks (feature-flagged).

---

## References
- Telemetry Module - metrics/traces export.
- Notification Module - alert routing.
- Gateway Module - traffic shedding during not-ready.