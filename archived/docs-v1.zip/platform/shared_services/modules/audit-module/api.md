# API - Audit Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List

{{ read_csv('api/audit-module-apis.csv') }}

---

## Operations

### append
**Method/Path:** `POST /audit`  
**Purpose:** Append a new audit record (JSON schema validated, secrets masked).

**Request**
```http
POST /audit HTTP/1.1
Host: api.example.com
Authorization: Bearer eyJhbGciOi...
Content-Type: application/json

{
  "tenantId": "TEN-123",
  "actor": "user-456",
  "action": "authz.decide",
  "resource": "AR.Dashboard",
  "status": "allow",
  "timestamp": "2025-08-26T11:30:00Z"
}
```

**Response**
```json
{ "ok": true, "eventId": "AUD-evt-20250826-xyz" }
```

---

### search
**Method/Path:** `GET /audit/search?tenant=TEN-123&actor=user-456&action=authz.decide`  
**Purpose:** Query audit records with filters.

**Response**
```json
[
  {
    "eventId": "AUD-evt-20250826-xyz",
    "tenantId": "TEN-123",
    "actor": "user-456",
    "action": "authz.decide",
    "status": "allow",
    "timestamp": "2025-08-26T11:30:00Z"
  }
]
```

---

### export
**Method/Path:** `GET /audit/export?tenant=TEN-123&range=2025-01-01:2025-01-31`  
**Purpose:** Export records for compliance evidence pack.

**Response**
```http
HTTP/1.1 200 OK
Content-Type: application/zip
Content-Disposition: attachment; filename="audit_export_TEN-123_20250101_20250131.zip"
(binary zip content)
```

---

### seal
**Method/Path:** `POST /audit/seal`  
**Purpose:** Trigger hash-chain sealing and publish Merkle root.

**Response**
```json
{ "ok": true, "sealId": "SEAL-20250826-abc", "publishedAt": "2025-08-26T11:45:00Z" }
```

---

## Error Model

```json
{
  "error": "append_failed",
  "error_description": "Audit DB unavailable",
  "correlation_id": "REQ-2025-08-26-abc123"
}
```

Common cases:
- `append_failed` - DB down or schema validation failed
- `unauthorized` - missing/invalid token
- `forbidden` - actor not allowed to access tenant’s logs
- `integrity_mismatch` - seal verification failed