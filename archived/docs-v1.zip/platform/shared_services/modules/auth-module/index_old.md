﻿# Auth Module

Tenant-aware authentication using a managed IdP (AWS Cognito recommended). Provides login, MFA, federation, token handling, and an Auth Facade so apps never import IdP SDKs directly.

![Version: v1.0](https://img.shields.io/badge/Version-v1.0-informational)
![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 25-Aug-2025](https://img.shields.io/badge/Last_Updated-25--Aug--2025-lightgrey)

---

!!! info "Purpose"
    Provide secure, tenant-aware authentication for users and services with MFA, SSO, passkeys, and federation out of the box. Expose a stable Auth Facade so apps remain provider-agnostic.

!!! warning "Blunt truth"
    If auth is brittle or inconsistent, every downstream system (RBAC, KPI apps, APIs) becomes untrustworthy.

---

## Design Goals
- Managed IdP first: offload MFA, recovery, device mgmt to Cognito.
- Tenant awareness: subdomain/header → JWT claims → mapping fallback.
- Short-lived access: access ≤ 15m, rotating refresh tokens.
- Separation of duties: Auth = identity; RBAC = authorization.
- Fail safe: suspended/deactivated users always blocked.

---

## Architecture Principles
- Auth Facade: proxy to Cognito; never import SDKs directly.
- IdP minimalism: only email, name in Cognito; permissions live in Host DB + AVP.
- Cookie security: HttpOnly, Secure, SameSite=Strict; token bloat avoided.
- Audit everything: login, MFA, federation errors, suspensions.
- Resilience: degrade gracefully if IdP down; fallback to cached tokens (flagged).

---

## Core Components
- Hosted UI (Cognito): login + MFA + recovery.
- Auth Facade: code exchange, cookie handling, token introspection.
- Provisioner: sync users from Host DB → Cognito.
- Revoker: suspends/deactivates users; revokes refresh tokens; emits `user_kill_switch`.
- Middleware: API layer short-circuits suspended users.

---

## APIs at a glance
- `GET /auth/login?tenant=TEN-123` → redirect to Hosted UI.
- `GET /auth/callback` → code exchange → cookie or token response.
- `POST /auth/logout` → revoke tokens + clear cookies.
- `POST /auth/token/refresh` → new access token.
- `POST /auth/token/introspect` → `{ active, sub, exp, tenantId }`.

---

## Failure Modes
- IdP outage → degrade: API tokens for back-office, UI read-only.
- Suspended user → 401/403 immediately (DB check before RBAC).
- Clock skew → ±60s tolerance; log `clock_regression`.
- Cookie domain misconfig → blocked login; healthcheck detects.

---

## Roadmap
- Phase 0: Cognito integration, Auth Facade, provision/suspend jobs.
- Phase 1: Tenant-scoped app clients, token introspection API.
- Phase 2: Passkeys, social login (opt-in, privacy reviewed).
- Phase 3: Device code flow for kiosks; advanced analytics.

---

## References
- RBAC Module → `../rbac-module/`
- Host System (user provisioning) → `/platform/platform_host_system/modules/tenant-manager/`
- Security/DR → `/platform/shared_services_system/modules/policy-module/`
- Risks & Mitigation (Auth) → `/risks/index.md`

---

### Acceptance Criteria (MVP)
- Users can log in via Hosted UI with MFA enabled.
- Tokens issued: access (≤15m) + rotating refresh.
- Suspended users blocked in <30s end-to-end.
- Audit log records `auth_login`, `auth_failure`, `mfa_challenge`, `token_exchange`.