# API - Messaging Module

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)

---

## API List (single logical API with operations)

{{ read_csv('api/messaging-module-apis.csv') }}

---

## Operations

---

### publish
**Method/Path:** `POST /bus/publish`  
**Purpose:** Publish event to a topic.

**Request**
```json
{"topic": "kpi.calculated", "idempotencyKey": "evt-123", "payload": {"kpi": "AR_DSO", "value": 45.2}}
```
**Response**
```json
{"ok": True, "offset": 34567}
```

---

### subscribe
**Method/Path:** `POST /bus/subscribe`  
**Purpose:** Create subscription/consumer group.

**Request**
```json
{"topic": "kpi.calculated", "group": "kpi-dashboards", "from": "latest"}
```
**Response**
```json
{"ok": True, "subscriptionId": "sub-789"}
```

---

### replay
**Method/Path:** `POST /bus/replay`  
**Purpose:** Replay from DLQ or offset.

**Request**
```json
{"topic": "kpi.calculated", "from": "dlq"}
```
**Response**
```json
{"ok": True, "replayed": 120}
```

---

### topics
**Method/Path:** `GET /bus/topics`  
**Purpose:** List topics and schemas.

**Request**
```http
GET /bus/topics HTTP/1.1
Host: api.example.com
```
**Response**
```json
{"items": [{"name": "kpi.calculated"}, {"name": "auth.events"}]}
```