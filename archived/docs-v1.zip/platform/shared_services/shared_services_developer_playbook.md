# Shared Services - Developer Playbook

_Generated from uploaded clean MD on 2025-08-26._

> Scope: Documentation reset baseline → refactor Shared Services for developer usability.


## Artifacts

- Draw.io diagrams: `shared-services.drawio` (Overview + per-module flows). Open in diagrams.net and export SVGs per page.

- Source MD: Kept under `docs/platform/shared_services/...` - this playbook links back to module docs and lists concrete actions.


## How to Use

1. Open `shared-services.drawio` → review Overview then the page for the module you’re implementing.

2. In each module below, implement the listed endpoints (if applicable), wire standard events, and keep state minimal.

3. Add telemetry, audit, and runbook notes while you build - don’t leave them for later.


---

## Audit

**Docs**: `docs/platform/shared_services/modules/audit-module/index.md` | API: `docs/platform/shared_services/modules/audit-module/api.md` | Features: `docs/platform/shared_services/modules/audit-module/features.md`

**Flow Diagram**: See page “Audit - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /audit`
- `POST /audit`
- `GET /audit/search?tenant=TEN-123&actor=user-456&action=authz.decide`
- `GET /audit/export?tenant=TEN-123&range=2025-01-01:2025-01-31`
- `POST /audit/seal`

**Standard events emitted**

- `audit.recorded`

**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Auth

**Docs**: `docs/platform/shared_services/modules/auth-module/index.md` | API: `docs/platform/shared_services/modules/auth-module/api.md` | Features: `docs/platform/shared_services/modules/auth-module/features.md`

**Flow Diagram**: See page “Auth - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `GET /auth/login?tenant=TEN-123&redirect=/app`
- `GET /auth/login?tenant=TEN-123&redirect=%2Fapp`
- `GET /auth/callback?code=...&state=...`
- `POST /auth/logout`
- `POST /auth/logout`
- `POST /auth/token/refresh`
- `POST /auth/token/refresh`
- `POST /auth/token/introspect`
- `POST /auth/token/introspect`
- `POST /auth/m2m/token`
- … (+1 more in API doc)

**Standard events emitted**

- `auth.logged_in`

**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Discovery

**Docs**: `docs/platform/shared_services/modules/discovery-module/index.md` | API: `docs/platform/shared_services/modules/discovery-module/api.md` | Features: `docs/platform/shared_services/modules/discovery-module/features.md`

**Flow Diagram**: See page “Discovery - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /discovery/register`
- `GET /discovery/resolve?service=kpi-api&version=v1&region=ap-south-1`
- `GET /discovery/resolve?service=kpi-api&version=v1&region=ap-south-1`
- `POST /discovery/deregister`
- `GET /discovery/watch?service=kpi-api`
- `GET /discovery/watch?service=kpi-api`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Encryption

**Docs**: `docs/platform/shared_services/modules/encryption-module/index.md` | API: `docs/platform/shared_services/modules/encryption-module/api.md` | Features: `docs/platform/shared_services/modules/encryption-module/features.md`

**Flow Diagram**: See page “Encryption - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /crypto/encrypt`
- `POST /crypto/decrypt`
- `POST /crypto/sign`
- `POST /crypto/verify`
- `GET /crypto/key/status?keyRef=kms:alias/platform-default&tenantId=TEN-123`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Feature Flags

**Docs**: `docs/platform/shared_services/modules/feature-flags-module/index.md` | API: `docs/platform/shared_services/modules/feature-flags-module/api.md` | Features: `docs/platform/shared_services/modules/feature-flags-module/features.md`

**Flow Diagram**: See page “Feature Flags - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /flags/eval`
- `GET /flags/definitions`
- `GET /flags/definitions`
- `POST /flags/expose`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Gateway

**Docs**: `docs/platform/shared_services/modules/gateway-module/index.md` | API: `docs/platform/shared_services/modules/gateway-module/api.md` | Features: `docs/platform/shared_services/modules/gateway-module/features.md`

**Flow Diagram**: See page “Gateway - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `GET /gateway/status`
- `GET /gateway/limits?tenant=TEN-123`
- `POST /gateway/limits`
- `POST /gateway/keys/issue`
- `POST /gateway/keys/revoke`
- `POST /gateway/signature/verify`
- `POST /gateway/routes/canary`
- `POST /gateway/cache/purge`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Health

**Docs**: `docs/platform/shared_services/modules/health-module/index.md` | API: `docs/platform/shared_services/modules/health-module/api.md` | Features: `docs/platform/shared_services/modules/health-module/features.md`

**Flow Diagram**: See page “Health - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `GET /health/live`
- `GET /health/ready`
- `GET /health/status`
- `GET /health/dependencies`
- `GET /health/maintenance`
- `POST /health/maintenance`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## ID/UUID

**Docs**: `docs/platform/shared_services/modules/id-uuid-module/index.md` | API: `docs/platform/shared_services/modules/id-uuid-module/api.md` | Features: `docs/platform/shared_services/modules/id-uuid-module/features.md`

**Flow Diagram**: See page “ID/UUID - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /ids/new`
- `POST /ids/new`
- `POST /ids/bulk`
- `POST /ids/correlation`
- `POST /ids/correlation`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Logging

**Docs**: `docs/platform/shared_services/modules/logging-module/index.md` | API: `docs/platform/shared_services/modules/logging-module/api.md` | Features: `docs/platform/shared_services/modules/logging-module/features.md`

**Flow Diagram**: See page “Logging - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /logs/append`
- `GET /logs/search?tenant=TEN-123&level=ERROR&from=2025-08-01`
- `GET /logs/search?tenant=TEN-123&level=ERROR&from=2025-08-01`
- `GET /logs/tail?tenant=TEN-123`
- `GET /logs/tail?tenant=TEN-123`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Messaging

**Docs**: `docs/platform/shared_services/modules/messaging-module/index.md` | API: `docs/platform/shared_services/modules/messaging-module/api.md` | Features: `docs/platform/shared_services/modules/messaging-module/features.md`

**Flow Diagram**: See page “Messaging - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /bus/publish`
- `POST /bus/subscribe`
- `POST /bus/replay`
- `GET /bus/topics`
- `GET /bus/topics`

**Standard events emitted**

- `bus.event_published`

**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Notification

**Docs**: `docs/platform/shared_services/modules/notification-module/index.md` | API: `docs/platform/shared_services/modules/notification-module/api.md` | Features: `docs/platform/shared_services/modules/notification-module/features.md`

**Flow Diagram**: See page “Notification - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /notify/send_email`
- `POST /notify/send_sms`
- `POST /notify/send_chat`
- `POST /notify/send_batch`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## RBAC

**Docs**: `docs/platform/shared_services/modules/rbac-module/index.md` | API: `docs/platform/shared_services/modules/rbac-module/api.md` | Features: `docs/platform/shared_services/modules/rbac-module/features.md`

**Flow Diagram**: See page “RBAC - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /authz/decide`
- `GET /authz/entitlements?tenant=TEN-123&app=finance`
- `POST /authz/cache/purge`
- `GET /authz/policies/TEN-123`

**Standard events emitted**

- `rbac.policy_denied`

**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Scheduler

**Docs**: `docs/platform/shared_services/modules/scheduler-module/index.md` | API: `docs/platform/shared_services/modules/scheduler-module/api.md` | Features: `docs/platform/shared_services/modules/scheduler-module/features.md`

**Flow Diagram**: See page “Scheduler - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /scheduler/enqueue`
- `POST /scheduler/schedule`
- `GET /scheduler/status?jobId=job-abc`
- `GET /scheduler/status?jobId=job-abc`
- `POST /scheduler/cancel`

**Standard events emitted**

- `scheduler.job_completed`

**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Secrets

**Docs**: `docs/platform/shared_services/modules/secrets-module/index.md` | API: `docs/platform/shared_services/modules/secrets-module/api.md` | Features: `docs/platform/shared_services/modules/secrets-module/features.md`

**Flow Diagram**: See page “Secrets - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `GET /secrets?name=db/password&version=3`
- `GET /secrets?name=db/password&version=3`
- `POST /secrets/set`
- `GET /secrets?prefix=db/`
- `GET /secrets?prefix=db/`
- `POST /secrets/rotate`
- `POST /secrets/leases`

**Standard events emitted**

- `secrets.rotated`

**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.


---

## Telemetry

**Docs**: `docs/platform/shared_services/modules/telemetry-module/index.md` | API: `docs/platform/shared_services/modules/telemetry-module/api.md` | Features: `docs/platform/shared_services/modules/telemetry-module/features.md`

**Flow Diagram**: See page “Telemetry - Flow” in `shared-services.drawio`.


**Endpoints (snapshot)**

- `POST /telemetry/metrics/write`
- `POST /telemetry/metrics/write`
- `POST /telemetry/trace/write`
- `POST /telemetry/trace/write`
- `GET /telemetry/dashboards?module=rbac-module`
- `GET /telemetry/dashboards?module=rbac-module`
- `GET /telemetry/slos?module=rbac-module`
- `GET /telemetry/slos?module=rbac-module`

**Standard events emitted**: *(none listed in catalog - add if applicable)*


**What to build now**

- Wire the endpoints above behind the module’s facade.
- Emit standard events on success/failure paths; include `tenantId`, correlation IDs.
- Add OpenTelemetry instrumentation: spans for external calls, attributes for tenant, user, and request IDs.
- Record immutable audit entries for any config change or admin action.
- Keep local state minimal; prefer managed services where possible.
- Update `runbooks.md` with operational checks, alerts, and known failure modes.

**Acceptance checks**

- cURL examples for every endpoint return expected HTTP codes and JSON shapes.
- Event(s) appear on the bus with correct schema; replay is idempotent.
- Health probes are green; dependency failures surface in /ready.
- Feature flags (if any) toggle behavior without redeploy.
- Logs contain correlation IDs; metrics expose golden signals.