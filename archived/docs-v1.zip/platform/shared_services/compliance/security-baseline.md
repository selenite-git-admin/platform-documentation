# Security Baseline - Shared Services

- Auth - OIDC / MFA / passkeys required.  
- RBAC - default-deny policies; per-bundle ownership.  
- Secrets - no plaintext in code/logs; rotation mandatory.  
- Encryption - KMS-backed; AES-256 or stronger.  
- Audit - immutable; 7y retention.  
- Logging - redact tokens/secrets automatically.  
- Telemetry - no PII in metrics/traces.