# ERD - Shared Services

This page contains the ERD image and the source DBML so you can regenerate it on dbdiagram.io (or any DBML tool).

![Shared Services ERD](../../../assets/diagrams/shared_services_system_erd.svg)

---

## DBML (copy/paste into dbdiagram.io)

```dbml
Project SharedServices {
  database_type: "PostgreSQL"
  note: "Shared Services minimal schema. Prefer managed stores; keep tables primitive."
}

Table rbac_policy_set {
  id uuid [pk, note: "gen_random_uuid()"]
  tenant_id uuid [not null]
  name text [not null]
  version int [not null]
  policy_format text [not null, note: "cedar|json|rego"]
  policy_text text [not null]
  created_at timestamptz [not null, default: `now()`]
  updated_at timestamptz [not null, default: `now()`]

  Note: "Versioned RBAC policy sets; unique(tenant_id, name, version)"
  Indexes {
    (tenant_id, name, version) [unique]
  }
}

Table gateway_limit {
  id uuid [pk, note: "gen_random_uuid()"]
  tenant_id uuid [not null]
  rate_rpm int [not null]
  burst int [not null]
  quota_daily int [not null]
  created_at timestamptz [not null, default: `now()`]
  updated_at timestamptz [not null, default: `now()`]

  Indexes {
    tenant_id
  }
}

Table secret_ref {
  id uuid [pk, note: "gen_random_uuid()"]
  tenant_id uuid [not null]
  name text [not null]
  labels jsonb
  current_version int [not null]
  created_at timestamptz [not null, default: `now()`]
  rotates_at timestamptz

  Note: "References to KMS/Vault secrets; metadata only"
  Indexes {
    (tenant_id, name) [unique]
  }
}

Table health_maintenance {
  id uuid [pk, note: "gen_random_uuid()"]
  tenant_id uuid [note: "NULL = global"]
  active boolean [not null, default: `false`]
  window_from timestamptz
  window_to timestamptz
  reason text
  created_at timestamptz [not null, default: `now()`]

  Indexes {
    active
  }
}

Table id_correlation {
  correlation_id text [pk]
  created_at timestamptz [not null, default: `now()`]
  expires_at timestamptz

  Indexes {
    expires_at
  }
}

Enum outbox_status {
  "pending"
  "published"
  "failed"
}

Table events_outbox {
  id bigserial [pk]
  topic text [not null]
  key text
  payload jsonb [not null]
  status outbox_status [not null, default: `'pending'`]
  created_at timestamptz [not null, default: `now()`]
  published_at timestamptz

  Indexes {
    (status, created_at)
  }
}

Ref: rbac_policy_set.tenant_id > gateway_limit.tenant_id
Ref: secret_ref.tenant_id > rbac_policy_set.tenant_id
```