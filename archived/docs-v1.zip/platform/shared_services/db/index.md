# DB Designs - Shared Services

Shared Services is light on state. Prefer managed stores (KMS, AVP, OIDC IdP, object storage). When DB tables exist, keep them primitive and auditable.

## ERD (high-level)
Describe or link ERDs per module. Store editable diagrams as `.drawio` or `.mermaid` and render PNGs for docs.

- `rbac/*` - principals, roles, assignments, policy metadata (if any local cache)
- `secrets/*` - references/labels (values live in Vault/KMS), rotation metadata
- `gateway/*` - rate/quotas, keys (hashed), route configs
- `scheduler/*` - jobs, schedules, runs (or external scheduler tables)
- `feature_flags/*` - flags, rules, exposures (if not in external service)
- `events/*` - optional outbox tables for reliable publish

## Conventions
- Immutable audit trail for any change (who, when, what, diff).
- Soft-delete with `deleted_at` only if necessary; otherwise archive.
- Row-level tenancy with `(tenant_id, ...)` composite keys where applicable.
- Timestamps in UTC; all clocks NTP-synchronized.
- Migrations are idempotent and reversible; attach test data seeds.

## Files
- `erd.mmd` - Mermaid ERD (source of truth)
- `erd.png` - Rendered diagram for quick viewing
- `schema.md` - Table-by-table docs (columns, PK/FK, constraints)
- `migrations.md` - Ordered, copyable SQL snippets with rollback