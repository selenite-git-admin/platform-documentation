# Data Storage System

The Data Storage System is the governed hub for persisted data products in the Cxofacts Platform.  
It manages warehouses, GDP models, KPI marts, metadata, and access policies - ensuring data is reliable, auditable, and secure for consumption.

---

## Architecture Principles

- Single source of truth - Central storage for GDP and KPI-ready data.  
- Governed access - RLS/ABAC policies control who sees what.  
- Metadata-first - Schemas, lineage, and contracts are tracked in the catalog.  
- Separation of planes - Clear split between control-plane metadata and data-plane content.  
- Performance & efficiency - Query optimization via caching, partitioning, and materialization.  

---

## Core Components

### Data Warehouse / Lakehouse  
- Stores GDP tables and KPI materializations  
- Supports both analytical and operational queries  
- Optimized for tenant-partitioned workloads  

### GDP Tables  
- Canonical cross-domain data models  
- Universal Date and harmonized entities  
- Versioned and auditable  

### KPI Marts  
- Pre-computed KPI results for fast consumption  
- Organized by domain packs (CFO, COO, CGO, etc.)  
- SLA-backed refresh policies  

### Metadata & Schema Registry  
- Catalog of datasets, schemas, and lineage  
- Contract enforcement (column names, data types, definitions)  
- Change tracking and impact analysis  

### Access & Policy Layer  
- RLS (Row-Level Security) and ABAC (Attribute-Based Access Control)  
- Policy enforcement across all queries  
- Audit logging for all access decisions  

---

## Conceptual Flow

1. Data Processing System publishes conformed GDP models into storage.  
2. Metadata registry captures schemas and lineage.  
3. KPI definitions trigger materializations into KPI Marts.  
4. Access requests pass through policy enforcement (RLS/ABAC).  
5. Consumers query data through approved interfaces with full auditability.  

> Placeholder diagram:  
> `![Data Storage Flow](../assets/diagrams/data-storage-flow.svg)`

---

## Roadmap

- Multi-cloud storage support (AWS, Azure, GCP).  
- Automated tiering (hot/warm/cold) for cost optimization.  
- Expand lineage and impact analysis to column-level.  
- Native integration with external catalogs (e.g., Collibra, Alation).