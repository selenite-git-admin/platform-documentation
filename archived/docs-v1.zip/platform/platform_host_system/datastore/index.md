# Datastore

## Stores
- Metadata DB (PostgreSQL) - tenants, config, audit refs
- Object Storage - exports and artifacts

## Design
- Normalized core tables; partition by tenant where applicable
- Backups daily; PITR enabled

## DR
- RPO = 0 for metadata (synchronous replicas), RTO = 15m

## References
- [ADR-001: Database Standard](../../../adrs/adr-001-database.md)