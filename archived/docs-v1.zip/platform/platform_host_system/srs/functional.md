# Functional Requirements (FR)

> Numbered for traceability (FR-###). Grouped by capability.

## Tenant Lifecycle
- FR-001: Create tenant with required metadata (name, orgId, plan).
- FR-002: Update tenant settings (quotas, flags, features).
- FR-003: Suspend/Resume tenant services.
- FR-004: Deprovision tenant with soft-delete and retention policy.

## Observability
- FR-010: Emit audit logs for all admin actions.
- FR-011: Provide health/readiness endpoints per module.
- FR-012: Correlate requests with trace IDs.

## Security & Access
- FR-020: Enforce OAuth2 with scopes per API.
- FR-021: Support RBAC for platform admin roles.

## References
- [ADR-002: Authentication – OAuth2](../../../adrs/adr-002-auth.md)
- [ADR-003: Observability & Logging](../../../adrs/adr-003-observability.md)