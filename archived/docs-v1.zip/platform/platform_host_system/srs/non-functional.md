# Non-Functional Requirements (NFR)

> Numbered, testable NFRs (NFR-###).

## Performance & Scalability
- NFR-001: P95 latency for control-plane APIs <= 200ms under nominal load.
- NFR-002: Horizontal scale to 10x tenants without redeploy.

## Availability & Resilience
- NFR-010: 99.9% monthly SLO for control-plane availability.
- NFR-011: Zero data loss RPO for metadata; 15m RTO.

## Security & Compliance
- NFR-020: Secrets never logged; in transit TLS 1.2+; at rest AES-256.
- NFR-021: Map controls to ISO 27001 Annex A; SOC 2 TSC.

## Operability
- NFR-030: All modules expose /health and /ready endpoints.
- NFR-031: Structured logs with tenantId and traceId.

## References
- [ADR-003: Observability & Logging](../../../adrs/adr-003-observability.md)
- External: ISO 27001, SOC 2