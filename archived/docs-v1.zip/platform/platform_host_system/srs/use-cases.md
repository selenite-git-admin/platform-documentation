# Use Cases

## UC-001: Create Tenant
**Actors**: Platform Admin  
**Trigger**: Admin submits create request  
**Flow**:
1. Validate payload & auth scopes.
2. Persist tenant metadata.
3. Emit `tenant.created` event.
4. Return 201 with resource link.

## UC-002: Suspend Tenant
**Actors**: Platform Admin  
**Flow**:
1. Validate scopes.
2. Flag tenant state = suspended.
3. Emit `tenant.suspended` event.
4. Orchestrate dependent modules.

## References
- [FR-001](functional.md), [FR-003](functional.md)
