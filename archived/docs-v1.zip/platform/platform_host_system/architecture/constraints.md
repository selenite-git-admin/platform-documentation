# Constraints

- Budget limits align with shared-services quotas.
- Hosting limited to approved cloud regions.
- Encryption at rest and in transit mandatory (per policy).
- PII handling must follow data minimization.

## References
- [ADR-006: Data Residency](../../../adrs/adr-006-data-residency.md)
