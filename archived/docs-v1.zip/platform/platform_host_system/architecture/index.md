# Architecture - Platform Host System

High-level architecture and lifecycle.

## Diagrams
- Context Diagram: _TBD_ (`/assets/diagrams/platform-host-context.svg`)
- Component Diagram: _TBD_ (`/assets/diagrams/platform-host-components.svg`)

## Lifecycle & Readiness
- Phased enablement (MVP → Full Ops).
- Health → Readiness → Live traffic.

## Links
- [Assumptions](./assumptions.md)
- [Constraints](./constraints.md)
- [Tech Stack](./tech-stack.md)
- [Deployment](./deployment.md)

## References
- [ADR-004: CI/CD Standard](../../../adrs/adr-004-cicd.md)
- [ADR-003: Observability & Logging](../../../adrs/adr-003-observability.md)
