# Assumptions

- Managed Kubernetes is available in target environments.
- Centralized IAM and API Gateway are provisioned.
- Modern browsers for admin UI (latest Chrome/Edge/Firefox).
- Source systems deliver UTF-8 data; timestamps in UTC.

## References
- [ADR-002: Authentication – OAuth2](../../../adrs/adr-002-auth.md)
