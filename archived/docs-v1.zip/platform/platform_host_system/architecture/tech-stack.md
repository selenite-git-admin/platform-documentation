# Tech Stack

## Languages & Frameworks
- Services: Python / Node.js (per module ADRs)
- API: OpenAPI 3.1, JSON
- UI: React + Tailwind

## Data & Storage
- PostgreSQL (per ADR-001)
- Object storage (S3-compatible) for exports

## Infra & Ops
- Kubernetes, Helm
- Observability: OpenTelemetry → centralized stack
- Messaging: Managed bus (Kafka/SNS/SQS/Rabbit - per env)

## Rationale
- Favor boring, proven tech; optimize for operability and hiring.

## References
- [ADR-001: Database Standard](../../../adrs/adr-001-database.md)
- [ADR-003: Observability & Logging](../../../adrs/adr-003-observability.md)
