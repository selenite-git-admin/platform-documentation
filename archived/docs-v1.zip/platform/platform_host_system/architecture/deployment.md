# Deployment

## Environments
- dev / stage / prod with separate accounts and networks.

## Topology
- Control plane services behind API Gateway.
- Private services via service mesh; egress restricted.

## CI/CD
- Branch → Build → Scan → Test → Deploy (progressive delivery).
- GitOps for manifest drift detection.

## Observability Hooks
- Traces, metrics, logs exported with tenant and trace IDs.

## References
- [ADR-004: CI/CD Standard](../../../adrs/adr-004-cicd.md)
