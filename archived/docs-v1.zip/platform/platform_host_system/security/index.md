# Security

## Threat Model
- Control-plane exposure via API Gateway only
- Lateral movement minimized via network policies/service mesh

## Identity & Access
- OAuth2 scopes; RBAC for platform admins
- Least privilege for service accounts

## Secrets Management
- Vault (KMS-backed); no secrets in source code or docs
- Rotation schedule and approvals per runbook

## Crypto
- TLS 1.2+ in transit, AES-256 at rest

## Compliance Mapping
- ISO 27001 Annex A controls mapping (TBD)
- SOC 2 Trust Services Criteria mapping (TBD)

## References
- [ADR-007: Secret Management](../../../adrs/adr-007-secrets.md)
- External: ISO 27001, SOC 2
