# Modules

List of runtime components implementing system frameworks.

## Modules & Feature Highlights
- Tenant Manager
  - Create/Update/Suspend/Deprovision tenants
  - Emits audit events
  - Health/readiness endpoints
- Provisioner
  - Golden-path environment bootstrap
  - Idempotent retries and drift detection
- Audit Logger
  - Structured logs with tenantId, traceId

## References
- [Frameworks](../frameworks/index.md)