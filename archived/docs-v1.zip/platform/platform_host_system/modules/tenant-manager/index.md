# Tenant Manager Module

## Features List
- Create tenant with validation and uniqueness checks
- Update tenant settings and features
- Suspend/Resume tenant services
- Deprovision with soft-delete & retention policy
- Emit `tenant.*` events with correlation IDs

## Responsibilities
- Enforce tenancy contract; coordinate with Provisioner
- Persist metadata; expose REST endpoints

## Telemetry
- Logs: structured JSON with `tenantId`, `traceId`
- Metrics: request counts, latency, error rates
- Traces: end-to-end across API → DB → events

## Dependencies
- IAM (OAuth2 scopes), Metadata DB, Message Bus

## References
- [FR-001](../../srs/functional.md), [NFR-010](../../srs/non-functional.md)
- [ADR-003: Observability](../../../../adrs/adr-003-observability.md)
