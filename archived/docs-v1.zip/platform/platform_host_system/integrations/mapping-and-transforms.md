# Mapping & Transforms

- Field-level mapping maintained as versioned JSON
- Validation rules: type checks, referential integrity, value ranges
- Backward compatibility: additive changes only in minor versions

## References
- [ADR-011: API Versioning](../../../adrs/adr-011-api-versioning.md)
