# Auth & Keys (Redacted)

- OAuth2 (client credentials / authorization code where applicable)
- Token lifetime: 60 min; refresh via offline token
- Key rotation: 90 days
- Secret storage: Vault (KMS-backed)

## References
- [ADR-002: Authentication](../../../adrs/adr-002-auth.md)
- [ADR-007: Secret Management](../../../adrs/adr-007-secrets.md)
