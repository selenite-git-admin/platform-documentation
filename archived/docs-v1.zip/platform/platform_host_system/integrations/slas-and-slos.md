# SLAs & SLOs

- Control-plane API availability: 99.9% monthly
- P95 latency: <= 200ms
- Event delivery: 99.99% within 1 minute

## References
- [ADR-012: SLO & Error Budget Policy](../../../adrs/adr-012-slo-policy.md)
