# Test Harness

- Contract tests for shared/internal/external integrations
- Stubs/mocks available for SAP and Salesforce
- Synthetic events for load and failure drills

## References
- [ADR-004: CI/CD Standard](../../../adrs/adr-004-cicd.md)
