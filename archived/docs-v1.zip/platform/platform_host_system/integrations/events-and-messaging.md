# Events & Messaging

- Topics/Queues: `platform.tenants`, `platform.audit`, `kpi.refresh`
- Schema registry: `tenant.created` v1 (TBD)
- Ordering: key = `tenantId`
- DLQ: `<bus>/dlq/platform-host` (7 days)

## References
- [ADR-003: Observability](../../../adrs/adr-003-observability.md)
