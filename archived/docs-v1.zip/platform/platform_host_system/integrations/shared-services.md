# Shared Services

## IAM
- OAuth2 provider; scopes per API
- JWKS rotation: 24h; clock skew: ±60s

## Observability
- OpenTelemetry exporters for traces/metrics/logs
- Correlation via `traceparent`

## Messaging
- Managed bus with DLQ, retries, ordering where required

## References
- [ADR-003: Observability](../../../adrs/adr-003-observability.md)
- [ADR-002: Authentication](../../../adrs/adr-002-auth.md)
