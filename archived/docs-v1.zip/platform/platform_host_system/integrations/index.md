# Integrations - Overview

This folder describes all inputs/outputs and system integrations. No secrets are stored in this repo; we reference secret IDs managed by the vault.

## Subsections
- [I/O Catalog](./io-catalog.md)
- [Shared Services](./shared-services.md)
- [Internal Systems](./internal-systems.md)
- [External Systems](./external-systems.md)
- [Connection Profiles](./connection-profiles.md)
- [Auth & Keys](./auth-and-keys.md)
- [Events & Messaging](./events-and-messaging.md)
- [Error Handling](./error-handling.md)
- [SLAs & SLOs](./slas-and-slos.md)
- [Mapping & Transforms](./mapping-and-transforms.md)
- [Test Harness](./test-harness.md)
- [Change Log](./change-log.md)

## References
- [ADR-002: Authentication – OAuth2](../../../adrs/adr-002-auth.md)
- [ADR-007: Secret Management](../../../adrs/adr-007-secrets.md)