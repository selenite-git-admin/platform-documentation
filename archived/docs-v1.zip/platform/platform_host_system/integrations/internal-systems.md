# Internal Systems

## Data Acquisition System
- Contract: `dataset.ingest.requested` event
- SLA: Ack within 2s; processing within 5m

## KPI Management System
- Contract: `kpi.refresh.triggered` event
- API: `/v1/kpi/refresh`

## References
- [ADR-010: API Throttling](../../../adrs/adr-010-api-throttling.md)
