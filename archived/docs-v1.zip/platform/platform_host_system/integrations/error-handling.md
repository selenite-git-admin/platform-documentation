# Error Handling & Resilience

- Retries: 100ms → 500ms → 2s → 10s → 30s (max 5)
- Idempotency: `Idempotency-Key` header; 24h dedupe
- Circuit breaker: open after 5x 5xx in 60s; half-open after 2m

## References
- [ADR-010: API Throttling](../../../adrs/adr-010-api-throttling.md)
