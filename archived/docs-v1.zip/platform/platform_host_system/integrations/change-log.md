# Integration Change Log

- 2025-08-24: Initial placeholder catalog created.

## References
- [ADR-011: API Versioning](../../../adrs/adr-011-api-versioning.md)
