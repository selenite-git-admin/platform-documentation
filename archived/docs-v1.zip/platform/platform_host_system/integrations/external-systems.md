# External Systems

## SAP S/4HANA
- Adapter: RFC over HTTPS
- Payloads: IDocs/CSV
- Retry: exponential backoff (max 5)

## Salesforce
- OAuth2 client credentials
- Rate limits: 100k/day, 1k/15min

## References
- [ADR-002: Authentication](../../../adrs/adr-002-auth.md)
