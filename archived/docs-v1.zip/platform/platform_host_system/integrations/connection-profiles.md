# Connection Profiles (Redacted)

> Logical connection profiles and secret references. No credentials stored.

## SAP S/4HANA (Prod)
- Endpoint: `sapprd.example.com:443`
- Protocol: RFC over HTTPS
- Secret IDs:
  - Username: `vault://platform/prod/sap/rfc_user`
  - Password: `vault://platform/prod/sap/rfc_password`
- Owner: Platform Ops
- Rotation: 90 days

## Salesforce (Prod)
- Endpoint: `https://login.salesforce.com`
- Secrets:
  - Client ID: `vault://platform/prod/sfdc/client_id`
  - Client Secret: `vault://platform/prod/sfdc/client_secret`

## References
- [ADR-007: Secret Management](../../../adrs/adr-007-secrets.md)
