# I/O Catalog

## Inputs
- Events: `tenant.created`, `dataset.ingest.requested`
- File drops: `s3://cxofacts-prod/ingest/sap/*` (CSV, UTF-8, gzip)
- APIs consumed: `Shared/Auth`, `Shared/Observability`

## Outputs
- Events: `ingest.completed`, `kpi.refresh.triggered`
- APIs exposed: `POST /platform/tenants`, `POST /platform/kpi/refresh`
- File sinks: `s3://cxofacts-prod/exports/kpi/*`

## References
- [ADR-011: API Versioning](../../../adrs/adr-011-api-versioning.md)
