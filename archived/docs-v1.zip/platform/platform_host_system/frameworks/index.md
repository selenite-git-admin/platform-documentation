# Frameworks Catalogue

This system defines non-runtime contracts (frameworks) that modules implement.

- Tenancy Contract - required fields, lifecycle states, events.
- Observability Contract - logs/metrics/traces schema.
- API Versioning Contract - path/headers, deprecation policy.

## References
- [System Documentation Guide](../../../references/system_documentation_guide.md)