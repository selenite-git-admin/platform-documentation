# API: Platform Tenants

**Base Path**: `/v1/platform/tenants`

## POST /
Create tenant
- Auth: scope `platform.tenants.write`
- Body:
```json
{ "name": "Acme", "orgId": "acme-001", "plan": "standard" }
```
- Responses:
- 201 Created - with resource link
- 400/409 - validation/duplicate

## PATCH /{id}
Update tenant
- Auth: scope `platform.tenants.write`

## DELETE /{id}
Deprovision tenant
- Auth: scope `platform.tenants.admin`

## References
- [FR-001](../srs/functional.md)
- [ADR-011: API Versioning](../../../adrs/adr-011-api-versioning.md)