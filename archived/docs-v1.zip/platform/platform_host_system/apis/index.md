# APIs - Overview

## Policies
- Auth via OAuth2 with scopes
- Consistent error model; correlation IDs; rate limits per ADR-010

## Surface
- Tenants: create/update/suspend/delete
- System: health/readiness

## References
- [ADR-010: API Throttling Policy](../../../adrs/adr-010-api-throttling.md)
- [ADR-011: API Versioning](../../../adrs/adr-011-api-versioning.md)
