# Kpi Lifecycle
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Lifecycle Management Framework

## Purpose
The KPI Lifecycle Management Framework (KLMF) defines how KPIs are created, approved, evolved, and retired in Cxofacts.  
It ensures that KPIs remain trustworthy, auditable, and relevant across business, industry, and client contexts.

Together with the KPI Call Framework (execution) and KPI Scheduler Framework (freshness),  
the Lifecycle Framework provides the governance backbone for KPI management.

---

## Lifecycle Stages
1. Draft – KPI proposed by business or technical owner; under review.  
2. Proposed – Submitted for approval; not yet active.  
3. Approved – Validated by CFO (business owner) and Data/Platform team (tech owner).  
4. Active – Available for production runs, dashboards, and AI activations.  
5. Deprecated – Superseded by a newer version; visible but discouraged.  
6. Retired – No longer available for production use. Archived for audit.  

---

## Ownership & Approval
- Business Owner – typically CFO, Controller, or Finance Leader. Ensures business meaning.  
- Technical Owner – Data Engineering / Product Engineering. Ensures correct mapping to GDP and technical feasibility.  
- Approval Workflow – no KPI moves from Draft → Approved without both business and technical approval.  

---

## Versioning
- Semantic Versioning applied to every KPI contract:  
  - Major (X.0.0) – breaking changes (e.g., new formula).  
  - Minor (0.X.0) – non-breaking additions (e.g., new extension).  
  - Patch (0.0.X) – technical fixes (e.g., corrected filter).  
- Contract Version stored and returned with every KPI call and response.  
- Dashboards & AI agents must reference a specific contract version.  

---

## KPI Variants (Industry & Client Specific)
KPIs may diverge from a Parent KPI to adapt to industry norms or client-specific practices.

### Parent KPI (Global)
- Universal definition (e.g., CFO-EF-02: DSO).  
- Baseline purpose, GDP mapping, and formula.  

### Industry Variant
- Derived from parent KPI; adjusted for industry practice.  
  - Example: DSO in SaaS vs. Manufacturing.  
- Tagged as: `CFO-EF-02-SaaS v1.0.0`.  

### Client-Specific Variant
- Derived from parent or industry variant; adjusted for client policies.  
  - Example: Client A excludes intercompany receivables.  
- Tagged as: `CFO-EF-02-SaaS-ClientA v1.0.0`.  

### Variant Rules
- Every variant must reference a Parent KPI ID.  
- Variants inherit contract unless explicitly overridden.  
- Parent → Variant → Client lineage is tracked.  
- Deprecation of Parent prompts review of all active variants.  

---

## Impact Analysis
- KPI changes automatically produce a list of dependent dashboards, reports, and AI agents.  
- Before deprecation or breaking change, all stakeholders are notified.  
- Dependency metadata stored in KPI catalog for audit.  

---

## Audit & Lineage
- Each KPI run stores:  
  - KPI ID + Contract Version  
  - Parent KPI (if variant)  
  - GDP tables + SQL lineage  
- Enables full traceability for auditors and CFO office.  

---

## Governance & Dev Notes
- Preventing KPI Sprawl – all KPIs and variants must be catalogued under lifecycle states.  
- Tenant Isolation – client-specific variants remain within tenant boundaries.  
- Transparency – every dashboard or AI activation surfaces KPI version & variant label.  
- End-of-Life Policy – retired KPIs archived but not deletable.  

---

## Example

**Parent KPI (Global)**  
- ID: CFO-EF-02  
- Name: Days Sales Outstanding (DSO)  
- Version: 1.0.0  
- Formula: Receivables ÷ Credit Sales × Days  

**Industry Variant (SaaS)**  
- ID: CFO-EF-02-SaaS  
- Name: DSO (SaaS Variant)  
- Version: 1.0.0  
- Formula: Adjusted for subscription billing  

**Client Variant (ClientA)**  
- ID: CFO-EF-02-SaaS-ClientA  
- Name: DSO (Client A Policy)  
- Version: 1.0.0  
- Formula: Excludes intercompany receivables  

---


---

## Change Request Management

All KPI lifecycle state transitions (Draft → Proposed → Approved → Active → Deprecated → Retired) must be initiated and tracked as Change Requests.

- Submission: Any modification to KPI definitions, validation rules, schedules, or SLA must be raised as a formal change request.  
- Routing: Requests flow into the Admin Dashboard approval queue.  
- Approvals: Dual sign-off (business + technical) is required for high‑criticality KPIs; configurable for others.  
- Impact Analysis: Automatically generated before decision, showing lineage and affected consumers.  
- Execution: Upon approval, the Admin Dashboard executes the state transition, updates audit logs, and triggers notifications.  
- Auditability: Every change request is immutable, timestamped, and linked to the KPI contract version.

This makes Lifecycle the governance policy and the Admin Dashboard the operational control plane for changes.


## Why It Matters
- Consistency – KPIs evolve in a controlled manner.  
- Flexibility – industry and client variants allowed, without breaking the backbone.  
- Transparency – CFOs and auditors always know *which version* they’re seeing.  
- Governance – no KPI is created or deprecated without business + technical accountability.

---


---

## Diagrams

None

## Tables

None



## Glossary

None