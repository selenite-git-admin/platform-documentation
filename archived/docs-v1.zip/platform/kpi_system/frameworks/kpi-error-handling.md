# Kpi Error Handling
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Error Handling Framework

## Purpose
The KPI Error Handling Framework defines how errors are classified, handled, and escalated during KPI execution in Cxofacts.  
It ensures that failures do not silently propagate into business decisions, while providing structured recovery strategies and transparent communication to both technical and business stakeholders.

---

## Core Concepts

- Error Classification
  Errors are categorized to apply the right handling strategy (retry, fallback, escalation).

- Automated Recovery
  Framework provides retry, fallback, and suppression strategies to keep KPIs reliable.

- Business-Aware Handling
  Some errors block KPI delivery; others degrade gracefully with warnings.

- Audit & Transparency
  All errors and handling outcomes are logged and surfaced via KPI Logging & Monitoring frameworks.

---

## Error Categories

1. Sourcing Errors
   - Missing GDP table or KPI source.
   - Schema mismatch or drift.
   - Dependency DAG not resolvable.

2. Validation Errors
   - Pre-validation failure (availability, freshness, quality).
   - Post-validation failure (plausibility, anomaly, verdict alignment).

3. Execution Errors
   - SQL/engine failure.
   - Timeout or resource exhaustion.
   - Infrastructure outage (DB down, network issue).

4. Business Rule Errors
   - Negative or implausible values (e.g., negative cash).
   - Verdict mismatch (Adequate vs Critical misalignment).

5. Scheduler Errors
   - Dependency not ready at trigger time.
   - Missed SLA window.

---

## Handling Strategies

- Retry Policies
  - Immediate retry (n attempts, exponential backoff).
  - Scheduled re-run after dependency readiness.
  - Example: DSO KPI waits for Receivables GDP; retries if not ready.

- Fallbacks
  - Use last successful KPI run (with warning to user).
  - Degrade gracefully: display "Data Unavailable" badge instead of stale numbers.

- Escalation
  - Ops alert for technical failures (SQL error, infra outage).
  - CFO/business owner alert for validation/business rule failures.

- Categorized Suppression
  - Non-critical failures (e.g., minor validation warning) → allow delivery with banner.
  - Critical failures (missing GDP, SLA breach) → block execution.

---

## Standard Error Codes

- `MISSING_GDP` – Required GDP not available.  
- `INVALID_KPI_ID` – Contract reference invalid.  
- `VALIDATION_FAIL_PRE` – Pre-validation hard fail.  
- `VALIDATION_FAIL_POST` – Post-validation hard fail.  
- `SLA_BREACH` – KPI exceeded freshness SLA.  
- `EXEC_TIMEOUT` – Execution exceeded allowed runtime.  
- `SQL_ERROR` – Query or engine failure.  
- `LINEAGE_BREAK` – Dependency graph unresolved.  

---

## Error Handling Matrix

[Table: Error Category / Typical Error Codes / Handling Strategy / Escalation Path](../../../assets/csv/kpi-error-handling-error-category-typical-error-codes-handl.csv)

---

## Integration with Other Frameworks

- KPI Scheduler Framework  
  Applies retry and fallback automatically; marks run as skipped or failed if unrecoverable.

- KPI Pre-Validation Framework  
  Emits `VALIDATION_FAIL_PRE` error codes on hard stops.

- KPI Post-Validation Framework  
  Emits `VALIDATION_FAIL_POST` or `BUSINESS_RULE_FAIL` codes when outputs implausible.

- KPI Logging Framework  
  Records all errors with context, retry attempts, fallback use, and escalation actions.

- KPI Monitoring Framework  
  Surfaces error counts, trends, and SLA breaches via dashboards and alerts.

- KPI Lifecycle Framework  
  Repeated or systemic errors may trigger KPI deprecation, variant review, or redesign.

---

## Example

**Liquidity Ratio (CFO-LQ-07)**  
1. Pre-validation detects missing GDP_Liabilities → error code `MISSING_GDP`.  
2. Scheduler retries after 30 min; still fails.  
3. Error escalated: Ops channel alerted.  
4. KPI marked as *skipped*; last known value surfaced with warning badge.  
5. Logs show retry attempts, SLA breach, and final escalation path.  

---

## Why It Matters

- Trust – CFOs never see unvalidated or corrupt KPI results.  
- Resilience – Structured retries and fallbacks prevent cascading failures.  
- Transparency – Clear error codes and handling outcomes recorded in logs.  
- Governance – Repeated issues flagged for Lifecycle review.  
- Future-Proof – Error categories and strategies extendable as new KPI types emerge.  

---

---


---

## Diagrams

None

## Tables

- [Table: Error Category / Typical Error Codes / Handling Strategy / Escalation Path](../../../assets/csv/kpi-error-handling-error-category-typical-error-codes-handl.csv)



## Glossary

None