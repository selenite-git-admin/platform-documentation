# Kpi Logging
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Logging Framework

## Purpose
The KPI Logging Framework defines dedicated, business-aware logging for KPI executions in Cxofacts.  
It records what KPI ran, with which sources and contract version, what validations occurred, and what was delivered-separately from generic ETL or infrastructure logs.  
This provides CFO-grade transparency, auditability, and tenant-safe traceability.

---

## Core Concepts

- Business-Facing Logs
  Logs are organized around KPI semantics (KPI ID, contract version, verdicts) rather than low-level pipeline steps.

- End-to-End Coverage
  One run entry spans sourcing → pre-validation → execution → post-validation → delivery.

- Tenant Isolation
  All logs are scoped to tenant/environment/region; no cross-tenant exposure.

- Immutability
  Historical log entries are append-only; corrections create new entries linked via lineage refs.

---

## Minimal Data Model (DDL Sketch)

```sql
-- One row per executed attempt (including retries).
CREATE TABLE kpi_log_run (
  run_id            BIGSERIAL PRIMARY KEY,
  tenant_id         TEXT NOT NULL,
  environment       TEXT CHECK (environment IN ('dev','stg','prod')) NOT NULL,
  region            TEXT,
  kpi_id            TEXT NOT NULL,
  contract_version  TEXT NOT NULL,
  variant_label     TEXT,                      -- e.g., SaaS, ClientA
  trigger_type      TEXT CHECK (trigger_type IN ('time','event','manual')) NOT NULL,
  triggered_by      TEXT,                      -- scheduler id / user / event name
  schedule_cron     TEXT,
  started_at        TIMESTAMPTZ NOT NULL,
  finished_at       TIMESTAMPTZ,
  status            TEXT CHECK (status IN ('success','failed','partial','skipped')) NOT NULL,
  rows_processed    BIGINT,
  sla_breached      BOOLEAN DEFAULT FALSE,
  retry_seq         INT DEFAULT 0,             -- 0 for first attempt, increment on retry
  error_code        TEXT,
  error_message     TEXT,
  lineage_ref       TEXT                       -- pointer to lineage store
);

-- Sourcing lineage resolved for this run.
CREATE TABLE kpi_log_sourcing (
  run_id            BIGINT REFERENCES kpi_log_run(run_id),
  source_type       TEXT CHECK (source_type IN ('gdp','kpi')) NOT NULL,
  source_object     TEXT NOT NULL,             -- GDP table or KPI ID
  source_version    TEXT,                      -- KPI contract version (when source_type='kpi')
  attributes        TEXT,                      -- optional: list of GDP attributes
  sql_hash          TEXT,                      -- hash of generated SQL (if any)
  UNIQUE (run_id, source_type, source_object)
);

-- Pre-validation outcomes.
CREATE TABLE kpi_log_pre_validation (
  run_id            BIGINT REFERENCES kpi_log_run(run_id),
  rule_id           TEXT,
  rule_type         TEXT,                      -- availability/readiness/quality
  severity          TEXT CHECK (severity IN ('warn','error')),
  result            TEXT CHECK (result IN ('pass','fail')),
  details           TEXT
);

-- Post-validation outcomes.
CREATE TABLE kpi_log_post_validation (
  run_id            BIGINT REFERENCES kpi_log_run(run_id),
  rule_id           TEXT,
  rule_type         TEXT,                      -- value_range/variance/verdict_alignment/cross_kpi
  severity          TEXT CHECK (severity IN ('warn','error')),
  result            TEXT CHECK (result IN ('pass','fail')),
  details           TEXT
);

-- What was delivered to consumers.
CREATE TABLE kpi_log_delivery (
  run_id            BIGINT REFERENCES kpi_log_run(run_id),
  time_grain        TEXT,
  time_range        TEXT,
  scd_view          TEXT,                      -- as_reported/restated
  extensions        TEXT,                      -- e.g., ["MoM","unit","budget_vs_actual"]
  verdict           TEXT,                      -- Adequate/Low/Critical
  output_sample     TEXT                       -- small JSON sample or reference to blob
);
```

> Note: Table names are illustrative; adapt to warehouse/OLTP conventions.

---

## Governance & Operations

- Append-Only Policy
  No updates to past rows except appending corrective entries; maintain audit correctness.

- PII/PHI Avoidance
  KPI logs store metric metadata, not sensitive personal data.

- Retention Strategy
  Keep full logs for a defined period (e.g., 24 months), then archive cold storage.

- Access Control
  Row-level security by `tenant_id`; restricted columns for sensitive operational context.

- Indexing & Queryability
  Index by (tenant_id, kpi_id, started_at) for quick drill; expose views for CFO/ops dashboards.

- Alert Integration
  Error/warn results can trigger Slack/Email/Opsgenie with deep links to log runs.

---

## Integration Points

- KPI Scheduler Framework
  Creates `kpi_log_run` at trigger time; updates status on completion.

- KPI Sourcing Framework
  Writes resolved GDP/KPI lineage into `kpi_log_sourcing`.

- KPI Pre-Validation Framework
  Writes rule results into `kpi_log_pre_validation`; can set run status to `skipped` on hard fail.

- KPI Call Framework
  Provides SQL hash/lineage refs and rows processed.

- KPI Post-Validation Framework
  Writes rule results into `kpi_log_post_validation`; controls delivery gating.

- Consumption Layer
  Summarizes delivered context into `kpi_log_delivery` for end-user transparency.

---

## Example Flow

1. Scheduler triggers CFO-EF-02 v1.0.0 for tenant *Acme* at 02:00 UTC → inserts `kpi_log_run`.  
2. Sourcing resolves GDP_Receivables + GDP_Sales → inserts `kpi_log_sourcing`.  
3. Pre-Validation checks *availability, freshness <24h, no negative receivables* → all pass → records in `kpi_log_pre_validation`.  
4. KPI Call runs; SQL hash & lineage saved; rows_processed recorded.  
5. Post-Validation checks *ratio bounds & volatility* → pass; verdict = Adequate → recorded.  
6. Delivery row captures time range, extensions, verdict; run marked success.  

---

## Why It Matters

- Transparency & Trust
  A CFO-readable trail explains *what ran, on what data, and why the result is valid*.

- Audit & Compliance
  Immutable logs satisfy internal/external audits and financial governance requirements.

- Faster Triage
  Clear separation from pipeline logs speeds root-cause analysis for KPI issues.

- Tenant Safety
  Strong isolation minimizes risk in multi-tenant environments.

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None