# Kpi Layers
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Layers

## Purpose
The KPI Layers Framework defines how KPIs are structured into logical layers within Cxofacts.  
It ensures clear separation between GDP-based KPIs and derived/composite KPIs, providing consistency for design, scheduling, and validation.

---

## Core Layers

- Primary KPIs (GDP-Sourced)
  - Operate directly on Golden Data Points (facts and dimensions).
  - Represent reconciled, base-level business measures.
  - Examples:
    - Cash Balance (GDP_CashBalance)
    - Receivables (GDP_Receivables)
    - Headcount (GDP_Employees)

- Secondary KPIs (KPI-Sourced / Derived)
  - Derived from one or more other KPI outputs.
  - Typically ratios, percentages, or composites.
  - Examples:
    - Days Sales Outstanding (Receivables ÷ Sales × Days)
    - Gross Margin % (Revenue – COGS) ÷ Revenue
    - Liquidity Ratio (Cash Balance ÷ Current Liabilities)

- Composite / Index KPIs
  - Higher-level aggregations or indices, often blending multiple KPIs into a score.
  - Examples:
    - Financial Health Index (weighted blend of liquidity, leverage, profitability ratios)
    - Sales Effectiveness Score (pipeline conversion, win rates, revenue per rep)

---

## Layered Dependency Graph (DAG)

- Leaves = Primary KPIs (GDP-sourced).
- Intermediate nodes = Secondary KPIs (KPI-on-KPI).
- Higher nodes = Composite KPIs (indices, scores).
- Scheduler executes DAG topologically:
  - Primary first → Secondary → Composite.

---

## Governance & Execution Implications

- Sourcing Framework
  - Primary → GDP mappings only.
  - Secondary → KPI contract references required.

- Pre-Validation
  - Primary → GDP readiness checks.
  - Secondary → Upstream KPI freshness & SLA checks.

- Scheduler
  - Executes DAG respecting KPI-on-KPI dependencies.

- Post-Validation
  - Rules adapted by layer:
    - Primary → data plausibility (no negative receivables).
    - Secondary → ratio rules (denominator >0, % range checks).
    - Composite → distribution/weighting sanity checks.

---

## Example: Liquidity KPI Set

1. Cash Balance (Primary)  
   - Source: GDP_CashBalance  
   - Frequency: Daily  

2. Current Liabilities (Primary)  
   - Source: GDP_Liabilities  
   - Frequency: Daily  

3. Liquidity Ratio (Secondary)  
   - Source: CFO-LQ-04 (Cash Balance), CFO-LQ-05 (Current Liabilities)  
   - Formula: Cash ÷ Liabilities  
   - Frequency: Daily (post dependencies)  

4. Liquidity Health Index (Composite)  
   - Source: CFO-LQ-07 (Liquidity Ratio), CFO-LQ-08 (Quick Ratio), CFO-LQ-09 (Cash Flow Coverage)  
   - Formula: Weighted index  
   - Frequency: Weekly  

---

## Why It Matters

- Clarity – Developers and pack designers know which layer a KPI belongs to.  
- Trust – CFOs see not just the ratio, but also the underlying validated KPIs.  
- Governance – Lifecycle and validation rules adapt to layer context.  
- Scalability – DAG execution allows hundreds of KPIs without chaos.  
- Future-Proof – Lays the groundwork for KPI indices, AI scoring, and industry benchmarks.  

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None