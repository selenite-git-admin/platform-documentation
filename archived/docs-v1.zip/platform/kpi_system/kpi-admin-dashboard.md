# Kpi Admin Dashboard
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI Admin Dashboard Framework

## Purpose
The KPI Admin Dashboard is the control plane for Cxofacts.  
It centralizes catalog management, deployment, versioning, monitoring, and operational control for KPIs across tenants.  
Both platform admins and client admins can safely publish, pause, resume, roll back, and decommission KPIs with full audit trails.

---

## Personas & RBAC

- Platform Admin (Cxofacts Ops)  
  Global view across tenants; manages platform-wide settings, templates, rollouts, and incident response.

- Client Admin (Tenant Owner / Controller)  
  Manages KPIs for their tenant: approvals, schedules, SLA, alert routes, variants, and maintenance actions.

- Read-Only Roles (CFO/Exec, Auditors)  
  View health, versions, lineage, and SLA reports; cannot change state.

**RBAC model**: action-level permissions on KPI objects (create, approve, publish, pause, resume, rollback, retire), scoped by tenant and environment.

---

## Core Capabilities

1. KPI Catalog & Search
   - Browse by pack, layer (Primary/Secondary/Composite), owner, status, version.
   - Full-text search across purpose, formula, sources, and rules.

2. Versioning & Promotion
   - Draft → Approved → Active → Deprecated → Retired (per Lifecycle).  
   - Promote across environments (dev → stg → prod) with approvals.  
   - Rollback to previous contract_version with one click.

3. Deployment Controls
   - Publish/Unpublish KPI version.  
   - Pause/Resume a KPI (global or scoped by entity/time).  
   - Maintenance Mode with banner reasons and ETA.  
   - Canary Release (% traffic / subset of entities).

4. Scheduling & SLA
   - Edit frequency, triggers, windows.  
   - Configure SLA targets and grace windows.  
   - Preview impact of schedule changes on dependencies.

5. Validation & Error Policies
   - Manage pre/post validation rules and severities.  
   - Set error-handling policies (retry, fallback, suppression).

6. Alerts & Reports
   - Route alerts (Slack/Email/Opsgenie) per KPI or pack.  
   - Subscribe stakeholders to daily/weekly/monthly reports.

7. Lineage & Impact Analysis
   - Visual DAG: GDP → KPIs → Derived KPIs → Dashboards.  
   - Pre-change impact report (who/what is affected).

8. Tenant & Secret Management
   - Data connections (RDS/Redshift) and credentials (via AWS Secrets Manager).  
   - Tenant-level configuration (time zone, currency, calendars).

9. Audit & Compliance
   - Immutable event log: who changed what, when, and why.  
   - Evidence bundle exports for audits.

---

## Key Workflows

### A) Publish a New KPI Version
1. Author definition → submit for approval.  
2. Validation of sources & rules; generate impact analysis.  
3. Approver signs off → Promote to env → Publish to Active.  
4. Monitor with canary (optional) → full rollout.

### B) Pause/Resume for Maintenance
1. Admin selects KPI → Pause (global or scoped).  
2. Scheduler skips runs; dashboards show maintenance badge.  
3. Fix deployed → Resume → post-validation enforced on first run.

### C) Hotfix / Rollback
1. Issue detected → Rollback to last healthy version.  
2. Error handling routes alerts; logs capture rollback event.  
3. Post-mortem auto-snapshot: runs, failures, rules triggered.

### D) Decommission a KPI
1. Mark Deprecated → warn consumers.  
2. After grace period → Retire; archive lineage and mappings.  

---

## UI Modules (Suggested)

- Catalog (table & filters)  
- KPI Detail (tabs: Overview, Versions, Sourcing, Validation, Schedule/SLA, Lineage, Monitoring, Alerts, Audit)  
- Change Requests (approval queue)  
- Rollouts (canary status, environment promotions)  
- Incidents (active failures, paused KPIs, SLA breaches)  
- Settings (tenant configs, secrets, alert channels)

**Diagram placeholders:**  
- Catalog & Detail Wireframes → `../assets/diagrams/kpi-admin-catalog.svg`  
- Rollout/Approval Flow → `../assets/diagrams/kpi-admin-rollout.svg`

---

## Backend APIs (Control Plane)

- `POST /kpis/{kpi_id}/versions/{ver}/publish`  
- `POST /kpis/{kpi_id}/versions/{ver}/pause` (scope: global/entity/time)  
- `POST /kpis/{kpi_id}/versions/{ver}/resume`  
- `POST /kpis/{kpi_id}/versions/{ver}/rollback`  
- `POST /kpis/{kpi_id}/versions/{ver}/schedule`  
- `POST /kpis/{kpi_id}/versions/{ver}/sla`  
- `POST /kpis/{kpi_id}/versions/{ver}/validation`  
- `GET  /kpis/{kpi_id}/lineage`  
- `GET  /kpis/{kpi_id}/impact?change=...`  
- `POST /approvals/{request_id}/decision`

All write operations append events to the audit log and update the version catalog.

---

## Governance & Safety

- Dual-approval for high-criticality KPIs (4-eyes principle).  
- Change window enforcement for production.  
- Policy guardrails (cannot publish without active SLA & validation rules).  
- Scoped pause to avoid unintended global outages.  
- RBAC & RLS for tenant isolation and least privilege.

---

## NFRs

- Availability 99.9% for control plane UI/APIs.  
- Auditability 100% of admin actions stored with reason & approver.  
- Performance Catalog search < 1s P95 (indexed, cached).  
- Security SSO/OIDC, fine-grained RBAC, secrets in AWS Secrets Manager.  
- Scalability 10k+ KPIs across tenants; bulk actions supported.  
- Usability All critical actions are reversible (rollback) and explainable (impact analysis).

---

## AWS Integration (Phase 1)

- UI: hosted on S3 + CloudFront.  
- APIs: API Gateway + Lambda (control plane) with Step Functions integration.  
- Jobs: ECS Fargate for KPI runs; EventBridge for triggers.  
- Storage: RDS/Redshift for KPI results; DynamoDB for KPI logs & audit events.  
- Observability: CloudWatch metrics/logs; SNS/SQS for alerts & approvals.  
- Security: Cognito (or enterprise SSO), IAM-per-tenant roles, KMS encryption.

---

## Why It Matters

- One control surface to manage KPI lifecycle end-to-end.  
- Operational safety with pause/resume, rollback, and canary releases.  
- Governance with approvals, audit logs, and impact analysis.  
- Speed - shipping and fixing KPIs becomes a managed, repeatable process.

---

---


---

## Diagrams

None

## Tables

None



## Glossary

None