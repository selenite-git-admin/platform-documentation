# KPI Management System

## Purpose
The KPI Management System (KPI MS) is a self-contained subsystem of the Cxofacts Platform.  
It ensures that Key Performance Indicators (KPIs) are defined, executed, governed, and delivered in a consistent, auditable, and scalable manner.

It is designed to:

- Provide a governed contract for every KPI (definition, sourcing, validation, versioning).  
- Execute KPI runs in a reliable, SLA-aware orchestration layer.  
- Govern KPIs through lifecycle controls, change requests, and security policies.  
- Offer a control plane (Admin Dashboard + APIs) for deployment, monitoring, and maintenance.  
- Deliver trustworthy KPI outputs to the Consumption System (dashboards, playbooks, APIs, agents).  

---

## Scope
**Included:**

- Definition of KPIs and their metadata (contracts, extensions, rules).  
- Execution of KPI jobs with pre-validation and post-validation, logging, and error handling.  
- Governance: lifecycle, versioning, approvals, change requests, and security enforcement.  
- Control: admin operations (publish, pause, rollback, rollout).  
- Delivery: serving KPI results with lineage, metadata, and SLA compliance status.  

**Excluded:**

- Source ingestion (Responsible: Data Acquisition System).  
- Core GDP transformations (Responsible: Data Processing System).  
- Raw storage (Responsible: Data Storage System).  
- Visualization/BI UX (Responsible: Consumption System).  

---

## System Context
- Upstream dependencies:  
  Data Processing & Storage (GDP tables, Silver models).  

- Downstream consumers:  
  Consumption System (dashboards, reports, playbooks, APIs, AI agents).  

- Cross-cutting dependencies:  
  Shared Services (auth, IAM, secrets, observability, policy, lineage).  

- Control plane dependencies:  
  Tenant System (client policies), Platform Management (ops, environments).  

## At a Glance
![KPI MS – At a Glance](../../assets/diagrams/kpi-overview.svg)

**Example Flow:**  
`GDP.Sales` → KPI Contract: *Net Revenue v1.2* → Execution (daily @ 07:00) → SLA check → Logs & lineage → Reporting API → CFO Pack dashboard.

---

## System Boundaries
| Inside KPI System                | Outside KPI System                   |
|----------------------------------|--------------------------------------|
| KPI contracts & sourcing rules   | Data ingestion pipelines             |
| Pre/post validation              | Core GDP transformations             |
| SLA-aware orchestration          | Data persistence/storage engines     |
| Logging & monitoring             | BI dashboards & visualization UX     |
| Error handling                   | AI/agent consumption logic           |
| Lifecycle & versioning           |                                      |
| Security enforcement             |                                      |
| Admin Dashboard + APIs           |                                      |

---

## Design Principles
- Contracts over queries  
  Every KPI is defined as a metadata contract (YAML/JSON/DB), not ad-hoc SQL.  
  → Ensures governance, review, and versioning.  

- Auditability by default  
  Each run records contract version, input lineage, validation checks, and SLA state.  
  → Any KPI value can be explained and reproduced.  

- Lifecycle discipline  
  KPIs follow Draft → Proposed → Approved → Active → Deprecated → Retired, with semantic versioning (major/minor/patch).  
  → Protects historical comparability and prevents silent changes.  

- Reliability  
  SLA enforcement ensures KPIs are delivered on time (e.g., *Revenue KPI ready by 8 AM daily*). Failures trigger retries and alerts.  

- Scalability  
  Cloud-native, multi-tenant, DAG-aware scheduling enables thousands of KPIs to run without conflict or drift.  

---

## Roadmap
- v0.1: Core contract model, execution engine, datastore, APIs.  
- v0.2: SLA monitoring, anomaly detection, automated alerts.  
- v0.3: Multi-tenant support, advanced governance (approvals, scorecards).  
- Future: AI-driven KPI recommendations, auto-validation rules, root-cause diagnostics.  

---

## Glossary
- KPI Contract – Metadata definition of a KPI (inputs, extensions, rules, version).  
  Example: Net Revenue v1.2 = Gross Sales – Discounts, sourced from GDP.Sales.  

- KPI Run – Execution instance of a KPI contract.  
  Example: Run ID `2025-08-01-07:00` for Net Revenue v1.2, SLA daily. 

- Lineage – Trace of input sources, transformations, and dependent KPIs.  
  Example: Net Revenue depends on Gross Sales KPI + Discounts KPI.

- SLA (Service Level Agreement) – Expected freshness, latency, and availability of a KPI.  
  Example: “KPI must refresh by 07:00 daily, 99.5% success rate.” 

- Pack – Curated group of KPIs aligned to a business domain.  
  Example: CFO Pack contains Revenue, EBITDA, Net Margin KPIs.