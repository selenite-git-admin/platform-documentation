# Kpi User Roles And Permissions
[![Version: 1.0](https://img.shields.io/badge/Version-1.0-374151?style=flat-square&labelColor=111827&color=374151)](#)
[![Status: Draft](https://img.shields.io/badge/Status-Draft-f59e0b?style=flat-square&labelColor=111827&color=f59e0b)](#)
[![Last Updated: 2025-08-23](https://img.shields.io/badge/Last%20Updated-2025--08--23-neutral?style=flat-square&labelColor=111827&color=neutral)](#)

**Author:** Anant Kulkarni  
**Owner:** KPI Platform Team  
**Contributors:** -  

---

## Document Information
- Purpose: Describe this component of the KPI System.  
- Scope: Covers key concepts, structures, and interactions. Excludes implementation-specific code and deployment runbooks.  
- Target Readers: Solution architects, developers, and reviewers.  
- Dependencies: <List related docs>  
- References: <List references>  

---

# KPI System - User Roles & Permissions

This document defines roles, permissions (actions), and policy patterns for the KPI System.  
It supports both role-based access control (RBAC) and attribute-based access control (ABAC), enforced at API and data layers.

---

## 1. Principles
- Least privilege: Users receive only the minimal permissions needed.  
- Tenant isolation: All permissions are evaluated within tenant scope.  
- Separation of duties: Authoring, approving, and operating are distinct.  
- Policy-first: RBAC roles map to actions; ABAC adds contextual constraints (entity, region, sensitivity, grain).  
- Auditability: Every decision logs the user, role(s), policy version, and obligations applied.

---

## 2. Actions (Permission Verbs)

[Table: Action / Description](../../assets/csv/kpi-user-roles-and-permissions-action-description.csv)

Legend: List=`kpi:List`, Read=`kpi:Read`, Inspect=`kpi:Inspect`, Sched=`kpi:ScheduleEdit`, SLA=`kpi:SlaEdit`, Valid=`kpi:ValidationEdit`, Logs=`kpi:LogsRead`, Alerts=`kpi:AlertsManage`

---

## 7. Enforcement & Audit Flow

1. Authenticate via OIDC/JWT (Cognito).  
2. Authorize action using tenant policy (RBAC + ABAC) → decision + obligations.  
3. Shape query with obligations (RLS filters, masking, grain caps).  
4. Execute KPI call / admin op.  
5. Audit decision: user, roles, policy version, obligations, trace_id.  
6. Respond with `policy_version` and applied obligations in metadata.

---

## 8. Open Items / Tenant Customization
- Role templates per tenant (Finance Standard, External Auditor, CFO Confidential).  
- Policy simulator and dry-run mode in Admin Dashboard.  
- Break-glass emergency role (time-limited, dual-approval).

---

---


---

## Diagrams

None

## Tables

- [Table: Action / Description](../../assets/csv/kpi-user-roles-and-permissions-action-description.csv)



## Glossary

None