# Data Acquisition System

The Data Acquisition System is the entry point for all data into the Cxofacts Platform.  
It provides connectors, ingestion orchestration, and validation to ensure that source data from ERP, CRM, HRMS, and other systems arrives in the platform reliably and consistently.

---

## Architecture Principles

- Connector-driven - Standard connectors abstract source system complexity.  
- Schema-aware ingestion - Automatic detection and reconciliation of schema changes.  
- Multiple ingestion modes - Batch, event, and streaming are supported.  
- Validation-first - Freshness, completeness, and reconciliation checks applied at ingestion.  
- Tenant isolation - Credentials and pipelines are scoped per tenant for security.  

---

## Core Components

### Connectors  
- Prebuilt connectors for SAP, Salesforce, NetSuite, Tally, and others  
- Credential management per tenant  
- Schema detection and drift handling  

### Ingestion Orchestration  
- Batch ingestion for ERP/CRM extracts  
- Event-driven or streaming ingestion for real-time sources  
- Retry and dead-letter queue (DLQ) handling  

### Validation Layer  
- Freshness checks on arrival times  
- Completeness checks (row counts, reconciliations)  
- Alerts for ingestion failures  

---

## Conceptual Flow

1. Connector extracts data from a source system.  
2. Ingestion orchestration moves the data into Bronze landing zone.  
3. Schema and validation checks ensure data quality at the door.  
4. Errors route to DLQs; alerts notify operators.  
5. Valid data moves forward to the Data Processing System.  

> Placeholder diagram:  
> `![Data Acquisition Flow](../assets/diagrams/data-acquisition-flow.svg)`

---

## Roadmap

- Expand connector library (industry-specific ERPs/CRMs)  
- Add more streaming/event-based ingestion options  
- Improve automatic schema reconciliation and mapping to GDP models  
- Integrate with anomaly detection for real-time ingestion monitoring