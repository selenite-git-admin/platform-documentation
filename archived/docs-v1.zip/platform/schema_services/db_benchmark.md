# Schema Services - DB Benchmarks

![status-draft](https://img.shields.io/badge/status-draft-yellow)
![last_updated-2025-08-28%2010:58%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2010:58%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This page packages runnable k6 smoke scripts and the gate criteria for selection sign‑off.

!!! info
    Point `BASE_URL` at your Prism mock or dev API. These are HTTP level smokes aligned to W2 and W4. Extend to W1–W6 for full gates.

## Workload Gates

| Workload | What it proves | Gate |
|---|---|---|
| W1 Create Version | insert envelope JSONB with lineage and bindings | p95 50 ms at 60 rps |
| W2 List Versions | paginate last 50 by schema_id | p95 30 ms at 200 rps |
| W3 Search | name prefix plus category or tag filter | p95 30 ms at 150 rps |
| W4 Append Run | single insert to telemetry | p95 30 ms at 2k rps baseline and 10k burst for five minutes |
| W5 Runs Query | 30‑day, time‑bounded list for a version | p95 80 ms at 100 rps with stable plans |
| W6 Usage Snapshot | refresh derived view | completes under two minutes at 100M rows per day |

## k6 Scripts

```javascript title="k6/w2_list_versions.js"
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 10,
  duration: '30s',
};

const BASE_URL = __ENV.BASE_URL || 'http://127.0.0.1:4010';
const AUTH = __ENV.AUTH || 'Bearer test';

export default function () {
  const headers = { 'Authorization': AUTH };
  const res = http.get(`${BASE_URL}/schemas`, { headers });
  check(res, { '200': r => r.status === 200 });
  sleep(0.3);
}

```

```javascript title="k6/w4_append_run.js"
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 5,
  duration: '30s',
};

const BASE_URL = __ENV.BASE_URL || 'http://127.0.0.1:4010';
const AUTH = __ENV.AUTH || 'Bearer test';

export default function () {
  const payload = JSON.stringify({
    name: 'gdp_general_ledger_header',
    category: 'gdp',
    owner: { team: 'data-platform' }
  });

  const headers = {
    'Authorization': AUTH,
    'Idempotency-Key': crypto.randomUUID(),
    'Content-Type': 'application/json'
  };

  const res = http.post(`${BASE_URL}/schemas`, payload, { headers });
  check(res, { '201 or 200': r => r.status === 201 || r.status === 200 });
  sleep(0.5);
}

```

## Run

```bash
BASE_URL=http://127.0.0.1:4010 k6 run k6/w2_list_versions.js
BASE_URL=http://127.0.0.1:4010 k6 run k6/w4_append_run.js
```

