# Solution

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Architecture](https://img.shields.io/badge/Owner-Architecture-blue)
![Last Updated: 27-Aug-2025](https://img.shields.io/badge/Last_Updated-27--Aug--2025-lightgrey)

---

## The Problem

Enterprises consistently struggle with schema drift and discoverability. Raw tables evolve silently. Pipelines break without warning. Documentation is sparse or outdated. Analysts cannot trace KPIs back to the source. Institutional knowledge disappears when engineers move on. The result is costly rework, wasted engineering cycles, and loss of trust in the data itself.

Traditional approaches-scattered ER diagrams, dbt models, or tribal SME knowledge-do not scale across systems and tenants. They also fail to capture the business meaning of fields. A column named `SAKNR` tells nothing to a CFO. A liquidity ratio KPI is meaningless if the analyst cannot map it back to validated source schemas.

---

## The Solution

Schema Services solves this by making schema definitions first-class contracts. Every dataset-whether raw source, GDP abstraction, KPI input, or AI feature-is governed by a schema object. These objects are global, versioned, and signed. They unify technical structure with business meaning and governance metadata.

Tenants no longer reverse-engineer. They select a schema from a global catalog. If they need a variant, they request one under SLA. SMEs review, approve, and release it. Pipelines then bind to schema headers that point to validated payloads. Contracts-not hope-define the flow of data.

!!! info "Contract First"
    Schemas exist before data connection. Tenants select from a global catalog or request a controlled modification under SLA.

---

## Conceptual View

![Schema Services Conceptual View](../../assets/diagrams/schema-services/solution_overview.svg){ style="display\:block; margin: 1.5rem auto;" }

CxoFacts works across four broad layers:

1. Enterprise Data Systems: SAP, NetSuite, Salesforce, and other ERPs/CRMs.
2. CxoFacts Data Systems: Ingestion, storage, processing, KPI management.
3. Schema Services: The contract layer that governs, validates, and versions all schemas.
4. Data Consumption Systems: Dashboards, APIs, and AI activations.

Schema Services sits at the center of trust, ensuring that all data is well-defined, versioned, validated, and ready for use by analytics and AI.

---

## Workflow (Logic Flow)

The best way to understand Schema Services is to follow the journey of tenant enterprise data through CxoFacts.

### 1. Acquisition

A tenant administrator connects CxoFacts to an enterprise system, such as SAP FI. At this stage, only the connection is established. No new schema is created.

### 2. Schema Selection

Schema Services provides a global catalog of pre-built schemas for major systems. The admin selects the required schemas - for example, SKA1, SKB1, and SKAT from SAP FI. These schemas are already defined and versioned.

### 3. Variant Request

If the tenant requires changes, such as an extension or stricter validation, the admin submits a schema modification request. The shared services team reviews and fulfills this request under an SLA. A new tenant-specific or global schema version is then released.

### 4. GDP Normalization

CxoFacts provides GDP Schemas that represent canonical business definitions, such as g\_gl\_account. These GDP schemas are bound to Source Schemas like SKA1 and SKAT. The GDP layer ensures that raw ERP structures are converted into consistent, business-friendly contracts.

### 5. KPI Contracts

KPI Schemas, such as kpi\_inputs\_liquidity, are available in the catalog. Tenants select these schemas, which reference GDP schemas. KPI schemas declare inputs, grain, and invariants, making metrics durable and auditable.

### 6. AI Activation

For machine learning or GenAI use cases, tenants use AI Activation Schemas. These schemas define features, privacy constraints, and evaluation baselines. They bind to GDP schemas. Like KPI schemas, they are available out-of-the-box, with modification requests handled under SLA.

### 7. Governance and Drift

At runtime, all data pipelines are validated by DQC rules attached to the schema. If data violates type, null, or range rules, the pipeline fails closed. If schema drift is detected, such as a source column changing type, an event is raised. Teams are notified, and schema diffs highlight the change.

### 8. Consumption

Dashboards, APIs, and AI services consume only Released schemas. Consumers never connect directly to raw ERP tables. They rely on the contract layer that Schema Services enforces.

!!! info "Principle"
    Schema contracts are defined before connection. Tenants onboard by selecting from a trusted catalog or requesting controlled modifications. All downstream consumption relies on these governed contracts.

---

## Core Components

Schema Services is made of several core components. Each plays a specific role in the workflow. Together they ensure that schemas are trusted, governed, and ready for consumption.

### Schema Registry

The Schema Registry is the system of record. It stores every schema, its versions, and its metadata. The registry keeps track of columns, keys, constraints, and lineage. It enforces that no schema can move forward without version control.

### Lifecycle and Approvals

All schemas follow the same lifecycle: Draft → In Review → Approved → Released → Deprecated → Retired.
A schema cannot change state without approval. Subject matter experts review Drafts, attach DQC profiles, and approve them. Released schemas are the only schemas allowed in pipelines.

### DQC Engine

The DQC engine is the gatekeeper. It enforces validation rules every time data flows through a schema. Rules check for type mismatches, null violations, ranges, and business invariants. Global rules apply everywhere. Tenants can add local rules, but they cannot weaken the global baseline.

### Bindings and Mapping

Bindings link schemas across layers. GDP schemas bind to Source schemas. KPI schemas bind to GDP schemas. AI schemas bind to GDP or Source schemas. Each binding has a mapping reference that explains how attributes transform. This ensures traceability from KPI back to raw source.

### Provider Seeding

Provider seeding accelerates onboarding. Adapters import schema definitions from ERP or CRM systems, such as SAP DDIC. The seed produces a Draft schema. The schema still needs review, but seeding prevents manual definition from scratch.

### Validation and Drift Detection

Validation ensures that data matches the schema contract at runtime. Drift detection monitors for unexpected changes, such as a column type changing in the source system. When drift occurs, an event is raised. Consumers are notified, and a diff highlights the mismatch.

### Events and Observability

Schema Services publishes events such as schema.released, schema.deprecated, and schema.drift.detected. These events feed into monitoring systems. Observability metrics show schema coverage, validation latency, and drift frequency. Runbooks connect alerts to remediation steps.

### Admin Console (UI)

The Admin Console is a thin web client. It provides discovery, authoring, review queues, and lineage exploration. All operations in the UI call the same public APIs, so automation and manual workflows stay consistent.

### Public APIs

All functionality in Schema Services is exposed by APIs. Teams can create, update, release, or validate schemas programmatically. APIs also support diffs, provider seeding, and event subscriptions. This API-first design ensures CxoFacts integrates with any ecosystem.

---

## Governance and Tenancy

Governance defines how schemas are controlled and trusted across the platform. Tenancy defines how global standards and local needs co-exist. Together they make sure that CxoFacts delivers consistency without blocking flexibility.

### Global Schemas

Global schemas are defined once and are available to all tenants. They are reviewed by subject matter experts and approved through the lifecycle. Global schemas act as the baseline contracts for major ERP and CRM systems.

### Tenant Variants

Tenants sometimes need additional attributes, stricter validations, or localized adjustments. In these cases, they request a tenant variant. A tenant variant inherits the structure and rules of the global schema but adds local changes. It cannot weaken or remove global rules.

### Promotion Path

A tenant variant can be promoted to become a new global version. The variant goes through the same review and approval process. If approved, it replaces or extends the global baseline. This process ensures that improvements discovered locally can benefit all tenants.

### Rule Inheritance

All data quality rules from the global schema apply automatically to tenant variants. Tenants can add new rules or tighten thresholds. They cannot reduce coverage or relax controls. This keeps the trust baseline intact across the platform.

!!! info "Why this matters"
    Global schemas guarantee consistency for enterprise-wide reporting.
    Tenant variants allow local business units to move fast without breaking standards.
    Promotion ensures that the best practices flow back into the global catalog.

---

## Versioning Control

Every schema in CxoFacts follows semantic versioning. This makes changes predictable and helps teams understand the impact before adoption.

### Semantic Versioning

Schemas use the format `MAJOR.MINOR.PATCH`.

* MAJOR: A breaking change. Examples are dropping a column, renaming a key, or tightening a constraint. Pipelines bound to the old schema cannot move forward without adjustment.
* MINOR: A non-breaking enhancement. Examples are adding a new nullable column, adding an index, or widening a length or precision. Existing consumers continue to work.
* PATCH: A fix that does not change structure. Examples are description updates, corrected metadata, or additional lineage notes.

![Schema Services Conceptual View](../../assets/diagrams/schema-services/versioning_policy.svg){ style="display\:block; margin: 1.5rem auto;" }

### Compatibility Rules

Compatibility rules ensure that downstream consumers know what to expect. When a new version is released, CxoFacts enforces these rules:

* A consumer bound to a MAJOR version must explicitly migrate.
* A consumer bound to a MINOR or PATCH version can continue without change.
* Migration notes are required for every MAJOR bump.
* Deprecation events are published when a schema moves towards retirement.

!!! info "Why this matters"
    Without versioning discipline, schema drift becomes invisible and dangerous. Semantic versioning makes every change explicit, traceable, and auditable. Consumers can plan migrations instead of reacting to silent failures.

---

## Operating Model

Schema Services is designed to run as a production system. Its focus is reliability, security, and compliance.

### Service Levels

The registry API must be available at least 99.9 percent of the time. Validation must respond within 50 milliseconds for one thousand rows at p50. Median review-to-release time must be less than 24 hours. Drift detection must occur within fifteen minutes of ingestion.

### Security

Access follows role-based access control. Roles are Author, Approver, Reader, and Operator. Each role has the least privilege needed. All approvals and changes are recorded in an immutable log. All data at rest is encrypted.

### Compliance

Global DQC rules apply to every schema. Tenants may add local rules but cannot weaken the global baseline. Privacy flags are mandatory for schemas that contain personal data. AI schemas must include evaluation thresholds before they are released.

### Monitoring

Schema Services emits metrics and events for all critical operations. Events connect to runbooks that guide remediation. Alerts fire when validation fails, drift is detected, or SLOs are at risk.

!!! success "Principle"
    The system fails closed. No KPI or AI result is produced unless schema and DQC checks pass.

---

## Special Flows

Two workflows show how Schema Services is applied in practice: onboarding a new tenant and activating AI use cases.

### Onboarding (Source → GDP → KPI)

A tenant admin connects CxoFacts to an ERP system. They select Source Schemas from the global catalog. GDP schemas bind to those sources and provide canonical definitions. KPI schemas bind to GDP and define metric inputs. At every step, DQC rules validate data. Only released schemas are used in pipelines.

### AI Activation

A data team defines an AI schema for a model use case. They select GDP tables as features. They declare privacy requirements and evaluation baselines. Reviewers approve the schema. Once released, the schema governs the feature store or GenAI context. At runtime, validation enforces vector dimensions, privacy, and evaluation thresholds.

📌 *Diagram placeholders:* \[FLOW\_DIAGRAM\_E2E\_ONBOARDING], \[FLOW\_DIAGRAM\_AI\_ACTIVATION]

---

!!! success "The Core Differentiator"
    Schema Services is not just a collection of modules. It is the trust fabric of CxoFacts.
    It transforms raw enterprise data into governed, reliable, and business-meaningful contracts that
    power every dashboard, KPI, and AI activation.
    Without Schema Services, CxoFacts would be just another data platform.
    With it, CxoFacts becomes a trusted partner of CXOs for enterprise decision-making.