# Schema Object

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 27-Aug-2025](https://img.shields.io/badge/Last_Updated-27--Aug--2025-lightgrey)

---

## Layered Model

Each schema object is defined in layers. This keeps business information, technical structure, and governance separate but connected.

### Layer 1 - Identity (Header)

* schema\_id: unique identifier such as src\_sap\_fi\_ska1\_v1
* category: Source, GDP, KPI, or AI
* type: classification such as Table, Master, Fact, Feature Store, or Context
* version: semantic version in MAJOR.MINOR.PATCH format
* provider: source or logical provider (required for Source; optional for GDP/KPI/AI)
* source\_protocol: access method such as JDBC, OData v2, RFC, REST (required for Source)
* payload\_ref: pointer to associated payload definition

### Layer 2 - Structural (Payload)

* columns: name, type, length, precision, scale, nullable, ordinal, description
* keys: primary, unique, foreign
* constraints: invariants such as gross = net + tax
* classifications: business\_key, amount, date, text, pii, etc.
* semantics: tags such as amount.net, posting\_date
* lineage: provider dictionary references and transform notes
* signature: hash of structural attributes including column order

### Layer 3 - Governance (Header)

* scope: Global or Tenant
* lifecycle: Draft → In Review → Approved → Released → Deprecated → Retired
* owner: accountable steward or team
* consumers: tenants, pipelines, dashboards, models
* approvals: reviewer list and timestamps
* changelog: reasoned history of changes

### Layer 4 - Data Quality (Payload)

* dqc\_profile: ruleset attached to the schema payload
* enforcement\_mode: name\_bound or position\_bound
* validation\_policy: Block, Quarantine, or Warn
* rules: type checks, null checks, range checks, PK uniqueness, strict\_column\_order, schema\_signature\_match

### Layer 5 - Bindings and Relationships (Header + Payload)

* gdp\_to\_source: mappings with transform references
* kpi\_to\_gdp: inputs and roles
* ai\_to\_gdp\_or\_source: feature or context bindings
* lineage\_edges: upstream and downstream links

### Layer 6 - Operations and Observability (Header)

* events: schema.released, schema.deprecated, schema.validation.failed, schema.drift.detected, ai\_eval.regression
* profiling\_stats: null percent, distinct percent, min and max
* slo: availability and validation latency targets

---

## Customer Experience

As a tenant admin, I onboard SAP FI. Instead of deciphering cryptic tables, I open the global catalog. I select SKA1. The schema header shows governance: owner, lifecycle, approvals, payload reference. The payload defines columns, keys, constraints, and DQC rules. If I need a variant, I request it. Once approved, the variant payload is released with its own reference.

When analysts bind a KPI schema-for example, `kpi_inputs_liquidity`-they know exactly which GDP schemas it references and which source payloads back it. For AI, the same applies: feature stores reference GDP schemas, add privacy contracts, and declare evaluation thresholds. Schema Services guarantees that no model activates unless the schema passes DQC.

---

## Anticipated Objections

* *Isn’t this over-engineered?* No. The cost of rediscovery and drift is higher. A schema contract prevents invisible failures and enforces trust.
* *Can dbt handle this?* dbt manages transformations. It does not provide a global registry, tenant governance, or AI-specific contracts.
* *What about constant change?* Semantic versioning absorbs safe changes as MINOR or PATCH. MAJOR changes force explicit migration, protecting consumers.

---

## Principles

* Contract first: schemas exist before data connection.
* Separation of concerns: headers govern, payloads define.
* Signed and versioned: payloads are hashed; no drift is invisible.
* Fail closed: no pipeline or model runs without passing DQC.
* Tenant simplicity: admins select, request, release. No reverse-engineering.

---

## Examples

### Source Schema - Header

```json
{
  "schema_id": "src_sap_fi_ska1_v1",
  "category": "Source",
  "type": "Table",
  "provider": "SAP",
  "source_protocol": "OData v2",
  "domain": "Finance",
  "module": "FI",
  "version": "1.1.0",
  "scope": "Global",
  "lifecycle": "Released",
  "owner": "Finance Data Engineering",
  "consumers": ["TenantA_Finance", "TenantB_Audit"],
  "approvals": ["SME_Finance"],
  "payload_ref": "payload_ska1_v1"
}
```

### Source Schema - Payload

```json
{
  "payload_id": "payload_ska1_v1",
  "columns": [
    { "name": "KTOPL", "logical_type": "STRING", "length": 4, "nullable": false, "ordinal": 1 },
    { "name": "SAKNR", "logical_type": "STRING", "length": 10, "nullable": false, "ordinal": 2 },
    { "name": "KTOKS", "logical_type": "STRING", "length": 4, "nullable": true, "ordinal": 3 },
    { "name": "SPERR", "logical_type": "BOOL", "nullable": true, "ordinal": 4 },
    { "name": "XLOEV", "logical_type": "BOOL", "nullable": true, "ordinal": 5 }
  ],
  "keys": { "primary": ["KTOPL", "SAKNR"] },
  "constraints": [],
  "dqc_profile": {
    "rules": [
      { "id": "strict_column_order", "level": "Block" },
      { "id": "schema_signature_match", "level": "Block", "config": { "expected_signature": "sha256:6a4c...b9" } }
    ]
  },
  "enforcement_mode": "position_bound",
  "validation_policy": "Block",
  "signature": "sha256:6a4c...b9",
  "lineage": { "provider_dict": "SAP-DDIC:FI:SKA1" },
  "profiling_stats": { "row_count": 0 }
}
```
!!! example "Use Case"
    Tenant admin onboarding SAP FI (FI-SKA1).  
    Instead of reverse-engineering SAP DDIC, they simply select the released schema.  
    Schema Service guarantees correct column order and flags drift if SAP upgrades change field length or position.  

!!! note "User PoV"
    - Admin: I don’t need to guess SAP internals; I bind directly to a trusted schema.  
    - Engineer: Pipelines won’t break silently - signature and DQC enforce order.  
    - Analyst: I can trace SKA1 → GDP GL Account confidently.  

---

### GDP Schema - Header

```json
{
  "schema_id": "gdp_gl_account_v1",
  "category": "GDP",
  "type": "Master",
  "domain": "Finance",
  "name": "g_gl_account",
  "version": "1.0.0",
  "scope": "Global",
  "lifecycle": "Released",
  "owner": "Finance Data Engineering",
  "payload_ref": "payload_gdp_gl_account_v1",
  "validation_policy": "Block"
}
```

### GDP Schema - Payload

```json
{
  "payload_id": "payload_gdp_gl_account_v1",
  "columns": [
    { "name": "chart_of_accounts", "logical_type": "STRING", "length": 4, "nullable": false, "semantics": ["master.gl_account.chart"], "ordinal": 1 },
    { "name": "gl_account", "logical_type": "STRING", "length": 10, "nullable": false, "semantics": ["master.gl_account.id"], "ordinal": 2 },
    { "name": "account_group", "logical_type": "STRING", "length": 4, "nullable": true, "ordinal": 3 },
    { "name": "is_balance_sheet", "logical_type": "BOOL", "nullable": true, "ordinal": 4 },
    { "name": "is_pl", "logical_type": "BOOL", "nullable": true, "ordinal": 5 },
    { "name": "short_text", "logical_type": "STRING", "length": 40, "nullable": true, "classifications": ["text"], "ordinal": 6 }
  ],
  "keys": {
    "primary": ["chart_of_accounts", "gl_account"],
    "foreign": [ { "columns": ["chart_of_accounts"], "target": "g_chart_of_accounts(chart_of_accounts)" } ]
  },
  "bindings": {
    "sources": [
      { "provider": "SAP", "module": "FI", "name": "SKA1", "version": "1.1.0", "mapping_ref": "map_ska1_to_g_gl_account_v1" },
      { "provider": "SAP", "module": "FI", "name": "SKAT", "version": "1.0.0", "mapping_ref": "map_skat_to_g_gl_account_v1" }
    ]
  },
  "constraints": [ { "name": "account_type_coherence", "expr": "(is_balance_sheet XOR is_pl) IS TRUE" } ]
}
```
!!! example "Use Case"
    Cxofacts team provides a conformed ‘GL Account’ schema across all tenants.  
    It abstracts SKA1 + SKAT into a simple, business-oriented GDP table.  
    Schema Service tracks mappings, so if SAP changes, only GDP mapping updates - tenant KPIs remain stable.  

!!! note "User PoV"
    - SME: I approve this GDP schema once; all tenants consume the same standard.  
    - Tenant Analyst: I don’t care which SAP tables are underneath; I see a clean `g_gl_account`.  
    - Data Engineer: No repeated ETL for each tenant - reuse global payloads.  

---

### KPI Schema - Header

```json
{
  "schema_id": "kpi_inputs_liquidity_v1",
  "category": "KPI",
  "type": "Input",
  "domain": "Finance",
  "name": "kpi_inputs_liquidity",
  "version": "1.0.0",
  "scope": "Global",
  "lifecycle": "Released",
  "payload_ref": "payload_kpi_inputs_liquidity_v1",
  "validation_policy": "Block"
}
```

### KPI Schema - Payload

```json
{
  "payload_id": "payload_kpi_inputs_liquidity_v1",
  "columns": [
    { "name": "posting_date", "logical_type": "DATE", "nullable": false, "ordinal": 1 },
    { "name": "customer_id", "logical_type": "STRING", "nullable": false, "ordinal": 2 },
    { "name": "open_ar_amount", "logical_type": "DECIMAL(18,2)", "nullable": false, "semantics": ["amount.net"], "ordinal": 3 },
    { "name": "currency", "logical_type": "STRING", "length": 5, "nullable": false, "ordinal": 4 }
  ],
  "bindings": { "gdp": [
    { "name": "g_ar_invoice_header", "version": "1.1.0", "role": "input_base" },
    { "name": "g_ar_payment", "version": "1.0.0", "role": "settlement" }
  ]},
  "constraints": [ { "name": "amount_non_negative", "expr": "open_ar_amount >= 0" } ]
}
```

!!! example "Use Case"
    Finance analyst needs liquidity KPIs.  
    The KPI schema binds directly to GDP schemas for invoices and payments.  
    Business rules (amount ≥ 0) are enforced by payload DQC.  

!!! note "User PoV"
    - Analyst: I get KPI inputs already mapped and validated.  
    - Admin: I can explain KPI definitions clearly - they are linked to GDP.  
    - Data Engineer: I no longer get ad-hoc SQL requests; KPI schemas are contracts.  

---

### AI Schema - Header

```json
{
  "schema_id": "ai_fv_customer_credit_risk_v1",
  "category": "AI",
  "type": "Feature Store",
  "ai_kind": "ml_feature_store",
  "use_case": "credit_risk",
  "model_family": "xgboost",
  "serving_mode": "online",
  "domain": "Finance",
  "name": "fv_customer_credit_risk_v1",
  "version": "1.0.0",
  "scope": "Global",
  "lifecycle": "Released",
  "payload_ref": "payload_ai_fv_customer_credit_risk_v1",
  "validation_policy": "Block"
}
```

### AI Schema - Payload

```json
{
  "payload_id": "payload_ai_fv_customer_credit_risk_v1",
  "columns": [
    { "name": "customer_id", "logical_type": "STRING", "nullable": false, "classifications": ["business_key"], "ordinal": 1 },
    { "name": "avg_days_past_due_90d", "logical_type": "DECIMAL(9,3)", "nullable": false, "ordinal": 2 },
    { "name": "invoices_last_30d", "logical_type": "INT", "nullable": false, "ordinal": 3 },
    { "name": "total_outstanding", "logical_type": "DECIMAL(18,2)", "nullable": false, "semantics": ["amount.net"], "ordinal": 4 },
    { "name": "is_high_risk_label", "logical_type": "BOOL", "nullable": true, "ordinal": 5 }
  ],
  "bindings": { "gdp": [
    { "name": "g_ar_invoice_header", "version": "1.1.0", "role": "base", "transform_ref": "tx_fv_crisk_v1.sql" },
    { "name": "g_ar_payment", "version": "1.0.0", "role": "settlement", "transform_ref": "tx_fv_crisk_v1.sql" }
  ]},
  "privacy": { "pii": false, "dlp_policy_ref": "dlp_std_001", "consent_basis": "contract", "retention_days": 365, "locality": "in-region" },
  "eval_contract": { "metrics": { "auc": { "min": 0.78 }, "ks": { "min": 0.25 } } }
}
```
!!! example "Use Case"
    Risk team trains a credit risk ML model.  
    Schema Service defines feature store payload (days past due, invoices count, etc.) and enforces privacy and evaluation contracts.  
    If features drift, schema events alert ML ops.  

!!! note "User PoV"
    - Data Scientist: I trust features are stable across retrains.  
    - Compliance Officer: PII and DLP policies are encoded in the schema itself.  
    - Ops: If accuracy drops below contract, schema alerts fire automatically.  
---

---

## Canonical Meta-Schema

To prevent ambiguity and enforce consistency, a canonical JSON Schema (Draft 2020-12) defines the authoritative structure of a Schema Object.  
This Markdown file provides the conceptual narrative, but all programmatic validation and API contracts must reference the JSON file.

- Meta-schema JSON: `/schema_services/schema-object-meta.json`  
- Examples:  
  - Source: `/schema_services/examples/source-example.json`  
  - GDP: `/schema_services/examples/gdp-example.json`  
  - KPI: `/schema_services/examples/kpi-example.json`  
  - AI: `/schema_services/examples/ai-example.json`  

!!! note "Future Reference" 
    OpenAPI specifications, Registry DDL, and validations will reference this meta-schema directly.

---

## Exclusions

The Schema Object envelope is immutable per version. Do not embed the following in the envelope:

- Counters or telemetry (success/failure counts, last_used_at)  
- Tenant rosters, consumer bindings, or overrides  
- Runtime metadata from pipelines or runs  

These live in Schema Registry - Associations & Telemetry, a companion resource that tracks consumers, tenant bindings, runs, and usage.