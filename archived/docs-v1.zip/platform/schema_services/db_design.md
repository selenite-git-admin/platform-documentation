# Schema Services Database Design

![status-draft](https://img.shields.io/badge/status-draft-yellow)
![last_updated-2025-08-28%2010:39%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2010:39%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This document defines the physical and logical design for the Schema Services datastore. It turns the selection rationale into concrete structures, policies, and operational playbooks. The scope covers both the System of Record and Telemetry paths.

!!! info "Target Engine"
    Engine target is Amazon Aurora PostgreSQL Serverless v2. 
    The design keeps PostgreSQL‑portable constructs where possible.

## Principles

- Contract‑first and immutable versioning for schema envelopes.
- Minimize writes on the System of Record; use append‑only on telemetry.
- Every read and write is tenant‑aware; Row Level Security enforces isolation.
- Predictable performance through partitioning and appropriate indexes.
- Migrations are forward‑only; rollbacks use new versions and retire old ones.
- Observability and cost are first‑class; no hidden work in triggers without monitoring.
- Warehouse sync via logical replication; avoid ad‑hoc ETL against the primary.

## Requirements Recap

| Area          | Must haves                                                                                                                        |
|---------------|-----------------------------------------------------------------------------------------------------------------------------------|
| Entities      | schema, schema_version, approval, lineage_edge, binding, consumer, schema_consumption, tenant_binding, schema_run, usage_snapshot |
| Multi‑tenancy | Global, provider, and tenant scopes with isolation and audit                                                                      |
| Search        | By category, kind, tags, and name prefix; JSONB predicates on envelope payload                                                    |
| Availability  | System of Record 99.95 percent; telemetry 99.9 percent                                                                            |
| Latency (P95) | System of Record 50 ms; telemetry appends 30 ms                                                                                   |
| Scale horizon | 50k schemas; 500k versions; 2–5 billion runs per year                                                                             |

!!! note "Authoritative DDL"
    DDL in this page is authoritative for implementation. Changes follow the migration policy below.

## Conventions

| Topic        | Rule                                                               |
|--------------|--------------------------------------------------------------------|
| Namespaces   | Use schema namespace `registry`                                    |
| Identifiers  | `snake_case`, singular table names                                 |
| Primary keys | Synthetic UUID unless a natural key is stable                      |
| Timestamps   | `timestamptz`; include `created_at` and `updated_at` where mutable |
| Envelope     | JSONB stored in `schema_version.envelope_json`                     |
| Lifecycle    | `governance_state` as text with `CHECK` constraints                |
| Foreign keys | `ON DELETE RESTRICT` unless stated otherwise                       |
| Indexes      | Name as ``ix_<table>__<cols>``                                     |
| RLS          | Enable per table and add explicit policies                         |
| Partitioning | Monthly by `started_at` on `schema_run`                            |

## ERD

!!! info
    Paste the below DBML into dbdiagram.io, adjust the layout if needed.

```dbml
Project "Schema Services - Registry & Telemetry" {
  database_type: "PostgreSQL"
}

Enum category {
  source
  gdp
  kpi
  ai
}

Enum governance_state {
  draft
  in_review
  approved
  released
  deprecated
  retired
}

Enum role {
  author
  reviewer
  approver
  operator
}

Enum decision {
  approved
  rejected
  changes_requested
}

Enum relation {
  derives_from
  joins
  aggregates
  calculates_from
  feeds
  duplicates
}

Enum environment {
  dev
  test
  stage
  prod
}

Enum run_type {
  validate
  load
  serve
}

Enum run_status {
  success
  failed
  partial
}

Table schema {
  schema_id      uuid [pk]
  name           text [not null, unique]
  display_name   text
  category       text [note: 'one of category enum']
  owner          jsonb
  tags           text[]
  description    text
  links          jsonb
  created_at     timestamptz [not null, default: `now()`]
  updated_at     timestamptz

  Note: 'system of record; one-to-many schema_version'
}

Table schema_version {
  schema_id        uuid [not null]
  version          text [not null]
  envelope_json    jsonb [not null]
  governance_state text [not null, note: 'one of governance_state enum']
  created_at       timestamptz [not null, default: `now()`]

  indexes {
    (schema_id, version) [pk]
    (schema_id, created_at) [name: 'ix_schema_version__schema_created']
    envelope_json [name: 'ix_schema_version__envelope', note: 'GIN(jsonb_path_ops) in PostgreSQL']
  }

  Note: 'immutable envelope per (schema_id, version)'
}

Table approval {
  schema_id uuid [not null]
  version   text [not null]
  role      text [not null, note: 'one of role enum']
  decision  text [not null, note: 'one of decision enum']
  at        timestamptz [not null, default: `now()`]
  by        text [not null]
  comment   text

  indexes {
    (schema_id, version, role, at) [pk]
  }
}

Table lineage_edge {
  schema_id      uuid [not null]
  version        text [not null]
  from_schema_id uuid [not null]
  from_version   text [not null]
  relation       text [not null, note: 'one of relation enum']
  note           text

  indexes {
    (schema_id, version, from_schema_id, from_version, relation) [pk]
  }

  Note: 'explicit upstream edge; also references upstream version'
}

Table binding {
  schema_id        uuid [not null]
  version          text [not null]
  target_schema_id uuid [not null]
  target_category  text [not null, note: 'one of category enum']
  mapping_ref      text
  note             text

  indexes {
    (schema_id, version, target_schema_id) [pk]
  }
}

Table consumer {
  consumer_id uuid [pk]
  name        text [not null]
  type        text [not null, note: 'bi|etl|agent|service|other']
  owner       jsonb
  links       jsonb
}

Table schema_consumption {
  schema_id   uuid [not null]
  version     text [not null]
  consumer_id uuid [not null]
  environment text [not null, note: 'one of environment enum']
  mode        text

  indexes {
    (schema_id, version, consumer_id) [pk]
  }
}

Table tenant_binding {
  schema_id         uuid [not null]
  version           text [not null]
  tenant_id         text [not null]
  environment       text [not null, note: 'one of environment enum']
  effective_version text [not null]
  effective_from    timestamptz [not null, default: `now()`]
  effective_to      timestamptz
  override          boolean [not null, default: false]

  indexes {
    (schema_id, version, tenant_id, environment, effective_from) [pk]
  }
}

Table schema_run {
  run_id      uuid [pk]
  schema_id   uuid [not null]
  version     text [not null]
  tenant_id   text
  environment text [note: 'one of environment enum']
  run_type    text [note: 'one of run_type enum']
  status      text [note: 'one of run_status enum']
  started_at  timestamptz [not null]
  finished_at timestamptz
  duration_ms int
  rows_in     bigint
  rows_out    bigint
  error_count int
  error_ref   text
  trace_id    text

  indexes {
    (schema_id, version, started_at) [name: 'ix_schema_run__schema_version_time']
    (tenant_id, started_at)          [name: 'ix_schema_run__tenant_time']
    started_at                       [name: 'partition_key_hint', note: 'monthly RANGE partitions in PostgreSQL']
  }

  Note: 'append-only telemetry; partitioned monthly by started_at; consider partial index on status=failed'
}

/* Relationships */
Ref: schema_version.schema_id > schema.schema_id
Ref: approval.(schema_id, version) > schema_version.(schema_id, version)
Ref: lineage_edge.(schema_id, version) > schema_version.(schema_id, version)
Ref: lineage_edge.(from_schema_id, from_version) > schema_version.(schema_id, version)
Ref: binding.(schema_id, version) > schema_version.(schema_id, version)
Ref: binding.target_schema_id > schema.schema_id
Ref: schema_consumption.(schema_id, version) > schema_version.(schema_id, version)
Ref: schema_consumption.consumer_id > consumer.consumer_id
Ref: tenant_binding.(schema_id, version) > schema_version.(schema_id, version)
Ref: schema_run.schema_id > schema.schema_id
```

![schema_services_db.svg](../../assets/diagrams/schema-services/erd.svg){ style="display\:block; margin: 1.5rem auto;" }

## DDL

The statements assume a clean database and a user with privileges to create schemas, types, and extensions.

```sql
CREATE SCHEMA IF NOT EXISTS registry;

-- Optional, improves diagnostics
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
```

### Core Tables

```sql
CREATE TABLE registry.schema (
  schema_id      UUID PRIMARY KEY,
  name           TEXT NOT NULL UNIQUE,
  display_name   TEXT,
  category       TEXT NOT NULL CHECK (category IN ('source','gdp','kpi','ai')),
  owner          JSONB,
  tags           TEXT[] DEFAULT ARRAY[]::TEXT[],
  description    TEXT,
  links          JSONB,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ
);

CREATE TABLE registry.schema_version (
  schema_id        UUID NOT NULL REFERENCES registry.schema(schema_id) ON DELETE RESTRICT,
  version          TEXT NOT NULL,
  envelope_json    JSONB NOT NULL,
  governance_state TEXT NOT NULL CHECK (governance_state IN ('draft','in_review','approved','released','deprecated','retired')),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (schema_id, version)
);

CREATE INDEX ix_schema_version__schema_created ON registry.schema_version (schema_id, created_at DESC);
CREATE INDEX ix_schema_version__envelope ON registry.schema_version USING GIN (envelope_json jsonb_path_ops);

CREATE TABLE registry.approval (
  schema_id UUID NOT NULL,
  version   TEXT NOT NULL,
  role      TEXT NOT NULL CHECK (role IN ('author','reviewer','approver','operator')),
  decision  TEXT NOT NULL CHECK (decision IN ('approved','rejected','changes_requested')),
  at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  by        TEXT NOT NULL,
  comment   TEXT,
  PRIMARY KEY (schema_id, version, role, at),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

CREATE TABLE registry.lineage_edge (
  schema_id      UUID NOT NULL,
  version        TEXT NOT NULL,
  from_schema_id UUID NOT NULL,
  from_version   TEXT NOT NULL,
  relation       TEXT NOT NULL CHECK (relation IN ('derives_from','joins','aggregates','calculates_from','feeds','duplicates')),
  note           TEXT,
  PRIMARY KEY (schema_id, version, from_schema_id, from_version, relation),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

CREATE TABLE registry.binding (
  schema_id        UUID NOT NULL,
  version          TEXT NOT NULL,
  target_schema_id UUID NOT NULL,
  target_category  TEXT NOT NULL CHECK (target_category IN ('source','gdp','kpi','ai')),
  mapping_ref      TEXT,
  note             TEXT,
  PRIMARY KEY (schema_id, version, target_schema_id),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

CREATE TABLE registry.consumer (
  consumer_id UUID PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL CHECK (type IN ('bi','etl','agent','service','other')),
  owner       JSONB,
  links       JSONB
);

CREATE TABLE registry.schema_consumption (
  schema_id   UUID NOT NULL,
  version     TEXT NOT NULL,
  consumer_id UUID NOT NULL REFERENCES registry.consumer(consumer_id) ON DELETE RESTRICT,
  environment TEXT NOT NULL CHECK (environment IN ('dev','test','stage','prod')),
  mode        TEXT,
  PRIMARY KEY (schema_id, version, consumer_id),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);
```

### Tenant Bindings

```sql
CREATE TABLE registry.tenant_binding (
  schema_id         UUID NOT NULL,
  version           TEXT NOT NULL,
  tenant_id         TEXT NOT NULL,
  environment       TEXT NOT NULL CHECK (environment IN ('dev','test','stage','prod')),
  effective_version TEXT NOT NULL,
  effective_from    TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_to      TIMESTAMPTZ,
  override          BOOLEAN NOT NULL DEFAULT false,
  PRIMARY KEY (schema_id, version, tenant_id, environment, effective_from),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);
```

### Telemetry Runs With Partitioning

```sql
CREATE TABLE registry.schema_run (
  run_id      UUID PRIMARY KEY,
  schema_id   UUID NOT NULL,
  version     TEXT NOT NULL,
  tenant_id   TEXT,
  environment TEXT CHECK (environment IN ('dev','test','stage','prod')),
  run_type    TEXT CHECK (run_type IN ('validate','load','serve')),
  status      TEXT CHECK (status IN ('success','failed','partial')),
  started_at  TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ,
  duration_ms INTEGER,
  rows_in     BIGINT,
  rows_out    BIGINT,
  error_count INTEGER,
  error_ref   TEXT,
  trace_id    TEXT
) PARTITION BY RANGE (started_at);

-- Example current month partition
CREATE TABLE IF NOT EXISTS registry.schema_run_2025_08 PARTITION OF registry.schema_run
  FOR VALUES FROM ('2025-08-01') TO ('2025-09-01');

-- Indexes on the parent propagate to children created after the index exists
CREATE INDEX IF NOT EXISTS ix_schema_run__schema_version_time ON registry.schema_run (schema_id, version, started_at DESC);
CREATE INDEX IF NOT EXISTS ix_schema_run__tenant_time ON registry.schema_run (tenant_id, started_at DESC);
CREATE INDEX IF NOT EXISTS ix_schema_run__failures ON registry.schema_run (schema_id, started_at DESC) WHERE status = 'failed';
```

## RLS Policies

RLS is enabled on telemetry and binding tables. The application sets the session variable `app.current_tenant` or uses a JWT claim mapped to a function.

```sql
ALTER TABLE registry.tenant_binding ENABLE ROW LEVEL SECURITY;
ALTER TABLE registry.schema_run     ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION registry.current_tenant() RETURNS text
LANGUAGE sql STABLE AS $$
  SELECT current_setting('app.current_tenant', true)
$$;

CREATE POLICY tenant_binding_isolation ON registry.tenant_binding
  USING (tenant_id = registry.current_tenant());

CREATE POLICY schema_run_isolation ON registry.schema_run
  USING (tenant_id IS NULL OR tenant_id = registry.current_tenant());
```

!!! note
    If using JWT claims through PgBouncer, pass them as separate parameters and set `app.current_tenant` on connect.

## Partition Rotation

Two options are supported: `pg_cron` inside Aurora if available, or CloudWatch Events plus a Lambda that runs `psql`.

```sql
-- Rotation helper
CREATE OR REPLACE FUNCTION registry.ensure_run_partitions(months_ahead int DEFAULT 3) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE
  start_month date := date_trunc('month', now())::date;
  m int;
  from_date date;
  to_date date;
  part_name text;
BEGIN
  FOR m IN 0..months_ahead LOOP
    from_date := (start_month + make_interval(months => m))::date;
    to_date   := (start_month + make_interval(months => m + 1))::date;
    part_name := format('schema_run_%s', to_char(from_date, 'YYYY_MM'));

    EXECUTE format(
      'CREATE TABLE IF NOT EXISTS registry.%I PARTITION OF registry.schema_run FOR VALUES FROM (%L) TO (%L)',
      part_name, from_date, to_date
    );
  END LOOP;
END;
$$;
```

If `pg_cron` is available:

```sql
CREATE EXTENSION IF NOT EXISTS pg_cron;
SELECT cron.schedule('ensure-partitions-daily', '15 2 * * *', $$SELECT registry.ensure_run_partitions(3);$$);
```

Else schedule the same call from Lambda with an IAM role that connects to the cluster.

## Parameter Profile

| Parameter                           | Suggested                 | Reason                                           |
|-------------------------------------|---------------------------|--------------------------------------------------|
| idle_in_transaction_session_timeout | 60000                     | Prevent pinned sessions that block scale‑down    |
| statement_timeout                   | 60000                     | Guardrail against runaway queries                |
| work_mem                            | 16MB                      | Safe default for small ACU; tune with benchmarks |
| maintenance_work_mem                | 256MB                     | Faster index build during deploy windows         |
| autovacuum_vacuum_scale_factor      | 0.1                       | More predictable vacuuming on large tables       |
| autovacuum_analyze_scale_factor     | 0.05                      | Fresher stats for the planner                    |
| shared_preload_libraries            | pg_stat_statements        | Visibility into workload                         |
| max_connections                     | Size according to min ACU | Match pool sizing to prevent thrash              |

!!! info
    Parameter groups vary by Aurora version. Set these in a dedicated parameter group and apply to the cluster.

## Migration Policy

- Versioned migrations using Flyway or Liquibase, stored in the repo.
- Forward‑only for structural changes; destructive changes retire old objects after data backfill.
- Blue/green or shadow deploys for risky changes.
- Do not run ad‑hoc DDL in production outside the migration pipeline.
- Keep a rollback plan that restores the previous database snapshot.

## CDC And Warehouse

- Enable logical replication at the cluster parameter group.
- Create a publication for change tables.
- Consume with a managed connector or Debezium and write to the warehouse.

```sql
-- Example publication
CREATE PUBLICATION registry_pub FOR TABLE
  registry.schema,
  registry.schema_version,
  registry.approval,
  registry.lineage_edge,
  registry.binding,
  registry.consumer,
  registry.schema_consumption,
  registry.tenant_binding,
  registry.schema_run;
```

## Observability And SLO

- Enable `pg_stat_statements` and export to metrics.
- Ship logs to CloudWatch; alert on slow statements over 2 seconds.
- Dashboards for CPU, connections, buffer cache hit ratio, checkpoint distance, and replication lag.
- Synthetic probes for connection and simple `SELECT` latency.
- Error budget defined on P95 latency and availability.

## Sizing Guide

| stage | min max acu | topology               | notes                                        |
|-------|-------------|------------------------|----------------------------------------------|
| dev   | 0 to 1      | single az, no replicas | cheapest; auto pause on                      |
| mvp   | 0.5 to 2    | single az, no replicas | tighten idle timeouts and pool sizes         |
| beta  | 1 to 4      | multi az, 1 reader     | turn off auto pause; higher max connections  |
| ga    | 2 to 8      | multi az, n readers    | consider i o optimized if i o dominates cost |

## API Alignment

All write and read paths map one‑to‑one with OpenAPI routes. Envelopes are immutable after the release state. Lifecycle transitions change `governance_state` only through controlled endpoints.

## Next Steps

- Create a dev cluster with a parameter group and apply this DDL.
- Wire RLS context in the application connection layer.
- Stand up partition rotation and basic alarms.
- Run the benchmark harness against W1–W6 and record results.
