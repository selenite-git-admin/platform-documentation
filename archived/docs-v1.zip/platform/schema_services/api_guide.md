# API Guide - Schema Registry

![status-stable](https://img.shields.io/badge/status-stable-brightgreen)
![last_updated-2025-08-28%2014:35%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2014:35%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This guide explains how to use the schema registry safely and predictably. It covers authentication, tenancy, idempotency, pagination, errors, caching, rate limits, versioning, and operational boundaries. Use it with the interactive OpenAPI reference.

!!! info
    Headings use title case. Body text uses sentence case. There is no numbering in headings and no bold words in the body.

## Overview

The schema registry is a contract‑first API for managing schema objects, versions, validation, lifecycle, lineage, bindings, and telemetry. Write operations are idempotent. Read operations are cacheable and conditional.

## Base URL And Versions

- Base URL: `https://api.cxofacts.com`
- API versioning: the HTTP surface is compatible within a major version. Breaking changes require a new path or a new version tag in the spec.
- Spec version: the OpenAPI spec is published under the documentation site and versioned in source control.

!!! note
    The schema envelope format is immutable for a given version once released. A new schema version is required to change the envelope payload.

## Authentication

- Use Bearer JWT in the `Authorization` header.
- Tokens must include tenant and scope claims as issued by your identity provider.
- Do not send tokens in query parameters.

Example:
```bash
curl -H "Authorization: Bearer <token>" https://api.cxofacts.com/schemas
```

## Tenancy

- Multi‑tenant isolation is enforced with row level security.
- The optional `X-Tenant-Id` header selects the target tenant when the token is scoped to more than one tenant.
- All write and read paths are tenant‑aware. Cross‑tenant reads are rejected or return zero rows.

!!! info
    If you use a connection pooler, ensure the tenant claim is set on every connection checkout to avoid cross‑tenant leakage.

## Idempotency

- All write operations require the `Idempotency-Key` header.
- The server stores the first successful response for a key and request hash.
- A repeat request with the same key and body returns the same response with status 200.
- A repeat request with the same key but a different body returns 409 Conflict.

Example:
```bash
curl -X POST https://api.cxofacts.com/schemas   -H "Authorization: Bearer <token>"   -H "Content-Type: application/json"   -H "Idempotency-Key: 123e4567"   -d '{"name":"gdp_gl_header","category":"gdp"}'
```

## Pagination

- Pagination uses `limit` and cursor‑based continuation tokens.
- `limit` bounds are 1–200. The default is 50.
- Cursors are opaque. Do not construct or parse them.

## Error Model

All non‑2xx responses use `application/problem+json` with stable fields.

```json
{
  "type": "https://errors.cxofacts.com/schema/validation",
  "title": "validation failed",
  "status": 422,
  "detail": "envelope_json.kind is required",
  "instance": "/schemas/1a2b/versions/1.0.0",
  "errors": [{"path":"envelope_json.kind","message":"required"}]
}
```

Common status codes:
- 400 for client contract error
- 401 for unauthenticated
- 403 for forbidden
- 404 for not found
- 409 for conflict such as idempotency hash mismatch
- 422 for validation error
- 429 for rate limited
- 5xx for server fault

## Caching And Concurrency

- Successful reads return an `ETag` header.
- Send `If-None-Match` with the previously returned ETag to receive 304 when unchanged.
- Concurrent writes are serialized by idempotency and version rules.

Example:
```bash
ETAG=$(curl -si https://api.cxofacts.com/schemas/<id> | awk -F': ' '/^ETag/{print $2}')
curl -s -H "If-None-Match: $ETAG" https://api.cxofacts.com/schemas/<id>
```

## Rate Limits And Retries

- The service may return 429 with a `Retry-After` header.
- Use exponential backoff with jitter for client retries.
- Do not retry non‑idempotent requests without a valid idempotency key.

!!! note
    Treat timeouts as unknown outcomes. Replay only if an idempotency key was sent and you can tolerate a 200 response on duplicate.

## Versioning

- Schema versions follow semantic versioning where practical.
- Released versions are immutable. Changes require a new version.

## Resource Naming And Identifiers

- Identifiers are case‑insensitive UUIDs or safe strings limited to letters, digits, dash, and underscore.
- Avoid embedding semantic meaning into identifiers. Use metadata fields for meaning and search.

## Request And Response Examples

Create a schema:
```bash
curl -X POST https://api.cxofacts.com/schemas   -H "Authorization: Bearer <token>"   -H "Content-Type: application/json"   -H "Idempotency-Key: 9b2c"   -d '{"name":"sales_order","category":"gdp","owner":{"team":"data-platform"}}'
```

Create a version:
```bash
curl -X POST https://api.cxofacts.com/schemas/<schema_id>/versions   -H "Authorization: Bearer <token>"   -H "Content-Type: application/json"   -H "Idempotency-Key: 77aa"   -d '{"version":"1.0.0","envelope_json":{"kind":"table","fields":[{"name":"id","type":"uuid"}]}}'
```

## Security Considerations

- Prefer short‑lived tokens and least‑privilege scopes.
- Never log secrets or tokens. Redact the `Authorization` header in logs.
- Avoid sending sensitive data in URL query parameters.

## Change Management And Compatibility

- Server changes are validated against the spec and examples in continuous integration.
- Backward‑incompatible changes trigger a new version and deprecation plan.
- The change log is maintained in source control and rendered in the documentation site.

## Client Checklist

- Send Bearer token in the `Authorization` header.
- Include `Idempotency-Key` on all writes.
- Honor `Retry-After` on 429 responses.
- Store and send `ETag` for cacheable reads.
- Never assume a cursor format.
- Validate inputs before sending and handle `problem+json` consistently.

---

## Environments

| Environment | Base URL                     | Auth notes              | Rate limits      |
|-------------|------------------------------|-------------------------|------------------|
| Dev         | https://dev.api.cxofacts.com | Test tenants and tokens | Low limits       |
| Staging     | https://stg.api.cxofacts.com | Production‑like scopes  | Medium limits    |
| Production  | https://api.cxofacts.com     | Production scopes       | Published limits |

!!! note
    Production tokens do not work on non‑production environments. Avoid cross‑environment data moves.

## Headers

| Header          | Required    | Purpose                   | Constraints                   |
|-----------------|-------------|---------------------------|-------------------------------|
| Authorization   | Yes         | Bearer JWT                | Max 8 KB                      |
| Idempotency-Key | Writes      | Deduplicate retries       | ASCII, 1–128 chars            |
| X-Tenant-Id     | Conditional | Explicit tenant selection | Safe string                   |
| X-Request-Id    | Optional    | Request tracing           | Client generated; echoed back |
| If-None-Match   | Optional    | Conditional GET           | An ETag value                 |

## Idempotency Semantics

- The server computes a request hash from the method, path, and the canonicalized subset of the JSON body.
- The first successful response for a key is stored for the TTL and returned for repeats with status 200.
- A repeat with the same key but a different hash returns 409 Conflict.

| Setting        | Value                        |
|----------------|------------------------------|
| Key TTL        | 24 hours                     |
| Max key length | 128                          |
| Stored fields  | Method, path, canonical body |

## Error Catalog

| Type                                             | Status | When it happens                                 |
|--------------------------------------------------|--------|-------------------------------------------------|
| https://errors.cxofacts.com/common/validation    | 422    | Schema or parameter validation failed           |
| https://errors.cxofacts.com/common/conflict      | 409    | Idempotency key reused with a different payload |
| https://errors.cxofacts.com/common/not_found     | 404    | Resource was not found                          |
| https://errors.cxofacts.com/auth/unauthenticated | 401    | Token is missing or invalid                     |
| https://errors.cxofacts.com/auth/forbidden       | 403    | Token lacks scope or tenant access              |

## Limits And Quotas

| Limit                  | Value                   |
|------------------------|-------------------------|
| Max request payload    | 1 MB                    |
| Max envelope_json size | 256 KB                  |
| Max tags per schema    | 50                      |
| Pagination limit range | 1–200 (default 50)      |
| Write burst            | 100 RPS for ten seconds |
| Write sustained        | 20 RPS per tenant       |

!!! info
    Limits may evolve. Clients should not hard code error message text and must handle 413 and 429 responses.

## Time And Formats

- Timestamps follow RFC 3339 with timezone, for example `2025-08-28T12:34:56Z`.
- Query parameters accept `from` and `to` in the same format. Use UTC if possible.

## Sorting And Filtering

- Sorting defaults to created time descending unless specified.
- Stable pagination is guaranteed only when the sort order is deterministic.
- Filtering allows name prefix, category, tags, and governance state.

## Caching And ETag

- The service returns strong ETags unless noted. ETags change when any field in the payload changes.
- Cache‑Control may include `no-store` on endpoints that return sensitive data.

## Request Tracing

- The service returns `X-Request-Id` on all responses. If the client sends one, it is echoed back.
- Include this id when reporting issues.

## CORS Policy

- Allowed origins are the documentation site and registered first‑party apps.
- Allowed methods are GET, POST, PATCH, and DELETE.
- Allowed headers include Authorization, Idempotency-Key, If-None-Match, and Content-Type.

## Deprecation And Sunset

- Breaking changes are introduced under a new path or a new version.
- Deprecated endpoints include `Sunset` and `Deprecation` headers where applicable.
- The standard window is ninety days unless otherwise announced.

## Support And Operations

- Standard SLO is 99.95 percent monthly availability for production.
- Planned maintenance windows are communicated at least seventy‑two hours in advance.
- Incidents are tracked with request ids and published in the status page.
