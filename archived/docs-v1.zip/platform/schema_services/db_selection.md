# Schema Services - Database Selection

![status-draft](https://img.shields.io/badge/status-draft-yellow)
![last_updated-2025-08-28%2009:48%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2009:48%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

Schema Services must act as the source of truth for versioned schema envelopes and governance, while tracking associations and high-volume runs and usage telemetry. This document selects an engine, sets guardrails, and defines the benchmark gates that will either confirm or overturn the choice.

!!!info
    This is a selection narrative, not the full design. db_design.md will carry complete DDL, ERDs, RLS policies, partition rotation, and migration strategy.

## Context

Two distinct workloads drive the choice:
- system of record for contracts and lifecycle with strong consistency and predictable low latency
- telemetry append and read with cost-efficient scale and time-bounded queries

Aurora PostgreSQL Serverless v2 aligns with both, provided partitioning and indexing are applied to telemetry.

## Requirements recap

### Functional scope

| Area | Must haves |
|---|---|
| Entities | schema, schema_version, approval, lineage_edge, binding, consumer, schema_consumption, tenant_binding, schema_run, usage_snapshot |
| Operations | CRUD for schema, create version from envelope, approvals and lifecycle transitions, attach consumers, upsert tenant bindings, append runs, read usage |
| Multi-tenancy | global, provider, tenant scopes with isolation on reads and writes |
| Search | filter by category or kind or tags, free text on name and display_name, optional JSONB predicates on envelope payload |

### Non-functional targets

| Dimension | Target |
|---|---|
| Consistency | strong for system of record, eventual for derived usage |
| Latency p95 | system of record reads and writes 50 ms, telemetry appends 30 ms |
| Throughput | 300 rps read and 60 rps write on system of record, 2k inserts per second baseline on telemetry with 10k per second burst for five minutes |
| Availability | system of record 99.95 percent, telemetry 99.9 percent |
| Durability | system of record RPO 0 and RTO less than 15 minutes, telemetry RPO up to 5 minutes and RTO less than 30 minutes |
| Scale horizon 12 months | 50k schemas, 500k versions, 50k consumers, 1M tenant bindings, 2 to 5 billion runs |
| Security | encryption at rest and in transit, row level security by tenant, audit trail |
| Operations | online migrations, point in time restore, managed metrics |

!!!note
    Targets are gates for a go or no-go decision after benchmark. If a gate fails on telemetry only, a split design with ClickHouse for runs becomes the fallback.

## Candidate shortlist

| Candidate | Why it fits | Risks or tradeoffs | When to pick |
|---|---|---|---|
| Amazon Aurora PostgreSQL Serverless v2 | JSONB for envelopes, RLS for tenant isolation, logical replication to warehouse, serverless pay as you go, partitioned tables | writer pressure if telemetry spikes and poolers pin capacity, need disciplined partitioning and indexes | default if workloads W4 and W5 pass under cost caps |
| CockroachDB managed | scale out and multi region consistency, postgres wire compatibility | potential cost and write amplification at high ingest, some SQL feature mismatches with postgres tooling | consider if active active writes across regions become mandatory |
| Split model: Aurora for system of record plus ClickHouse for telemetry | cost efficient billion row telemetry, vectorized scans | dual writes or CDC complexity, eventual consistency for usage views | adopt only if telemetry gates fail on Aurora |

## Decision

Pick Amazon Aurora PostgreSQL Serverless v2 as the default. Reopen the decision only if the benchmark falsifies it on telemetry ingest or query cost and latency.

## Physical design summary

This is the what, not the how.

- schema_version keeps envelope_json as JSONB with a GIN index using jsonb_path_ops for tags and name predicates
- schema_run is partitioned by month using range on started_at, with composite indexes on schema_id, version, started_at and on tenant_id, started_at; a partial index for failed status accelerates incident drills
- row level security is enabled on tenant_binding and schema_run with policies keyed on a tenant claim
- etag uses an envelope hash or xmin pattern
- point in time restore retention is set to 7 to 14 days
- warehouse sync uses logical replication

db_design.md will provide full DDL and ERDs.

## Cost model and defaults

Aurora Serverless v2 is billed per ACU hour for compute and per GB month for storage. Aurora Standard bills I or O per request while Aurora I or O Optimized removes I or O charges for a higher base. References are at the end.

### Scaling facts

| Topic | Detail |
|---|---|
| ACU step | scales in 0.5 ACU increments |
| Minimum capacity | set 0 or 0.5 ACU for PostgreSQL to allow real scale down; very low min implies a max connections cap around 2000 |
| Auto pause and resume | enable when idle windows exist so the cluster scales to 0 ACU |
| I or O mode choice | start on Standard; switch to I or O Optimized when I or O spend is about a quarter of total Aurora cost |

### MVP profile

| Setting | Recommendation | Rationale |
|---|---|---|
| Cluster type | Serverless v2 on Aurora Standard | cheapest at low traffic and allows scale down |
| Capacity caps | min 0 or 0.5 ACU, max 2 ACU | keeps idle cost low and caps burst until benchmarks justify more |
| Topology | single writer, no replicas, single AZ | minimal cost for dev and MVP; add replicas or multi AZ once external SLA exists |
| Connections | small pools and short idle timeouts | prevents pinned capacity that blocks scale down or auto pause |
| Storage | general purpose with PITR 7 to 14 days | balances durability and cost |
| I or O watch | track I or O share with CloudWatch | flip to I or O Optimized when I or O dominates the bill |

!!!info
    Back of envelope: a cluster idling around 0.5 ACU for a month costs roughly half the published 1 ACU hourly rate in your region for compute, plus storage and small I or O on Standard. Use the AWS pricing page for the exact rate card.

## Ops guardrails

- enable automatic pause and resume where feasible and tune min and max ACU
- ensure poolers release idle connections so scale down happens
- start single AZ and add replicas or multi AZ when SLOs require it
- monitor I or O spend share and switch to I or O Optimized when it crosses the threshold
- pre create telemetry partitions three months ahead and drop expired partitions on schedule
- alert on replication lag, checkpoint stalls, autovacuum backlogs, and slow queries

## Benchmark plan and gates

| Workload | What it proves | Gate |
|---|---|---|
| W1 create version | insert envelope JSONB with lineage and bindings | p95 50 ms at 60 rps |
| W2 list versions | paginate last 50 by schema_id | p95 30 ms at 200 rps |
| W3 search | name prefix plus category or tag filter | p95 30 ms at 150 rps |
| W4 append run | single insert to telemetry | p95 30 ms at 2k rps baseline and 10k rps burst for five minutes |
| W5 runs query | time bounded list for a version over 30 days | p95 80 ms at 100 rps and stable plans |
| W6 usage snapshot | refresh or query derived view | completes in under two minutes at 100M rows per day |

Pass requires all gates met, sustained ingest for thirty minutes without throttle, PITR validated, RLS overhead under five percent, and monthly cost within cap.

## AWS references

- Pricing overview and Standard vs I or O Optimized  
  https://aws.amazon.com/rds/aurora/pricing/
- How Serverless v2 capacity and billing work  
  https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/aurora-serverless-v2.how-it-works.html
- Auto pause and resume for scale to zero capacity  
  https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/aurora-serverless-v2-auto-pause.html
- Launch post for scale to zero capacity with Serverless v2  
  https://aws.amazon.com/blogs/database/introducing-scaling-to-0-capacity-with-amazon-aurora-serverless-v2/
- Storage and I or O mode guidance including the 25 percent threshold  
  https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/Aurora.Overview.StorageReliability.html
- Example I or O cost on Standard and how to estimate it with CloudWatch  
  https://aws.amazon.com/blogs/database/estimate-cost-savings-for-the-amazon-aurora-i-o-optimized-feature-using-amazon-cloudwatch/
- Capacity settings and max connections notes for low ACU  
  https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/aurora-serverless-v2.setting-capacity.html
- Serverless v2 deployment and Multi AZ notes  
  https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/aurora-serverless-v2.html

## Next steps

- keep this page as selection rationale
- create db_design.md with ERDs, full DDL, partition rotation jobs, RLS policies, and migration plan
- stand up an Aurora Serverless v2 dev cluster using the MVP profile and run the benchmark harness
