# Why Schema Services Matter

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 26-Aug-2025](https://img.shields.io/badge/Last_Updated-26--Aug--2025-lightgrey)


## Data Problems Context

Enterprises of all sizes face recurring pain in how data is stored, discovered, and consumed. ERP systems (SAP, NetSuite, Tally), CRM platforms (Salesforce), and operational databases all expose data through complex, inconsistent, and poorly documented schemas. This creates three broad categories of challenges:

### ETL Hurdles
- Raw schemas are often inaccurate, inconsistent, and unstructured. 
- Data engineers have to re-discover the raw schemas from scratch.
- Data engineers have to re-link data to context, which is often a manual process.
- Raw/bronze schemas evolve with upgrades, silently breaking pipelines.  
- Discoverability is low: no single catalog, missing metadata, poor documentation.  
- Institutional knowledge disappears when the original team leaves.

### Analytics Struggles
- Raw schemas are often inaccurate, inconsistent, and unstructured.
- Analysts have to re-discover KPIs from scratch.
- Analysts have to re-discover business rules from scratch.
- Analysts have to re-discover regulations from scratch.
- Analysts have to re-discover business metrics from scratch.
- KPIs are defined in business language (“Liquidity ratio”, “DSO”), but raw tables/columns don’t encode that meaning.  
- Business rules and regulations change constantly, requiring re-linking of data to context.  
- Every new requirement leads to manual back-and-forth between SMEs and data engineers.


### Trust Deficit
- Even when schemas are known, data quality attributes are rarely measured or conveyed.  
- No single place to see if data is accurate, complete, or fresh.  
- Consistency across systems is unverified.  
- Integrity checks (keys, references) are not enforced.  
- Users have no visibility into core dimensions of trust:  
  - Accuracy  
  - Completeness  
  - Consistency  
  - Freshness  
  - Validity  
  - Integrity

!!! warning "Business Suffers:"
    Data engineers spend cycles rediscovering basics and firefighting failures.
    Analysts spend cycles rediscovering basics and firefighting failures.
    Trust in data stays low. Leaders doubt dashboards, analysts reconcile endlessly, and AI models train on shaky ground.
---

## Cxofacts Solution

Cxofacts is designed to solve these systemic issues. It provides a governed, contract-first platform that makes data both technically reliable and business-meaningful. Cxofacts links raw source tables → canonical business data points → KPIs and AI models, while enforcing data quality and governance at every step.

At the heart of this platform sits Schema Services - the foundational subsystem that manages schema contracts. It ensures: 

### Schema Services Anchors
1. Source Schemas: Faithful, discoverable definitions of raw ERP/CRM tables.  
2. GDP Schemas: Normalized, contextualized, canonical schemas that capture business meaning.  
3. KPI / Consumption Schemas: Contracts that make KPI definitions durable, traceable, and executable.  
4. AI Activation Schemas: Contracts for AI/ML feature stores and GenAI contexts, with privacy and evaluation gates.


![diagram placeholder](../../assets/diagrams/schema-services/context_vision.svg)

### Outcome

!!! success "With Schema Services as the keystone, Cxofacts delivers:"
    - Discoverability: every schema is catalogued, searchable, and versioned.  
    - Business Context: durable links between KPIs and raw data through GDP schemas.  
    - Trust: data quality dimensions are measured and enforced via DQC.  
    - Auditability: lifecycle, approvals, and change logs are built in.  
    - Resilience: schema drift and new requirements are handled as versioned changes, not firefighting.
    - Finally, Cxofacts solves the enterprise data trust problem. Schema Services is the keystone that makes it possible.
