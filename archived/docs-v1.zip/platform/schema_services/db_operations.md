# Schema Services - DB Operations

![status-draft](https://img.shields.io/badge/status-draft-yellow)
![last_updated-2025-08-28%2010:58%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2010:58%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This page covers partition rotation, RLS wiring, and observability for Schema Services.

!!! info
    Keep operations boring. Automate partition management and alerts on the first day.

## Partition Rotation

```sql
-- helper function
CREATE OR REPLACE FUNCTION registry.ensure_run_partitions(months_ahead int DEFAULT 3) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE
  start_month date := date_trunc('month', now())::date;
  m int;
  from_date date;
  to_date date;
  part_name text;
BEGIN
  FOR m IN 0..months_ahead LOOP
    from_date := (start_month + make_interval(months => m))::date;
    to_date   := (start_month + make_interval(months => m + 1))::date;
    part_name := format('schema_run_%s', to_char(from_date, 'YYYY_MM'));

    EXECUTE format(
      'CREATE TABLE IF NOT EXISTS registry.%I PARTITION OF registry.schema_run FOR VALUES FROM (%L) TO (%L)',
      part_name, from_date, to_date
    );
  END LOOP;
END;
$$;
```

Schedule with `pg_cron`:

```sql
CREATE EXTENSION IF NOT EXISTS pg_cron;
SELECT cron.schedule('ensure-partitions-daily', '15 2 * * *', $$SELECT registry.ensure_run_partitions(3);$$);
```

Or run daily from Lambda with `psql`.

## RLS Wiring

```sql
ALTER TABLE registry.tenant_binding ENABLE ROW LEVEL SECURITY;
ALTER TABLE registry.schema_run     ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION registry.current_tenant() RETURNS text
LANGUAGE sql STABLE AS $$
  SELECT current_setting('app.current_tenant', true)
$$;

CREATE POLICY tenant_binding_isolation ON registry.tenant_binding
  USING (tenant_id = registry.current_tenant());

CREATE POLICY schema_run_isolation ON registry.schema_run
  USING (tenant_id IS NULL OR tenant_id = registry.current_tenant());
```

## Observability

| Area | What to track |
|---|---|
| SQL | pg_stat_statements top N, slow query log over 2 s |
| Storage | partition sizes, vacuum progress, bloat trending |
| Connections | max vs in‑use, spikes that block scale‑down |
| I/O share | switch to I/O‑Optimized when I/O share crosses 25 percent |
| Replication | logical replication lag and retry budget |

!!! note
    Add a basic dashboard for CPU, connections, cache hit ratio, checkpoints, and replication lag. Alert on p95 over gate and partition creation failures.
