# CI/CD — Schema Services (Backend)

**Repo:** `github.com/anant-selenite/backend`  
**Scope:** Infrastructure (AWS CDK/CloudFormation), Registry API service, DB migrations (PostgreSQL via Alembic), Catalog artifact publishing (docs live in a separate repo).

---

## 1) Branching & Environments

- **Branches**
  - `main` → protected; production releases only
  - `dev` → integration; auto-deploy to **DEV**
  - feature branches: `feat/*`, `fix/*`, `chore/*`

- **Environments**
  - **DEV** (auto from `dev`): cheap, fast, wide open for testing
  - **QA** (manual promote from `dev`): representative sizing, restricted write access
  - **PROD** (manual promote from `main`): deletion protection, change-set review required

- **Release tags**
  - `vX.Y.Z` on `main` → production release; immutable images and artifacts

---

## 2) Repo Structure (suggested)

```
backend/
  infra/
    cdk/                 # CDK app (TypeScript)
      bin/
      lib/
      cdk.json
      package.json
    pipelines/           # GitHub workflow definitions (templated)
  services/
    registry-api/        # FastAPI/Flask app (example)
      src/
      tests/
      pyproject.toml
      Dockerfile
  db/
    alembic/
      versions/          # migration scripts
    alembic.ini
    seeds/
      meta_schema_1_0_0.json
      seed.sql
  catalog/
    loaders/             # DDIC/CSV/JSON parsers
    samples/
  docs/
    mkdocs.yml
    platform/
      schema_services/
        CICD.md          # this file
```

---

## 3) GitHub Settings (hard requirements)

- **Branch protection**
  - `main`: require PR + code review + passing checks: `ci-test`, `db-migrate-dry-run`, `cdk-synth-diff`
  - `dev`: require passing checks: `ci-test`
- **Environments (GitHub)**: `DEV`, `QA`, `PROD` with required reviewers for `QA`/`PROD`
- **Secrets (GitHub → Actions)** (examples)
  - `AWS_ACCOUNT_ID`, `AWS_REGION`
  - `AWS_ROLE_TO_ASSUME_DEV`, `AWS_ROLE_TO_ASSUME_QA`, `AWS_ROLE_TO_ASSUME_PROD` (OIDC)
  - `DB_SUPERUSER_SECRET_ARN_DEV/QA/PROD` (AWS Secrets Manager arns)
  - `ARTIFACTS_BUCKET_DEV/QA/PROD` (S3 bucket names)
  - `ECR_REGISTRY` (e.g., `xxxxxxxxxxx.dkr.ecr.ap-south-1.amazonaws.com`)
- **OIDC** for GitHub Actions → IAM Roles per environment

---

## 4) Pipeline Stages (common)

1. **Lint & Build**
   - Python: `ruff`, `pytest -q`
   - CDK synth: `npm i`, `cdk synth`
2. **DB Migration (dry-run)**
   - Build Docker image for migrations; run `alembic upgrade --sql head` against a disposable container to validate scripts
3. **Image Build & Push**
   - Build `registry-api` Docker image and push to ECR with tag: branch SHA or release tag
4. **Infra Deploy (CDK → CloudFormation)**
   - `DEV`: auto deploy on `dev` push
   - `QA`/`PROD`: manual approval (environment protection)
5. **DB Migration (apply)**
   - Run `alembic upgrade head` **post-deploy** via maintenance task (Fargate task or Lambda) with rollback guard
6. **Seed (idempotent)**
   - Apply `seeds/meta_schema_1_0_0.json` into `registry_meta_schema` if not exists
7. **Publish Catalog Artifacts (if changed)**
   - Sync generated JSON to `s3://ARTIFACTS_BUCKET/catalog/...`

---

## 5) Alembic Conventions

- **Immutable history**: never edit old migrations; new migration for every change
- **Idempotent seed**: `INSERT ... ON CONFLICT DO NOTHING` style or app-level guard
- **Events**: DB triggers to append entries in `registry_schema_events` on writes to registry tables
- **Safety**: destructive changes to PROD blocked unless
  - explicit flag `ALLOW_DESTRUCTIVE=true`
  - change set reviewer approved

---

## 6) CDK Stacks (TS)

- `RegistryCoreStack` (once)
  - VPC (2–3 AZ), Security Groups
  - RDS Postgres/Aurora PG (Multi-AZ, KMS, backups, deletion protection)
  - Parameter Group (pg_stat_statements; logical_replication as needed)
  - Secrets Manager (DB creds, rotation enabled)
  - S3 `schema-registry-artifacts` (KMS, lifecycle, block public access)
  - IAM roles for GitHub OIDC deploy, ECS tasks, migrations
  - CloudWatch Alarms (CPU, conn, free storage, replica lag)

- `RegistryAppStack` (frequent)
  - ECR repo for registry-api
  - ECS Fargate service or Lambda (API)
  - ALB, WAF, Route 53 record
  - SG rules from ALB → App; App → DB
  - SSM Parameters (export ARNs/URLs)

**Security Aspects:** `cdk-nag` enabled; fix or suppress with rationale.

---

## 7) GitHub Actions — Workflows

### 7.1 `.github/workflows/ci.yml` (PRs & pushes to any branch)
```yaml
name: ci
on:
  pull_request:
  push:
    branches: ['**']
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.11' }
      - name: Install deps (backend)
        run: |
          python -m pip install -U pip
          pip install -e services/registry-api[dev]
          pip install alembic
      - name: Lint & unit tests
        run: |
          pip install ruff
          ruff services/registry-api/src --output-format=github
          pytest -q services/registry-api/tests
      - name: Alembic dry-run SQL
        working-directory: db
        run: |
          alembic upgrade --sql head > /tmp/migration.sql
          test -s /tmp/migration.sql
      - name: CDK synth
        working-directory: infra/cdk
        run: |
          npm ci
          npx cdk synth
```

### 7.2 `.github/workflows/dev-deploy.yml` (push to `dev` → DEV)
```yaml
name: deploy-dev
on:
  push:
    branches: ['dev']
permissions:
  id-token: write
  contents: read
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      # Login to AWS via OIDC, assume DEV role
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_TO_ASSUME_DEV }}
          aws-region: ${{ secrets.AWS_REGION }}

      # Build & push image
      - name: Build & push ECR image
        run: |
          IMAGE=${{ secrets.ECR_REGISTRY }}/registry-api:${{ github.sha }}
          docker build -t $IMAGE services/registry-api
          aws ecr get-login-password --region ${{ secrets.AWS_REGION }} | docker login --username AWS --password-stdin ${{ secrets.ECR_REGISTRY }}
          docker push $IMAGE
          echo "IMAGE=$IMAGE" >> $GITHUB_ENV

      # CDK deploy (DEV)
      - name: CDK deploy
        working-directory: infra/cdk
        env:
          CDK_NEW_BOOTSTRAP: 1
        run: |
          npm ci
          npx cdk bootstrap
          npx cdk deploy --require-approval never "*"

      # Run DB migrations on DEV
      - name: Alembic upgrade (DEV)
        env:
          DB_SECRET_ARN: ${{ secrets.DB_SUPERUSER_SECRET_ARN_DEV }}
          AWS_REGION: ${{ secrets.AWS_REGION }}
        run: |
          python -m pip install -U pip boto3 psycopg2-binary alembic
          python db/scripts/run_alembic_from_secret.py --secret-arn "$DB_SECRET_ARN" upgrade head

      # Seed meta-schema v1.0.0 (idempotent)
      - name: Seed meta-schema
        run: |
          python -m pip install -U pip boto3 psycopg2-binary
          python db/scripts/seed_meta_schema.py db/seeds/meta_schema_1_0_0.json
```

### 7.3 `.github/workflows/release.yml` (tag on `main` → QA/PROD promotes)
```yaml
name: release
on:
  push:
    tags: ['v*.*.*']
permissions:
  id-token: write
  contents: read
jobs:
  promote-qa:
    runs-on: ubuntu-latest
    environment: QA
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_TO_ASSUME_QA }}
          aws-region: ${{ secrets.AWS_REGION }}
      - name: Deploy QA (CDK)
        working-directory: infra/cdk
        run: |
          npm ci
          npx cdk deploy --require-approval never "*"
      - name: Migrate QA
        env:
          DB_SECRET_ARN: ${{ secrets.DB_SUPERUSER_SECRET_ARN_QA }}
          AWS_REGION: ${{ secrets.AWS_REGION }}
        run: |
          python -m pip install -U pip boto3 psycopg2-binary alembic
          python db/scripts/run_alembic_from_secret.py --secret-arn "$DB_SECRET_ARN" upgrade head

  promote-prod:
    needs: promote-qa
    runs-on: ubuntu-latest
    environment: PROD
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_TO_ASSUME_PROD }}
          aws-region: ${{ secrets.AWS_REGION }}
      - name: Deploy PROD (CDK) via Change Set
        working-directory: infra/cdk
        run: |
          npm ci
          npx cdk deploy --require-approval broadening "*"
      - name: Migrate PROD (guarded)
        env:
          DB_SECRET_ARN: ${{ secrets.DB_SUPERUSER_SECRET_ARN_PROD }}
          AWS_REGION: ${{ secrets.AWS_REGION }}
          ALLOW_DESTRUCTIVE: "false"
        run: |
          python -m pip install -U pip boto3 psycopg2-binary alembic
          python db/scripts/run_alembic_from_secret.py --secret-arn "$DB_SECRET_ARN" upgrade head
```

---

## 8) Rollback Strategy

- **Infra**: CloudFormation change sets; stack policy blocks deletes; last-known-good tag `vX.Y.Z` re-deployable
- **DB**: migrations are forward-only; rollback = new migration that restores previous shape/data; PITR drill for RDS
- **API**: blue/green or minimum two ECS tasks; ALB target group shift

---

## 9) Quality Gates & Policies

- `cdk-nag`/`cfn-nag`: must pass
- Unit tests coverage threshold (set a baseline, e.g., 70%)
- JSON Schema validation in CI for **meta-schema** and **catalog artifacts**
- No direct pushes to `main`; no force-pushes

---

## 10) First Tasks (Day 1)

1. Create repo `backend` on GitHub org `anant-selenite`
2. Configure OIDC → IAM roles for DEV/QA/PROD
3. Scaffold CDK app (TS) under `infra/cdk`
4. Add Alembic and initial migrations under `db/`
5. Add Actions workflows above
6. Seed `meta_schema_1_0_0.json` and `seed.sql`
7. Push `dev` branch → verify DEV deploy & DB migrate
8. Tag `v0.1.0` → promote QA (manual), then PROD (manual)


---

## 11) Documentation (separate repo)

- Docs are managed in a **separate repository/app** (e.g., `github.com/anant-selenite/docs`).
- That repo owns its **own CI/CD** (lint, link-check, build & publish to `docs.cxofacts.com`). 
- This `backend` repo **does not** build or publish docs.

---

## 12) Cost & Architecture Guardrails (from `db_selection`)

**Default DB:** **Amazon Aurora PostgreSQL Serverless v2** (pay-per-ACU, JSONB, RLS, logical replication).  
**Why:** Strong consistency for system-of-record, economical scaling; JSONB + GIN for envelopes; partitioned tables for runs.

**Targets (gates):**
- Read/Write throughput: ~300 rps read / ~60 rps write (system-of-record) with bursty telemetry acceptable within caps.
- Availability/Durability: 99.95% (SoR), PITR; Multi-AZ.
- Scale horizon (12 mo): ~50k schemas, 500k versions, 50k consumers, 1M bindings, billions of runs.

**Economy rules (enforced via CI/CD & CDK):**
- Start at **low ACU**; **autoscaling** enabled; alarms on ACU floor/ceiling.
- Prefer **Aurora Standard** storage with I/O Optimized **only if** CloudWatch shows 25%+ cost delta favoring IO-Optimized.
- **Partition `schema_run`** by month; **partial indexes** (e.g., failed status) to keep index cost low.
- **GIN (jsonb_path_ops)** only where query patterns justify it (measured by `pg_stat_statements`).
- **Row Level Security (RLS)** on tenant-bound tables; policies tied to tenant claims.
- **Benchmark harness** in CI: fail PRs if queries breach **P95 latency** or cost SLOs.
- **Fallback plan**: if telemetry gates fail on Aurora (cost/latency), **split model** — keep SoR on Aurora, move telemetry/runs to ClickHouse.

**Pipeline hooks:**
- Add a **`db-benchmark` job** running representative read/write and catalog queries against a DEV Aurora cluster, asserting SLOs.
- Add a **`cost-check`** step pulling CloudWatch metrics to decide IO-Optimized toggle.
