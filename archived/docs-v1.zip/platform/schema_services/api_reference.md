# API Reference Schema Registry

![status-stable](https://img.shields.io/badge/status-stable-brightgreen)
![last_updated-2025-08-28%2014:22%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2014:22%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This page embeds the interactive OpenAPI reference for the schema registry. Use it with the api guide for correct usage patterns.

<swagger-ui
  src="/assets/api/schema_registry_openapi.v2025-08-28.yaml"
  deepLinking="true"
  persistAuthorization="true"
  displayRequestDuration="true"
  docExpansion="none"
  validatorUrl="null">
</swagger-ui>
