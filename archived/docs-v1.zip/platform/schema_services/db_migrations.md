# Schema Services - DB Migrations

![status-draft](https://img.shields.io/badge/status-draft-yellow)
![last_updated-2025-08-28%2010:58%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2010:58%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This page contains the initial, authoritative DDL for Schema Services and how to apply it.

!!! info
    Use Flyway or Liquibase in CI. The SQL below is designed to be idempotent where safe. Treat it as `V001` and evolve forward only.

## Apply With psql

```bash
psql "host=<endpoint> port=5432 dbname=registry user=registry_admin sslmode=require" \
  -f migrations/V001__schema_registry_init.sql
```

## Flyway Example

```bash
flyway -url="jdbc:postgresql://<endpoint>:5432/registry" \
  -user=registry_admin -password=CHANGE_ME migrate
```

## Initial DDL (V001)

```sql
-- V001__schema_registry_init.sql
-- Schema Services: initial objects (registry namespace, core tables, telemetry, RLS, helpers)

CREATE SCHEMA IF NOT EXISTS registry;

CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- Core
CREATE TABLE IF NOT EXISTS registry.schema (
  schema_id      UUID PRIMARY KEY,
  name           TEXT NOT NULL UNIQUE,
  display_name   TEXT,
  category       TEXT NOT NULL CHECK (category IN ('source','gdp','kpi','ai')),
  owner          JSONB,
  tags           TEXT[] DEFAULT ARRAY[]::TEXT[],
  description    TEXT,
  links          JSONB,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at     TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS registry.schema_version (
  schema_id        UUID NOT NULL REFERENCES registry.schema(schema_id) ON DELETE RESTRICT,
  version          TEXT NOT NULL,
  envelope_json    JSONB NOT NULL,
  governance_state TEXT NOT NULL CHECK (governance_state IN ('draft','in_review','approved','released','deprecated','retired')),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (schema_id, version)
);

CREATE INDEX IF NOT EXISTS ix_schema_version__schema_created ON registry.schema_version (schema_id, created_at DESC);
CREATE INDEX IF NOT EXISTS ix_schema_version__envelope ON registry.schema_version USING GIN (envelope_json jsonb_path_ops);

CREATE TABLE IF NOT EXISTS registry.approval (
  schema_id UUID NOT NULL,
  version   TEXT NOT NULL,
  role      TEXT NOT NULL CHECK (role IN ('author','reviewer','approver','operator')),
  decision  TEXT NOT NULL CHECK (decision IN ('approved','rejected','changes_requested')),
  at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  by        TEXT NOT NULL,
  comment   TEXT,
  PRIMARY KEY (schema_id, version, role, at),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS registry.lineage_edge (
  schema_id      UUID NOT NULL,
  version        TEXT NOT NULL,
  from_schema_id UUID NOT NULL,
  from_version   TEXT NOT NULL,
  relation       TEXT NOT NULL CHECK (relation IN ('derives_from','joins','aggregates','calculates_from','feeds','duplicates')),
  note           TEXT,
  PRIMARY KEY (schema_id, version, from_schema_id, from_version, relation),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS registry.binding (
  schema_id        UUID NOT NULL,
  version          TEXT NOT NULL,
  target_schema_id UUID NOT NULL,
  target_category  TEXT NOT NULL CHECK (target_category IN ('source','gdp','kpi','ai')),
  mapping_ref      TEXT,
  note             TEXT,
  PRIMARY KEY (schema_id, version, target_schema_id),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS registry.consumer (
  consumer_id UUID PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT NOT NULL CHECK (type IN ('bi','etl','agent','service','other')),
  owner       JSONB,
  links       JSONB
);

CREATE TABLE IF NOT EXISTS registry.schema_consumption (
  schema_id   UUID NOT NULL,
  version     TEXT NOT NULL,
  consumer_id UUID NOT NULL REFERENCES registry.consumer(consumer_id) ON DELETE RESTRICT,
  environment TEXT NOT NULL CHECK (environment IN ('dev','test','stage','prod')),
  mode        TEXT,
  PRIMARY KEY (schema_id, version, consumer_id),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

-- Tenant bindings
CREATE TABLE IF NOT EXISTS registry.tenant_binding (
  schema_id         UUID NOT NULL,
  version           TEXT NOT NULL,
  tenant_id         TEXT NOT NULL,
  environment       TEXT NOT NULL CHECK (environment IN ('dev','test','stage','prod')),
  effective_version TEXT NOT NULL,
  effective_from    TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_to      TIMESTAMPTZ,
  override          BOOLEAN NOT NULL DEFAULT false,
  PRIMARY KEY (schema_id, version, tenant_id, environment, effective_from),
  FOREIGN KEY (schema_id, version) REFERENCES registry.schema_version(schema_id, version) ON DELETE RESTRICT
);

-- Telemetry (partitioned)
CREATE TABLE IF NOT EXISTS registry.schema_run (
  run_id      UUID PRIMARY KEY,
  schema_id   UUID NOT NULL,
  version     TEXT NOT NULL,
  tenant_id   TEXT,
  environment TEXT CHECK (environment IN ('dev','test','stage','prod')),
  run_type    TEXT CHECK (run_type IN ('validate','load','serve')),
  status      TEXT CHECK (status IN ('success','failed','partial')),
  started_at  TIMESTAMPTZ NOT NULL,
  finished_at TIMESTAMPTZ,
  duration_ms INTEGER,
  rows_in     BIGINT,
  rows_out    BIGINT,
  error_count INTEGER,
  error_ref   TEXT,
  trace_id    TEXT
) PARTITION BY RANGE (started_at);

CREATE INDEX IF NOT EXISTS ix_schema_run__schema_version_time ON registry.schema_run (schema_id, version, started_at DESC);
CREATE INDEX IF NOT EXISTS ix_schema_run__tenant_time ON registry.schema_run (tenant_id, started_at DESC);
CREATE INDEX IF NOT EXISTS ix_schema_run__failures ON registry.schema_run (schema_id, started_at DESC) WHERE status = 'failed';

-- RLS
ALTER TABLE registry.tenant_binding ENABLE ROW LEVEL SECURITY;
ALTER TABLE registry.schema_run     ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION registry.current_tenant() RETURNS text
LANGUAGE sql STABLE AS $$
  SELECT current_setting('app.current_tenant', true)
$$;

CREATE POLICY tenant_binding_isolation ON registry.tenant_binding
  USING (tenant_id = registry.current_tenant());

CREATE POLICY schema_run_isolation ON registry.schema_run
  USING (tenant_id IS NULL OR tenant_id = registry.current_tenant());

-- Partition rotation helper
CREATE OR REPLACE FUNCTION registry.ensure_run_partitions(months_ahead int DEFAULT 3) RETURNS void
LANGUAGE plpgsql AS $$
DECLARE
  start_month date := date_trunc('month', now())::date;
  m int;
  from_date date;
  to_date date;
  part_name text;
BEGIN
  FOR m IN 0..months_ahead LOOP
    from_date := (start_month + make_interval(months => m))::date;
    to_date   := (start_month + make_interval(months => m + 1))::date;
    part_name := format('schema_run_%s', to_char(from_date, 'YYYY_MM'));

    EXECUTE format(
      'CREATE TABLE IF NOT EXISTS registry.%I PARTITION OF registry.schema_run FOR VALUES FROM (%L) TO (%L)',
      part_name, from_date, to_date
    );
  END LOOP;
END;
$$;

```

