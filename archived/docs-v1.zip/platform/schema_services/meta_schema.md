# Meta-Schema Authoritative Contract

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 27-Aug-2025](https://img.shields.io/badge/Last_Updated-27--Aug--2025-lightgrey)

---

**Scope:** Define the canonical, machine-validated Schema Object envelope and provide example envelopes for each category (source, gdp, kpi, ai).  
**Non-Goals:** This page does not define registry storage DDL or runtime telemetry; see “Associations & Telemetry”.

---

## Context

Schema definitions drift, teams reinterpret fields, and integrations break without a single enforced contract.  
We need a single canonical meta-schema that every tool (authoring UI, Registry API, validators, CI) references.

**Constraints**
- Multi-tenant; must support global/provider/tenant scope.
- Versioned contracts (SemVer); immutable per version.
- Contract-first lineage across Source ⇄ GDP ⇄ KPI ⇄ AI.

---

## Goals / Non-Goals

**Goals**
1. Publish an authoritative JSON Schema (Draft 2020-12) for the Schema Object envelope.  
2. Provide category examples (source/gdp/kpi/ai) as reference envelopes.  
3. Make it consumable by humans (this page) and machines (JSON).

**Non-Goals**
- Counters/usage and tenant bindings (tracked outside the envelope).
- End-to-end OpenAPI and DDL (covered in separate docs).

---

## Canonical Meta-Schema

Below is the complete JSON Schema (Draft 2020-12) for Schema Objects.  
Copy this into validators, Registry API contracts, and CI pipelines.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://cxofacts.dev/schemas/schema-object-meta.json",
  "title": "Cxofacts Schema Object \u2014 Canonical Meta-Schema",
  "description": "Contract for versioned schema objects across categories (source, GDP, KPI, AI). Envelope + governance + ops + payload reference.",
  "type": "object",
  "required": [
    "schema_id",
    "name",
    "category",
    "version",
    "created_at",
    "governance",
    "payload"
  ],
  "additionalProperties": false,
  "properties": {
    "schema_id": {
      "$ref": "#/$defs/uuid"
    },
    "name": {
      "$ref": "#/$defs/slug",
      "description": "Stable, DNS-safe name (no spaces)."
    },
    "display_name": {
      "type": "string",
      "minLength": 1
    },
    "category": {
      "$ref": "#/$defs/category"
    },
    "kind": {
      "description": "Subtype for the category.",
      "type": "string",
      "enum": [
        "table",
        "view",
        "event",
        "metric",
        "cube",
        "contract",
        "profile",
        "embedding",
        "prompt",
        "model",
        "feature_view",
        "udf",
        "unknown"
      ]
    },
    "version": {
      "$ref": "#/$defs/semver"
    },
    "created_at": {
      "$ref": "#/$defs/datetime"
    },
    "updated_at": {
      "$ref": "#/$defs/datetime"
    },
    "tenant_scope": {
      "type": "object",
      "required": [
        "scope"
      ],
      "additionalProperties": false,
      "properties": {
        "scope": {
          "type": "string",
          "enum": [
            "global",
            "provider",
            "tenant"
          ]
        },
        "tenant_id": {
          "$ref": "#/$defs/slug"
        },
        "provider": {
          "type": "string",
          "description": "e.g., sap, salesforce, netsuite, tally"
        },
        "variant": {
          "type": "string",
          "description": "Provider version or add-on pack, e.g., S4HANA-2021 FPS1"
        }
      }
    },
    "owner": {
      "type": "object",
      "required": [
        "team"
      ],
      "additionalProperties": false,
      "properties": {
        "team": {
          "type": "string"
        },
        "email": {
          "type": "string",
          "format": "email"
        },
        "slack": {
          "type": "string"
        },
        "oncall": {
          "type": "string"
        }
      }
    },
    "tags": {
      "type": "array",
      "items": {
        "$ref": "#/$defs/tag"
      },
      "maxItems": 64
    },
    "description": {
      "type": "string"
    },
    "links": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "docs": {
          "type": "string",
          "format": "uri"
        },
        "catalog": {
          "type": "string",
          "format": "uri"
        },
        "source_repo": {
          "type": "string",
          "format": "uri"
        },
        "ticket": {
          "type": "string",
          "format": "uri"
        }
      }
    },
    "lineage": {
      "type": "array",
      "items": {
        "$ref": "#/$defs/lineage_edge"
      },
      "description": "Explicit upstream edges. Derived lineage may be richer."
    },
    "governance": {
      "$ref": "#/$defs/governance"
    },
    "rbac": {
      "$ref": "#/$defs/rbac"
    },
    "retention": {
      "$ref": "#/$defs/retention"
    },
    "ops": {
      "$ref": "#/$defs/ops"
    },
    "compatibility_policy": {
      "type": "string",
      "enum": [
        "strict_backward",
        "loose_backward",
        "forward",
        "none"
      ],
      "default": "strict_backward"
    },
    "bindings": {
      "type": "array",
      "items": {
        "$ref": "#/$defs/binding"
      },
      "description": "Mappings/links to other schema objects (e.g., KPI\u2192GDP, GDP\u2192Source)."
    },
    "validation_profiles": {
      "type": "array",
      "items": {
        "$ref": "#/$defs/validation_profile"
      }
    },
    "payload": {
      "$ref": "#/$defs/payload"
    },
    "checksums": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "payload_sha256": {
          "$ref": "#/$defs/hex256"
        },
        "envelope_sha256": {
          "$ref": "#/$defs/hex256"
        }
      }
    },
    "events": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "producer_topic": {
          "type": "string"
        },
        "consumer_topics": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "annotations": {
      "type": "object",
      "additionalProperties": {
        "type": "string"
      },
      "description": "Free-form key/value, non-authoritative."
    }
  },
  "$defs": {
    "uuid": {
      "type": "string",
      "format": "uuid"
    },
    "slug": {
      "type": "string",
      "pattern": "^[a-z0-9][a-z0-9-_]{1,127}$"
    },
    "tag": {
      "type": "string",
      "pattern": "^[A-Za-z0-9_.:-]{1,64}$"
    },
    "datetime": {
      "type": "string",
      "format": "date-time"
    },
    "semver": {
      "type": "string",
      "pattern": "^(0|[1-9]\\d*)\\.(0|[1-9]\\d*)\\.(0|[1-9]\\d*)(?:-[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?(?:\\+[0-9A-Za-z-]+(?:\\.[0-9A-Za-z-]+)*)?$",
      "description": "SemVer 2.0.0"
    },
    "category": {
      "type": "string",
      "enum": [
        "source",
        "gdp",
        "kpi",
        "ai"
      ]
    },
    "lineage_edge": {
      "type": "object",
      "required": [
        "from_schema_id",
        "from_version",
        "relation"
      ],
      "additionalProperties": false,
      "properties": {
        "from_schema_id": {
          "$ref": "#/$defs/uuid"
        },
        "from_version": {
          "$ref": "#/$defs/semver"
        },
        "relation": {
          "type": "string",
          "enum": [
            "derives_from",
            "joins",
            "aggregates",
            "calculates_from",
            "feeds",
            "duplicates"
          ]
        },
        "note": {
          "type": "string"
        }
      }
    },
    "approval": {
      "type": "object",
      "required": [
        "role",
        "by",
        "at",
        "decision"
      ],
      "additionalProperties": false,
      "properties": {
        "role": {
          "type": "string",
          "enum": [
            "author",
            "reviewer",
            "approver",
            "operator"
          ]
        },
        "by": {
          "type": "string"
        },
        "at": {
          "$ref": "#/$defs/datetime"
        },
        "decision": {
          "type": "string",
          "enum": [
            "approved",
            "rejected",
            "changes_requested"
          ]
        },
        "comment": {
          "type": "string"
        }
      }
    },
    "governance": {
      "type": "object",
      "required": [
        "state"
      ],
      "additionalProperties": false,
      "properties": {
        "state": {
          "type": "string",
          "enum": [
            "draft",
            "in_review",
            "approved",
            "released",
            "deprecated",
            "retired"
          ]
        },
        "approvals": {
          "type": "array",
          "items": {
            "$ref": "#/$defs/approval"
          }
        },
        "deprecation": {
          "type": "object",
          "additionalProperties": false,
          "properties": {
            "replaced_by": {
              "$ref": "#/$defs/uuid"
            },
            "date": {
              "$ref": "#/$defs/datetime"
            },
            "reason": {
              "type": "string"
            }
          }
        },
        "data_classification": {
          "type": "string",
          "enum": [
            "public",
            "internal",
            "restricted",
            "confidential",
            "secret"
          ],
          "default": "internal"
        },
        "pii": {
          "type": "boolean",
          "default": false
        },
        "sox_critical": {
          "type": "boolean",
          "default": false
        }
      }
    },
    "rbac": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "read": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "write": {
          "type": "array",
          "items": {
            "type": "string"
          }
        },
        "approve": {
          "type": "array",
          "items": {
            "type": "string"
          }
        }
      }
    },
    "retention": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "policy_id": {
          "$ref": "#/$defs/slug"
        },
        "ttl_days": {
          "type": "integer",
          "minimum": 0
        }
      }
    },
    "ops": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "slos": {
          "type": "object",
          "additionalProperties": false,
          "properties": {
            "availability": {
              "type": "number",
              "minimum": 0,
              "maximum": 1
            },
            "validate_p95_ms": {
              "type": "integer",
              "minimum": 0
            }
          }
        },
        "slis": {
          "type": "object",
          "additionalProperties": false,
          "properties": {
            "events_lag_ms": {
              "type": "integer",
              "minimum": 0
            },
            "last_validate_ms": {
              "type": "integer",
              "minimum": 0
            }
          }
        },
        "observability": {
          "type": "object",
          "additionalProperties": false,
          "properties": {
            "events_topic": {
              "type": "string"
            },
            "tracing_enabled": {
              "type": "boolean",
              "default": true
            }
          }
        }
      }
    },
    "binding": {
      "type": "object",
      "required": [
        "target_category",
        "target_schema_id"
      ],
      "additionalProperties": false,
      "properties": {
        "target_category": {
          "$ref": "#/$defs/category"
        },
        "target_schema_id": {
          "$ref": "#/$defs/uuid"
        },
        "mapping_ref": {
          "type": "string",
          "format": "uri"
        },
        "note": {
          "type": "string"
        }
      }
    },
    "validation_profile": {
      "type": "object",
      "required": [
        "profile_id"
      ],
      "additionalProperties": false,
      "properties": {
        "profile_id": {
          "$ref": "#/$defs/slug"
        },
        "ruleset_ref": {
          "type": "string",
          "format": "uri",
          "description": "Points to rule bundle (JSON Schema, SQL, DSL)."
        },
        "sampling": {
          "type": "string",
          "enum": [
            "none",
            "1pct",
            "5pct",
            "10pct",
            "full"
          ],
          "default": "none"
        },
        "severity": {
          "type": "string",
          "enum": [
            "info",
            "warn",
            "error"
          ],
          "default": "error"
        }
      }
    },
    "payload": {
      "type": "object",
      "oneOf": [
        {
          "required": [
            "schema_ref"
          ]
        },
        {
          "required": [
            "schema_inline"
          ]
        }
      ],
      "additionalProperties": false,
      "properties": {
        "format": {
          "type": "string",
          "enum": [
            "jsonschema",
            "avro",
            "protobuf",
            "parquet",
            "sql_ddl"
          ],
          "default": "jsonschema"
        },
        "schema_ref": {
          "type": "string",
          "format": "uri"
        },
        "schema_inline": {
          "type": "object",
          "description": "Embedded schema object (e.g., JSON Schema for a table/event)."
        },
        "checksum": {
          "$ref": "#/$defs/hex256"
        }
      }
    },
    "hex256": {
      "type": "string",
      "pattern": "^[a-f0-9]{64}$"
    }
  }
}
```

---

## Example Envelopes

These are full example envelopes for each category. Each uses `payload.schema_ref` pointing to where the concrete schema lives.

### a) Source Example
```json
{
  "schema_id": "32d018a5-10cd-4cb6-96c7-9f3111305d55",
  "name": "sap_bkpf",
  "display_name": "Sap Bkpf",
  "category": "source",
  "kind": "table",
  "version": "1.0.0",
  "created_at": "2025-08-28T03:14:26.670986Z",
  "updated_at": "2025-08-28T03:14:26.670986Z",
  "tenant_scope": {
    "scope": "tenant",
    "tenant_id": "acme-inc"
  },
  "owner": {
    "team": "data-platform",
    "email": "owner@example.com"
  },
  "tags": [
    "finance",
    "core"
  ],
  "description": "Example SOURCE schema envelope for sap_bkpf.",
  "lineage": [],
  "governance": {
    "state": "released",
    "approvals": [
      {
        "role": "approver",
        "by": "cto",
        "at": "2025-08-28T03:14:26.670986Z",
        "decision": "approved"
      }
    ],
    "data_classification": "internal",
    "pii": false
  },
  "rbac": {
    "read": [
      "role:analyst",
      "role:engineer"
    ],
    "write": [
      "role:engineer"
    ],
    "approve": [
      "role:data-owner"
    ]
  },
  "ops": {
    "slos": {
      "availability": 0.999,
      "validate_p95_ms": 50
    },
    "slis": {
      "events_lag_ms": 12,
      "last_validate_ms": 40
    },
    "observability": {
      "events_topic": "schema.events",
      "tracing_enabled": true
    }
  },
  "compatibility_policy": "strict_backward",
  "bindings": [],
  "validation_profiles": [
    {
      "profile_id": "default",
      "ruleset_ref": "https://cxofacts.dev/validation/default.json",
      "sampling": "none",
      "severity": "error"
    }
  ],
  "payload": {
    "format": "jsonschema",
    "schema_ref": "https://cxofacts.dev/schemas/source/sap_bkpf/1.0.0.json"
  },
  "checksums": {
    "payload_sha256": "0000000000000000000000000000000000000000000000000000000000000000",
    "envelope_sha256": "0000000000000000000000000000000000000000000000000000000000000000"
  },
  "events": {
    "producer_topic": "schema.lifecycle",
    "consumer_topics": [
      "validation.results"
    ]
  },
  "annotations": {
    "example": "true"
  }
}
```

### b) GDP Example
```json
{
  "schema_id": "570f976a-b836-4729-9f71-9dd9446a1290",
  "name": "gdp_general_ledger_header",
  "display_name": "Gdp General Ledger Header",
  "category": "gdp",
  "kind": "table",
  "version": "1.0.0",
  "created_at": "2025-08-28T03:14:26.670986Z",
  "updated_at": "2025-08-28T03:14:26.670986Z",
  "tenant_scope": {
    "scope": "tenant",
    "tenant_id": "acme-inc"
  },
  "owner": {
    "team": "data-platform",
    "email": "owner@example.com"
  },
  "tags": [
    "finance",
    "core"
  ],
  "description": "Example GDP schema envelope for gdp_general_ledger_header.",
  "lineage": [],
  "governance": {
    "state": "released",
    "approvals": [
      {
        "role": "approver",
        "by": "cto",
        "at": "2025-08-28T03:14:26.670986Z",
        "decision": "approved"
      }
    ],
    "data_classification": "internal",
    "pii": false
  },
  "rbac": {
    "read": [
      "role:analyst",
      "role:engineer"
    ],
    "write": [
      "role:engineer"
    ],
    "approve": [
      "role:data-owner"
    ]
  },
  "ops": {
    "slos": {
      "availability": 0.999,
      "validate_p95_ms": 50
    },
    "slis": {
      "events_lag_ms": 12,
      "last_validate_ms": 40
    },
    "observability": {
      "events_topic": "schema.events",
      "tracing_enabled": true
    }
  },
  "compatibility_policy": "strict_backward",
  "bindings": [],
  "validation_profiles": [
    {
      "profile_id": "default",
      "ruleset_ref": "https://cxofacts.dev/validation/default.json",
      "sampling": "none",
      "severity": "error"
    }
  ],
  "payload": {
    "format": "jsonschema",
    "schema_ref": "https://cxofacts.dev/schemas/gdp/gdp_general_ledger_header/1.0.0.json"
  },
  "checksums": {
    "payload_sha256": "0000000000000000000000000000000000000000000000000000000000000000",
    "envelope_sha256": "0000000000000000000000000000000000000000000000000000000000000000"
  },
  "events": {
    "producer_topic": "schema.lifecycle",
    "consumer_topics": [
      "validation.results"
    ]
  },
  "annotations": {
    "example": "true"
  }
}
```

### c) KPI Example
```json
{
  "schema_id": "c1bd03bd-4547-4bc4-8b8f-5e430979290f",
  "name": "kpi_current_ratio",
  "display_name": "Kpi Current Ratio",
  "category": "kpi",
  "kind": "metric",
  "version": "1.0.0",
  "created_at": "2025-08-28T03:14:26.670986Z",
  "updated_at": "2025-08-28T03:14:26.670986Z",
  "tenant_scope": {
    "scope": "tenant",
    "tenant_id": "acme-inc"
  },
  "owner": {
    "team": "data-platform",
    "email": "owner@example.com"
  },
  "tags": [
    "finance",
    "core"
  ],
  "description": "Example KPI schema envelope for kpi_current_ratio.",
  "lineage": [],
  "governance": {
    "state": "released",
    "approvals": [
      {
        "role": "approver",
        "by": "cto",
        "at": "2025-08-28T03:14:26.670986Z",
        "decision": "approved"
      }
    ],
    "data_classification": "internal",
    "pii": false
  },
  "rbac": {
    "read": [
      "role:analyst",
      "role:engineer"
    ],
    "write": [
      "role:engineer"
    ],
    "approve": [
      "role:data-owner"
    ]
  },
  "ops": {
    "slos": {
      "availability": 0.999,
      "validate_p95_ms": 50
    },
    "slis": {
      "events_lag_ms": 12,
      "last_validate_ms": 40
    },
    "observability": {
      "events_topic": "schema.events",
      "tracing_enabled": true
    }
  },
  "compatibility_policy": "strict_backward",
  "bindings": [],
  "validation_profiles": [
    {
      "profile_id": "default",
      "ruleset_ref": "https://cxofacts.dev/validation/default.json",
      "sampling": "none",
      "severity": "error"
    }
  ],
  "payload": {
    "format": "jsonschema",
    "schema_ref": "https://cxofacts.dev/schemas/kpi/kpi_current_ratio/1.0.0.json"
  },
  "checksums": {
    "payload_sha256": "0000000000000000000000000000000000000000000000000000000000000000",
    "envelope_sha256": "0000000000000000000000000000000000000000000000000000000000000000"
  },
  "events": {
    "producer_topic": "schema.lifecycle",
    "consumer_topics": [
      "validation.results"
    ]
  },
  "annotations": {
    "example": "true"
  }
}
```

### d) AI Example
```json
{
  "schema_id": "f05837c3-ac5f-4662-8b69-41d75aad6b91",
  "name": "ai_prompt_finance_summary",
  "display_name": "Ai Prompt Finance Summary",
  "category": "ai",
  "kind": "profile",
  "version": "1.0.0",
  "created_at": "2025-08-28T03:14:26.670986Z",
  "updated_at": "2025-08-28T03:14:26.670986Z",
  "tenant_scope": {
    "scope": "tenant",
    "tenant_id": "acme-inc"
  },
  "owner": {
    "team": "data-platform",
    "email": "owner@example.com"
  },
  "tags": [
    "finance",
    "core"
  ],
  "description": "Example AI schema envelope for ai_prompt_finance_summary.",
  "lineage": [],
  "governance": {
    "state": "released",
    "approvals": [
      {
        "role": "approver",
        "by": "cto",
        "at": "2025-08-28T03:14:26.670986Z",
        "decision": "approved"
      }
    ],
    "data_classification": "internal",
    "pii": false
  },
  "rbac": {
    "read": [
      "role:analyst",
      "role:engineer"
    ],
    "write": [
      "role:engineer"
    ],
    "approve": [
      "role:data-owner"
    ]
  },
  "ops": {
    "slos": {
      "availability": 0.999,
      "validate_p95_ms": 50
    },
    "slis": {
      "events_lag_ms": 12,
      "last_validate_ms": 40
    },
    "observability": {
      "events_topic": "schema.events",
      "tracing_enabled": true
    }
  },
  "compatibility_policy": "strict_backward",
  "bindings": [],
  "validation_profiles": [
    {
      "profile_id": "default",
      "ruleset_ref": "https://cxofacts.dev/validation/default.json",
      "sampling": "none",
      "severity": "error"
    }
  ],
  "payload": {
    "format": "jsonschema",
    "schema_ref": "https://cxofacts.dev/schemas/ai/ai_prompt_finance_summary/1.0.0.json"
  },
  "checksums": {
    "payload_sha256": "0000000000000000000000000000000000000000000000000000000000000000",
    "envelope_sha256": "0000000000000000000000000000000000000000000000000000000000000000"
  },
  "events": {
    "producer_topic": "schema.lifecycle",
    "consumer_topics": [
      "validation.results"
    ]
  },
  "annotations": {
    "example": "true"
  }
}
```

---

## Compatibility & Lifecycle

- Default policy: `compatibility_policy = strict_backward`  
- Breaking changes (e.g., field delete/type-narrow): require new major.  
- Lifecycle: `draft → in_review → approved → released → deprecated → retired`  
- Only released versions enter production pipelines; deprecation must specify replacement and date.

---

## What Stays Out

The envelope is immutable per version. Exclude:
- Run counters, success/failure tallies, last_used_at  
- Consumer/tenant rosters and per-tenant overrides  
- Pipeline/runtime telemetry

See companion: Schema Registry - Associations & Telemetry (consumers, tenant bindings, runs, usage).

---

## Validation & Tooling

- CI must validate every envelope against the meta-schema.  
- Authoring UI and Registry API should enforce `schema_ref | schema_inline` invariants, lifecycle gates, and RBAC.  
- Emit events on `schema.released`, `schema.deprecated`, `validation.failed`, `drift.detected` (event contracts in Events Catalog).

---

## Open Questions / Next

- Finalize diff & compatibility matrix (backward/forward rules).  
- Publish OpenAPI for Registry CRUD + lifecycle referencing this meta-schema.  
- DDL for `schema`, `schema_version`, `approval`, `binding`, `lineage_edge`, `event`.  
- Provider seed bundles (e.g., SAP FI minimal set) and validation profiles.

---

## References

- Meta-schema and examples are embedded above on this page for offline use.  
- Concept page: `schema_object.md`  
- Companion: `Schema Registry - Associations & Telemetry`  