# Schema Services Development Checklist
This is the single checklist we’ll use to finish and keep Schema Services healthy. It’s split into sections with objective “done” signals. Mark items as you complete them.

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Shared Services Team](https://img.shields.io/badge/Owner-Shared%20Services%20Team-blue)
![Last Updated: 27-Aug-2025](https://img.shields.io/badge/Last_Updated-27--Aug--2025-lightgrey)

---

## Documentation

- [x] Context, Requirements, Solution pages in MkDocs
- [x] Schema Object and Meta‑Schema (long form with examples)
- [x] OpenAPI Guide and Reference (Swagger UI rendered)
- [x] Database Selection (AWS‑6‑pager)
- [x] Database Design (DDL, RLS, partitions, CDC)
- [x] DB Setup & Infra (Terraform, apply steps)
- [x] DB Migrations (V001 DDL inline)
- [x] DB Benchmarks (k6 smokes and gate table)
- [x] DB Operations (partition rotation, RLS wiring, observability)

## OpenAPI & Swagger

- [x] Spec compiles locally with `openapi-spec-validator`
- [ ] Spec validation runs in CI on pull requests
- [ ] Every endpoint has an example request and example error body
- [ ] Consistent error model (problem+json) documented
- [ ] Pagination & filtering documented (limit, cursor/offset, sort)
- [ ] Security schemes documented (JWT/OAuth) with required scopes
- [ ] Idempotency key header documented on POST/PATCH where relevant
- [ ] Versioned doc path (e.g., `/assets/api/schema_registry_openapi.yaml` with version tag in header)
- [ ] CORS and auth flow tested via Swagger “Authorize” button

## Registry API Behavior

- [ ] Idempotency enforced server‑side for POST/PATCH (dedupe table or hash)
- [ ] ETag / conditional GET for schema summary endpoints
- [ ] Soft delete semantics for archive endpoints are implemented and logged
- [ ] Pagination limits capped and validated; input sanitization on filters
- [ ] 429 and retry‑after behavior specified for bursts

## Data Model & Meta‑Schema

- [x] Canonical meta‑schema published and reviewed
- [ ] Meta‑schema validation enforced in code path for create version
- [ ] Version immutability enforced after `released` state
- [ ] Lineage edges created on version publish
- [ ] Consumer bindings audited per environment; effective version honored

## Database (Aurora PostgreSQL Serverless v2)

- [ ] Dev cluster deployed (Standard I/O; min 0–0.5 ACU, max 2 ACU)
- [ ] Parameter group applied (timeouts, pg_stat_statements, logical replication)
- [ ] Migration `V001__schema_registry_init.sql` applied in dev
- [ ] RLS policies verified with tenant‑scoped JWT/session var
- [ ] Partition rotation job scheduled and observed to create next 3 months
- [ ] PITR retention set (7–14 days) and restore drill completed
- [ ] Publication for CDC created and consumer tested (Debezium/connector)
- [ ] Cost guardrails: connection pool caps, auto‑pause where feasible

## Benchmarks (Definition of Done)

- [ ] W1 Create Version meets P95 ≤ 50 ms @ 60 rps
- [ ] W2 List Versions meets P95 ≤ 30 ms @ 200 rps
- [ ] W3 Search meets P95 ≤ 30 ms @ 150 rps
- [ ] W4 Append Run meets P95 ≤ 30 ms @ 2k rps (burst 10k for 5 min)
- [ ] W5 Runs Query meets P95 ≤ 80 ms @ 100 rps; plans are stable
- [ ] W6 Usage Snapshot under 2 minutes @ 100M/day
- [ ] Cost observation: I/O share < 25%; flip to I/O‑Optimized if ≥ 25%

## Observability & Ops

- [ ] CloudWatch alarms: CPU, connections, freeable memory, disk queue, failover
- [ ] Slow query alert (> 2 s) and pg_stat_statements dashboard
- [ ] Partition creation failure alert; storage trend by partition
- [ ] Replication lag alert for CDC
- [ ] Runbook for incident triage (failed runs, backpressure, hotspot indexes)
- [ ] Monthly restore drill executed and documented

## Security & Compliance

- [ ] Secrets in AWS Secrets Manager; no secrets in code or CI logs
- [ ] Least‑privilege IAM for app, CI, and rotation jobs
- [ ] Audit trail for admin actions (approvals, archives, bindings)
- [ ] No PII stored in schema metadata; if any, DPIA completed

## Tenancy & Onboarding

- [ ] Checklist to onboard a tenant (binding, effective version, environment)
- [ ] Data retention windows defined (telemetry partitions and archives)
- [ ] Offboarding procedure (unbind, revoke tokens, archive schemas)

## CI/CD

- [ ] GitHub Actions: OpenAPI validate on PR
- [ ] GitHub Actions: migration dry‑run against disposable Postgres
- [ ] GitHub Actions: k6 smoke after deploy to dev
- [ ] Terraform plan & apply requires review for prod

## Release Management

- [ ] Versioning policy for schema versions (semver; immutability after release)
- [ ] Deprecation policy and consumer notification workflow
- [ ] Backward‑compat checks (CI gate on breaking changes)

---

### Notes / Decisions Log

- If telemetry gates fail or costs spike, fall back to split model (Aurora for SoR + ClickHouse for telemetry) with CDC.
- Multi‑region active‑active is out of scope; if required, re‑evaluate engine choice.

