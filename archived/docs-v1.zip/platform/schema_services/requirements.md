# Business & Product Requirements (BRD + PRD)

![Status: Draft](https://img.shields.io/badge/Status-Draft-yellow)
![Owner: Product Management](https://img.shields.io/badge/Owner-Product%20Management-blue)
![Last Updated: 27-Aug-2025](https://img.shields.io/badge/Last_Updated-27--Aug--2025-lightgrey)

---

## Business Requirements (BRD)

The problem statement has been established in Part A (Context).  
This section focuses only on what the business needs from Cxofacts and Schema Services.

### Core Requirements

- Stable schema contracts (no drift, versioned).  
- Schema discoverability for engineers and analysts.  
- Clear business context binding for KPIs.  
- Governance & approvals (SME sign-off, audit logs).  
- Tenant flexibility with global-first rules.  
- Measurable data quality enforcement (via DQC).  
- Traceability (KPI → GDP → Source).  

!!! info "Focus"
    BRD represents the *what* - the business expectations that the product must satisfy.

---

## Product Requirements (PRD)

These requirements describe *how* the product will meet the above business needs.

### Functional

- CRUD APIs for all schema types (Source, GDP, KPI, AI).  
- Schema lifecycle management: Draft → Review → Release → Retire.  
- DQC profiles: global baselines + tenant-specific overrides.  
- Schema diffing & validation tools.  
- Bindings: GDP→Source, KPI→GDP, AI→GDP/Source.  
- Event system for releases, drift, and validation failures.  
- Provider seeding from ERP/CRM dictionaries (e.g., SAP DDIC, NetSuite).  
- RBAC for authors, approvers, readers, operators.  

### Non-Functional

- Availability: Registry API uptime ≥ 99.9%.  
- Performance: Validation ≤ 50ms per 1k rows.  
- Scalability: Support ≥ 10k schemas, ≥ 100k versions.  
- Security: RBAC, tenant isolation, encryption at rest.  
- Observability: metrics, logs, alerts, runbooks.  

!!! note "Tenets"
    - Global-first, tenant-aware  
    - Contracts, not code  
    - Backward compatibility by default  
    - Auditability built-in  
    - API-first, UI thin client  

---

## Deliverables & Expected Outcomes

### Deliverables

- Schema Registry: central repository of versioned Source, GDP, KPI, AI schemas.  
- Schema Lifecycle Management: Draft → Review → Release → Retire with approvals logged.  
- DQC Profiles: baseline global rules + tenant-specific overrides, enforced at runtime.  
- APIs: CRUD, lifecycle, diff, validation, provider seeding, events.  
- UI Console (Admin): thin client for discovery, authoring, and approval workflows.  
- Event System: schema.released, schema.deprecated, validation.failed, drift.detected.  
- Auditability: changelog, approvals, lineage for each schema version.  
- Trust Metrics: data quality checks (accuracy, completeness, consistency, timeliness, validity, integrity).  
- Traceability Reports: governed lineage KPI → GDP → Source.  

### Expected Outcomes

!!! success "Impact on the Organization"
    - Reduced schema drift incidents → < 1% pipeline breakage.  
    - Faster schema onboarding → median review-to-release < 24h.  
    - Higher trust → 100% KPIs backed by versioned KPI schemas.  
    - Adoption → all tenants onboard with global + tenant schema governance.  