# Schema Services - Development Plan

![status-active](https://img.shields.io/badge/status-active-brightgreen)
![last_updated-2025-08-28%2011:20%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2011:20%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This is an actionable plan to take Schema Services from dev‑ready to GA. It contains a developer agenda, sprint‑sized tasks, acceptance criteria, and hard gates. Tone is direct. No vanity milestones.

!!! info
    scope covers api behavior, database wiring, benchmarks, ci, observability, and release operations. documentation is already in good shape and is considered done unless a task explicitly updates it.

## Ground Rules

- prefer boring solutions and small diffs. ship minimal and iterate.
- everything is validated by automation. manual steps are for drills only.
- contracts are enforced at boundaries. do not rely on client behavior.
- if a gate fails, stop and fix. do not pile on new features.

## Workstreams

| stream | scope | primary artifacts |
|---|---|---|
| backend | api behavior, idempotency, error model, etag, examples | code, openapi, swagger examples |
| platform | rls mapping, pooler config, auth, ci, testing | app bootstrap, ci workflows |
| perf | k6 harness and reports for w1–w6, plan captures | k6 scripts, reports, query plans |
| sre | alarms, dashboards, pitr drill, cost guardrails | cloudwatch, runbooks |
| data | cdc consumer, warehouse contracts | connector config, schemas |
| docs | update only when semantics change | mkdocs pages and examples |

## Now To GA Plan

| phase | goal | exit criteria |
|---|---|---|
| hardening | make the service safe to retry and inspect | idempotency and problem+json live, etag works, ci validates spec and runs smokes |
| proof | prove it meets gates | w1–w6 pass with captured plans and cost observation |
| launch | make it operable | alarms live, pitr drill completed, cdc wired, runbooks published |

## Developer Agenda

| day | backend | platform | perf | sre | data |
|---|---|---|---|---|---|
| d1 | implement idempotency storage and flow | map jwt claim to session var; verify rls with two tenants | prepare k6 env | set up slow query alert | plan cdc shape |
| d2 | adopt problem+json and add examples | add ci jobs for spec validation and smokes | run w2 and w4 smokes | add io share and idle pin alarms | choose connector |
| d3 | add etag and conditional get | enforce pagination limits and input validation | run w1 and w3 | schedule pitr drill | draft topics/tables |
| d4 | tighten error codes and retries | swagger authorize flow end‑to‑end | run w4 burst and w5 with plans | build dashboards | implement consumer |
| d5 | clean edges and docs | merge ci to default branch | run w6 snapshot | pitr drill dry run | validate lag budget |

!!! note
    the agenda is indicative. re‑sequence if blocked, but do not skip acceptance criteria.

## Sprint Backlog

| id | task | owner | type | acceptance | status |
|---|---|---|---|---|---|
| B‑1 | implement idempotency store and middleware | backend | api | repeat post with same key returns 200 and same body; no duplicate rows | todo |
| B‑2 | adopt problem+json error model | backend | api | every non‑2xx returns standardized fields; swagger examples render | todo |
| B‑3 | add etag and conditional get | backend | api | 304 returned when If‑None‑Match matches | todo |
| P‑1 | map jwt claim to app.current_tenant | platform | infra | cross‑tenant reads return zero rows in both app and psql | todo |
| C‑1 | openapi validate and k6 smokes in ci | platform | ci | failing validation or smoke fails the pr | todo |
| K‑1 | run w1–w6 and capture plans | perf | perf | all p95 gates pass; plans stored in repo | todo |
| S‑1 | alarms and dashboards | sre | ops | alerts fire in dry run; dashboards show key signals | todo |
| S‑2 | pitr drill | sre | ops | restore under 15 minutes; steps documented | todo |
| D‑1 | cdc consumer and schema | data | data | end‑to‑end change visible in warehouse under five minutes | todo |

## Detailed Instructions

### Idempotency Storage

Create a small table and hook it in the write path.

```sql
CREATE TABLE IF NOT EXISTS registry.idempotency_keys (
  key           text PRIMARY KEY,
  request_hash  text NOT NULL,
  status_code   int  NOT NULL,
  response_body jsonb NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_idem_created ON registry.idempotency_keys (created_at DESC);
```

Flow

- on POST or PATCH, require Idempotency‑Key header.
- hash the relevant request body fields. if the key exists and hash matches, return stored response with same status. if hash mismatches, return 409.
- store the first successful response; set a ttl job to purge old keys.

Quick test

```bash
curl -s -D- -H "Idempotency-Key: abc" -H "Content-Type: application/json" \
  -d '{"name":"demo","category":"gdp"}' https://.../schemas
curl -s -D- -H "Idempotency-Key: abc" -H "Content-Type: application/json" \
  -d '{"name":"demo","category":"gdp"}' https://.../schemas
```

### Error Model

Use application/problem+json with a stable shape.

```json
{
  "type": "https://errors.cxofacts.com/schema/validation",
  "title": "validation failed",
  "status": 422,
  "detail": "envelope_json.kind is required",
  "instance": "/schemas/123/versions/1.0.0",
  "errors": [{"path":"envelope_json.kind","message":"required"}]
}
```

Document retries and mapping

- 400 for client contract errors, 401/403 for auth, 404 not found, 409 conflict for idempotency hash mismatch, 422 validation, 429 rate limit with retry‑after, 5xx only for server faults.

### ETag And Conditional GET

- return ETag on read endpoints. use a stable hash of payload or version row xmin plus schema_id and version.
- support If‑None‑Match and return 304 when it matches.

### RLS Session Mapping

- set app.current_tenant from a jwt claim at connection open. if using a pooler, set on every checkout.
- verify with two tenants and direct psql calls.

```sql
SET app.current_tenant = 't1';
SELECT count(*) FROM registry.schema_run WHERE tenant_id = 't2'; -- expect 0
```

### CI Pipeline

Add a minimal workflow to validate OpenAPI and run k6 smokes against dev.

```yaml
name: api-validate-and-smoke
on:
  pull_request:
    paths:
      - "docs/assets/api/schema_registry_openapi.v2025-08-28.yaml"
      - "api/**"
jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: set up python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - name: validate openapi
        run: |
          pip install openapi-spec-validator
          python - <<'PY'
          import yaml
          from openapi_spec_validator import validate_v3_spec
          spec = yaml.safe_load(open('docs/assets/api/schema_registry_openapi.yaml'))
          validate_v3_spec(spec)
          print("spec valid")
          PY
  smoke:
    needs: validate
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: install k6
        run: |
          curl -s https://dl.k6.io/key.gpg | sudo gpg --dearmor -o /usr/share/keyrings/k6-archive-keyring.gpg
          echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
          sudo apt-get update && sudo apt-get install -y k6
      - name: run smokes
        env:
          BASE_URL: ${{ secrets.API_BASE_URL }}
          AUTH: ${{ secrets.API_AUTH }}
        run: |
          k6 run k6/w2_list_versions.js
          k6 run k6/w4_append_run.js
```

### Benchmarks

- run w1–w6 and record p50, p95, p99.
- capture explain analyze plans for w5 and commit to repo under perf/reports/yyyy‑mm‑dd.

### Observability And Cost

- alarms for slow query over two seconds, io share over twenty five percent, long lived idle connections, and partition creation failures.
- dashboards for cpu, connections, cache hit ratio, checkpoints, replication lag.

### PITR Drill

- simulate accidental drop of a small table in a dev snapshot and time restore to a new cluster. aim under fifteen minutes.

### CDC

- choose debezium or a managed connector.
- expose change tables via publication already created. document sink targets and retention.

## Gates And Acceptance

| area | gate |
|---|---|
| reliability | repeat POST with same idempotency key returns 200 and same body; conflict on hash mismatch |
| performance | w1–w6 pass p95 gates; plans for w5 captured |
| security | rls prevents cross‑tenant reads in app and psql |
| operability | alarms live; pitr drill under fifteen minutes; cdc lag under five minutes |
| documentation | examples render in swagger; api guide shows error model and retry rules |

## Decisions And Triggers

- flip to i o optimized when io share stays above twenty five percent for three days.
- split telemetry to clickhouse if w4 or w5 gates keep failing after index and partition tuning.

## Next Steps

- assign owners to the sprint backlog table.
- execute the developer agenda for five days.
- review gates and decide on ga or fallback.
