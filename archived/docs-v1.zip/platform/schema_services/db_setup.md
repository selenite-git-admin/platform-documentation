# Schema Services - DB Setup And Infra

![status-draft](https://img.shields.io/badge/status-draft-yellow)
![last_updated-2025-08-28%2010:58%20UTC+05:30](https://img.shields.io/badge/last_updated-2025-08-28%2010:58%20UTC+05:30-blue)
![owner-data_platform](https://img.shields.io/badge/owner-data_platform-informational)

This page packages a minimal, production‑sane way to stand up Aurora PostgreSQL Serverless v2 for Schema Services.

!!! info
    Start small. Use Standard I/O and tiny ACU caps. Flip to I/O‑Optimized and add replicas only when benchmarks or SLOs require it.

## Prerequisites

| Item | Notes |
|---|---|
| Terraform 1.5+ | local or in CI |
| AWS account and IAM | permissions for RDS, networking, CloudWatch |
| VPC networking | private subnets and a security group for the cluster |

## Terraform Module

Place these files under `infra/aurora_slsv2/`.

```hcl title="infra/aurora_slsv2/main.tf"
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.region
}

locals {
  tags = merge({
    Project = "Cxofacts Schema Services"
    Owner   = var.owner
    Env     = var.env
  }, var.extra_tags)
}

resource "aws_db_subnet_group" "registry" {
  name       = "${var.name}-db-subnets"
  subnet_ids = var.subnet_ids
  tags       = local.tags
}

resource "aws_rds_cluster_parameter_group" "registry" {
  name   = "${var.name}-aurora-pg15"
  family = "aurora-postgresql15"
  description = "Registry cluster params"

  parameter {
    name  = "idle_in_transaction_session_timeout"
    value = "60000"
  }

  parameter {
    name  = "statement_timeout"
    value = "60000"
  }

  parameter {
    name  = "rds.logical_replication"
    value = "1"
  }

  parameter {
    name  = "shared_preload_libraries"
    value = "pg_stat_statements"
  }

  tags = local.tags
}

resource "aws_rds_cluster" "registry" {
  cluster_identifier              = var.name
  engine                          = "aurora-postgresql"
  engine_version                  = var.engine_version
  database_name                   = var.db_name
  master_username                 = var.username
  master_password                 = var.password
  backup_retention_period         = var.backup_retention_days
  preferred_backup_window         = var.preferred_backup_window
  preferred_maintenance_window    = var.preferred_maintenance_window
  deletion_protection             = var.deletion_protection
  storage_encrypted               = true
  copy_tags_to_snapshot           = true
  iam_database_authentication_enabled = true
  db_subnet_group_name            = aws_db_subnet_group.registry.name
  vpc_security_group_ids          = var.security_group_ids
  db_cluster_parameter_group_name = aws_rds_cluster_parameter_group.registry.name

  # Aurora Standard vs I/O-Optimized.
  # "aurora" for Standard, "aurora-iopt1" for I/O-Optimized (if supported in your region/provider version).
  storage_type = var.storage_type

  serverlessv2_scaling_configuration {
    min_capacity = var.min_acu
    max_capacity = var.max_acu
  }

  tags = local.tags
}

resource "aws_rds_cluster_instance" "registry" {
  count               = 1
  identifier          = "${var.name}-instance-${count.index}"
  cluster_identifier  = aws_rds_cluster.registry.id
  instance_class      = "db.serverless"
  engine              = aws_rds_cluster.registry.engine
  engine_version      = aws_rds_cluster.registry.engine_version
  publicly_accessible = false
  performance_insights_enabled = true
  tags                = local.tags
}

```

```hcl title="infra/aurora_slsv2/variables.tf"
variable "region" { type = string }
variable "name"   { type = string }
variable "env"    { type = string }
variable "owner"  { type = string }
variable "db_name" { type = string }
variable "username" { type = string }
variable "password" { type = string, sensitive = true }
variable "subnet_ids" { type = list(string) }
variable "security_group_ids" { type = list(string) }

variable "engine_version" {
  type    = string
  default = "15.4"
}

variable "min_acu" {
  type    = number
  default = 0.5
}

variable "max_acu" {
  type    = number
  default = 2
}

variable "backup_retention_days" {
  type    = number
  default = 7
}

variable "preferred_backup_window" {
  type    = string
  default = "03:00-04:00"
}

variable "preferred_maintenance_window" {
  type    = string
  default = "sun:04:00-sun:05:00"
}

variable "deletion_protection" {
  type    = bool
  default = false
}

variable "storage_type" {
  type    = string
  default = "aurora" # Use "aurora-iopt1" to enable I/O-Optimized if supported
}

variable "extra_tags" {
  type    = map(string)
  default = {}
}

```

```hcl title="infra/aurora_slsv2/outputs.tf"
output "cluster_arn" {
  value = aws_rds_cluster.registry.arn
}

output "cluster_endpoint" {
  value = aws_rds_cluster.registry.endpoint
}

output "reader_endpoint" {
  value = aws_rds_cluster.registry.reader_endpoint
}

```

## Apply

```bash
cd infra/aurora_slsv2
terraform init
terraform apply   -var="region=ap-south-1"   -var="name=cxofacts-registry"   -var="env=dev"   -var="owner=data-platform"   -var="db_name=registry"   -var="username=registry_admin"   -var="password=CHANGE_ME"   -var='subnet_ids=["subnet-xxx","subnet-yyy"]'   -var='security_group_ids=["sg-zzz"]'
```

!!! note
    For I/O‑Optimized later, set `storage_type = "aurora-iopt1"` if supported in your region and provider version.

